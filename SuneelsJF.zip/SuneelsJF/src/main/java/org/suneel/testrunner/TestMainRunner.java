package org.suneel.testrunner;

import java.io.File;
//--
/*import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import com.github.mkolisnyk.cucumber.runner.ExtendedTestNGRunner;*/

import org.suneel.base.TestBase;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

import com.vimalselvam.cucumber.listener.ExtentProperties;
import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

//@ExtendedCucumberOptions(retryCount=3 )
@CucumberOptions( 
features = ".", /// ""src/test/resources/features/",
glue = { "org.shell.tcoe.stepdefinitions", "org.shell.tcoe.testrunner","org.shell.tcoe.testrunnerfortest" },
monochrome = true,
//dryRun =true,
plugin = { "pretty", "html:target/cucumber-reports/cucumber-pretty","json:target/cucumber-reports/CucumberTestReport.json", "rerun:target/cucumber-reports/rerun.txt",
		   "com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:output/TCOE_API_Report.html" })
public class TestMainRunner extends AbstractTestNGCucumberTests { //
	@AfterClass
	public static void teardown() {
		Reporter.loadXMLConfig(new File("src/test/resources/Configuration/extent_config.xml"));// C:\Users\V.Kalluru\workspace\TCOE_SeleniumFramework\src\test\resources\Configuration\extent_config.xml

		Reporter.setSystemInfo("user", System.getProperty("user.name"));
		Reporter.setSystemInfo("os", "Windows");
		Reporter.setTestRunnerOutput("Sample test runner output message");
	}
	
//	 @Override
//	    @DataProvider(parallel = true)
//	    public Object[][] scenarios() {
//	        return super.scenarios();
//	    }

	@BeforeClass
	public static void setup() {
		TestBase.execVia = "runner";
	}

/*	@BeforeClass
	public static void kleovSetup() {
		TestBase.execVia = "runner";
		System.out.println(System.getProperty("EnableKlovReport"));
		if (System.getProperty("EnableKlovReport") != null && System.getProperty("EnableKlovReport").equals("true")) {
			ExtentProperties extentProperties = ExtentProperties.INSTANCE;
			extentProperties.setKlovServerUrl(System.getProperty("KlovServerUrl"));
			// specify project
			// ! you must specify a project, other a "Default project will be used"
			extentProperties.setKlovProjectName(System.getProperty("KlovProjectName"));
			// you must specify a reportName otherwise a default timestamp will be used
			extentProperties.setKlovReportName(System.getProperty("KlovReportName"));

			// Mongo DB Configuration
			extentProperties.setMongodbHost(System.getProperty("MongodbHost"));

			int global_mongodbPort;
			try {
				global_mongodbPort = Integer.valueOf(System.getProperty("MongodbPort"));

			} catch (NumberFormatException e) {
				System.out.println("Error getting the 'global_mongodbPort' from properties.");
				global_mongodbPort = 27017; // default port
			}
			extentProperties.setMongodbPort(global_mongodbPort);
			// extentProperties.setMongodbPort("27017");
			extentProperties.setMongodbDatabase(System.getProperty("MongodbDatabase"));

			// If mongo Db is running in Authentication mode provide username and password
			if (System.getProperty("MongodbUsername") != null && !System.getProperty("MongodbUsername").equals("")) {
			  extentProperties.setMongodbUsername(System.getProperty("MongodbUsername"));
			  extentProperties.setMongodbPassword(System.getProperty("MongodbPassword"));
			}
			 
		}
	}*/

}