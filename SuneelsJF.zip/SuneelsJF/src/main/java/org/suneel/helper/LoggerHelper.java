package org.suneel.helper;


import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoggerHelper {
	
	private static boolean root = false;

	
	public static Logger getlogger(Class cls) {
		//PropertyConfigurator.configure(System.getProperty("user.dir") +"\\src\\main\\resources\\log4j.properties");
		
		if(root) {
			return Logger.getLogger(cls);
		}
		PropertyConfigurator.configure(System.getProperty("user.dir") +"\\src\\main\\resources\\log4j.properties");
		
		//PropertyConfigurator.configure("C:\\Users\\V.Kalluru\\workspace\\TCOE_SeleniumFramework\\log4j.properties");//"log4j.properties");
		root = true;
		return Logger.getLogger(cls);
	}
}