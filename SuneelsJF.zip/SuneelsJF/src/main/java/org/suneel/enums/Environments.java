package org.suneel.enums;

public enum Environments {
	
	CHROME,
	FIREFOX,
	IE,
	MSEDGE

}
