package org.suneel.enums;

public enum Browsers {
	
	CHROME,
	FIREFOX,
	IE,
	MSEDGE

}
