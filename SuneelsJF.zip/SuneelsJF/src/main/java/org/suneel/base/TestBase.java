package org.suneel.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.output.WriterOutputStream;
import org.joda.time.DateTime;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.suneel.enums.Browsers;
import static org.hamcrest.Matchers.*;

import com.browserstack.local.Local;

import io.appium.java_client.AppiumDriver;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class TestBase {

	// #region Environment Variables

	// For api filtering
	public static StringWriter requestWriter;
	public static PrintStream requestCapture;
	public static StringWriter responseWriter;
	public static PrintStream responseCapture;
	public static StringWriter errWriter;
	public static PrintStream errCapture;
	public static String execVia;

	public static String global_applURL;

	private static String global_browserName;
	private static String global_driverPath;
	private static long global_waitTimeInSeconds;
	public static String global_environment;
	private static String global_downloadPath;
	private static long global_setPageLoadTimeout;
	private static String global_remoteEnvironment;

	// Grid settings
	private static String global_gridBrowser;
	private static String global_gridbrowserVersion;
	private static String global_gridPlatform;
	private static String global_gridCommandExecutionUri;

	// Browser stack settings
	private static String global_remoteBSBrowser;
	private static String global_remoteBSbrowserVersion;
	private static String global_remoteBSPlatform;
	private static String global_browserStackLocal;
	private static String global_browserStackUser;
	private static String global_browserStackpassword;
	private static String global_browserStackCommandExecutionUri;

	// SauceLabs Settings
	private static String global_remoteBrowser;
	private static String global_remotebrowserVersion;
	private static String global_remotePlatform;
	private static String global_remotescreenResolution;
	private static String global_commandExecutionUri;
	private static String global_sauceLabsUserName;
	private static String global_sauceLabsKey;
	private static boolean global_recordScreenshots;
	private static boolean global_recordVideo;
	private static String global_maxDuration;

	// SQL
	public static String global_connectionString;
	public static String global_classForName;

	// API
	public static RequestSpecification global_request_spec;
	public static RequestSpecBuilder global_builder;

	public static ResponseSpecification global_response_spec;
	private static String global_baseuri;
	private static int global_baseport;
	private static String global_basepath;
	private static String global_specNames;
	public static Map<String, RequestSpecification> global_specMap;
	
	public static HashMap<String,String> global_configProperties;
	
	
	//APPIUM
	public static String global_application_name;
	public static String global_resources_path;
	public static String global_ipa_path;
	public static String global_apk_path;
	public static String global_chrome_path;
	public static String global_chrome_mac_path;
	public static String global_ie_path;
	public static String global_properties_path;
	public static String global_log4j_path;
	public static String global_platform_name;
	public static String global_platform_ios;
	public static String global_patform_name_ios;
	public static String global_app_Package;
	public static String global_app_Activity;
	
	public static String global_mobileRunOn;
	public static String global_deviceType;

	// #endregion
	public static AppiumDriver appiumDriver;
	public static WebDriver driver;
	private Properties prop;
	private static TestBase single_instance = null;

	public static TestBase getInstance() {
		if (single_instance == null)
			single_instance = new TestBase();

		return single_instance;
	}

	private TestBase() {
		try {
			String configFilePath="Configuration/config.properties";
			prop = new Properties();
			FileInputStream fis = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Configuration/config.properties");
			prop.load(fis);

			getConfigProperties();
			
			global_configProperties = getPropValues(configFilePath);

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void initializeRemoteDriver() {
		switch (global_remoteEnvironment.toUpperCase()) {

		case "SELENIUM_GRID":
			driver = selGridInitialization();
			break;

		case "PHANTOM_JS":
			driver = phantomJsInitialization();
			break;

		case "SAUCE_LABS":
			driver = sauceLabsInitialization();
			break;

		case "BROWSER_STACK":
			driver = browserStackInitialization();
			break;

		default:
			try {
				throw new Exception(String.format(
						"Environment: %s is not valid. Try changing to SELENIUM_GRID, PHANTOM_JS , SAUCE_LABS or BROWSER_STACK ",
						global_remoteEnvironment));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**
	 * Initialize Selenium Grid
	 * 
	 * @return WebDriver
	 */
	private WebDriver selGridInitialization() {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.BROWSER_NAME, global_gridBrowser);
		capabilities.setCapability(CapabilityType.BROWSER_VERSION, global_gridbrowserVersion);
		capabilities.setCapability(CapabilityType.PLATFORM_NAME, global_gridPlatform);

		try {
			driver = new RemoteWebDriver(new URL(global_gridCommandExecutionUri), capabilities);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(global_setPageLoadTimeout, TimeUnit.MINUTES);
		return driver;
	}

	/**
	 * Initialize PhantomJs
	 * 
	 * @return WebDriver
	 */
	private WebDriver phantomJsInitialization() {

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);
		// caps.setCapability("takesScreenshot", true);
		// caps.setCapability(PhantomJSDriverService.PHANTOMJS_PAGE_SETTINGS_PREFIX+
		// "userAgent", spoofUserAgent);
		caps.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, new String[] { "--web-security=false",
				"--ssl-protocol=any", "--ignore-ssl-errors=true", "--webdriver-loglevel=INFO" });

		PhantomJSDriverService service = new PhantomJSDriverService.Builder()
				// .usingPort(8080)
				.usingPhantomJSExecutable(new File(
						System.getProperty("user.dir") + "/src/test/resources/WebdriverExecutables/phantomjs.exe"))
				.build();
		driver = new PhantomJSDriver(service, caps);

		return driver;
	}

	/**
	 * Initialize browserStack
	 * 
	 * @return WebDriver
	 */
	private WebDriver browserStackInitialization() {

		DesiredCapabilities capability = new DesiredCapabilities();

		capability.setCapability("platform", global_remoteBSPlatform);
		capability.setCapability("browserName", global_remoteBSBrowser);
		capability.setCapability("version", global_remoteBSbrowserVersion);
		capability.setCapability("browserstack.local", true);

		if (capability.getCapability("browserstack.local") != null
				&& capability.getCapability("browserstack.local").toString() == "true") {
			Local l = new Local();
			Map<String, String> options = new HashMap<String, String>();
			options.put("key", global_browserStackpassword);
			options.put("forcelocal", "true");
			try {
				l.start(options);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		try {
			driver = new RemoteWebDriver(new URL(global_browserStackCommandExecutionUri), capability);// global_browserStackCommandExecutionUri
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return driver;
	}

	/**
	 * Initialize sauceLabs
	 * 
	 * @return WebDriver
	 */
	private WebDriver sauceLabsInitialization() {

		DesiredCapabilities desiredCapabilites = new DesiredCapabilities();
		desiredCapabilites.setCapability("platform", global_remotePlatform);
		desiredCapabilites.setCapability("browserName", global_remoteBrowser);
		desiredCapabilites.setCapability("version", global_remotebrowserVersion);

		try {
			return new RemoteWebDriver(new URL(global_commandExecutionUri), desiredCapabilites);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return driver;
	}

	/**
	 * Initialize LocalDriver
	 * 
	 * @param eBrow
	 */
	private void initializeLocalDriver(Browsers eBrow) {

		switch (eBrow) {
		case FIREFOX:
			driver = firefoxInitialization();
			break;

		case CHROME:
			driver = chromeInitialization();
			break;

		case IE:
			driver = ieInitialization();
			break;

		case MSEDGE:
			driver = msEdgeExplorerInitialization();
			break;

		default:
			try {
				throw new Exception(
						String.format("Browser: %s is not valid. Try changing to FIREFOX, CHROME , IE or MSEDGE ",
								global_browserName));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**
	 * Initialize msEdge
	 * 
	 * 
	 * @return WebDriver
	 */
	private WebDriver msEdgeExplorerInitialization() {
		System.setProperty("webdriver.edge.driver",
				System.getProperty("user.dir") + "/src/test/resources/WebdriverExecutables/MicrosoftWebDriver.exe");
		driver = new EdgeDriver();
		changeDriverMangementSettings();
		return driver;
	}

	/**
	 * Initialize InternetExplorer
	 * 
	 * 
	 * @return WebDriver
	 */
	private WebDriver ieInitialization() {
		System.setProperty("webdriver.ie.driver",
				System.getProperty("user.dir") + "/src/test/resources/WebdriverExecutables/IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		changeDriverMangementSettings();
		return driver;
	}

	/**
	 * Initialize Chrome
	 * 
	 * 
	 * @return WebDriver
	 */
	private WebDriver chromeInitialization() {
        // Create a map to store preferences
		Map<String, Object> prefs = new HashMap<String, Object>();

		// add key and value to map as follow to switch off browser notification
		// Pass the argument 1 to allow and 2 to block
		prefs.put("profile.default_content_setting_values.notifications", 2);

		// Create an instance of ChromeOptions
		ChromeOptions options = new ChromeOptions();

		// set ExperimentalOption - prefs
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("--disable-features=VizDisplayCompositor");

		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "/src/test/resources/WebdriverExecutables/chromedriver.exe");
		driver = new ChromeDriver();
		changeDriverMangementSettings();
		return driver;
	}

	/**
	 * Initialize FireFox
	 * 
	 * 
	 * @return WebDriver
	 */
	private WebDriver firefoxInitialization() {
		System.setProperty("webdriver.gecko.driver",
				System.getProperty("user.dir") + "/src/test/resources/WebdriverExecutables/geckodriver.exe");
		driver = new FirefoxDriver();
		changeDriverMangementSettings();
		return driver;
	}

	/**
	 * change DriverMangement Settings
	 * 
	 */
	private void changeDriverMangementSettings() {
		// -------------
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(global_setPageLoadTimeout, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(global_waitTimeInSeconds, TimeUnit.SECONDS);

		// -------------
	}

	/**
	 * choose a valid environment api - to run api service tests, local- to run
	 * tests on local machine, remote - to run tests on remote machine,
	 */
	public void initialization() {

		switch (global_environment) {

		case "api":
			initializeApiRequestAndResponseSpecs();
			break;

		case "local":
			initializeLocalDriver(Browsers.valueOf(global_browserName.toUpperCase()));
			initializeApiRequestAndResponseSpecs();
			break;

		case "remote":
			initializeRemoteDriver();
			initializeApiRequestAndResponseSpecs();
			break;
			
		case "mobile_local":
			/*initializeLocalDriver(Browsers.valueOf(global_browserName.toUpperCase()));
			initializeApiRequestAndResponseSpecs();*/
			setupMobileDriver();
			initializeApiRequestAndResponseSpecs();
			break;

		default:
			try {
				throw new Exception("Please choose a valid environment");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * Initialize Request Specs
	 */
	private void initializeApiRequestAndResponseSpecs() {

		// -----------
		global_specMap = new HashMap<String, RequestSpecification>();

		String[] arrSpecNames = global_specNames.split("#");

		for (int i = 0; i < arrSpecNames.length; i++) {
			global_specMap.put(arrSpecNames[i], mtdSpecConf(prop.getProperty(arrSpecNames[i])));
		}

		// -----------

		RequestSpecBuilder reqbuild = new RequestSpecBuilder();
		reqbuild.setBaseUri(global_baseuri); // "http://localhost"
//		reqbuild.setBaseUri("http://localhost"); // "http://localhost"
		reqbuild.setBasePath(global_basepath); // "/posts"
//		reqbuild.setBasePath("/posts"); // "/posts"
		if (global_baseport != 0)
			reqbuild.setPort(3000);
		requestWriter = new StringWriter();
		requestCapture = new PrintStream(new WriterOutputStream(requestWriter), true);
		reqbuild.addFilter(new RequestLoggingFilter(requestCapture));
		responseWriter = new StringWriter();
		responseCapture = new PrintStream(new WriterOutputStream(responseWriter), true);
		reqbuild.addFilter(new ResponseLoggingFilter(responseCapture));
		global_builder = reqbuild;
		global_request_spec = reqbuild.build();

	}

	/**
	 * Configure the RequestSpecification based on the input String configuration
	 * 
	 * @param specConfig
	 * @return
	 */
	private RequestSpecification mtdSpecConf(String specConfig) {
		RequestSpecification rspec;

		RequestSpecBuilder bilder = new RequestSpecBuilder();

		// System.out.println(specConfig);

		// Adding the request & Response Filters for logging
		requestWriter = new StringWriter();
		requestCapture = new PrintStream(new WriterOutputStream(requestWriter), true);
		bilder.addFilter(new RequestLoggingFilter(requestCapture));
		responseWriter = new StringWriter();
		responseCapture = new PrintStream(new WriterOutputStream(responseWriter), true);
		bilder.addFilter(new ResponseLoggingFilter(responseCapture));

		String[] arrSpecConfig = specConfig.split(",");

		Map<String, String> specConfMap = new HashMap<String, String>();

		for (int i = 0; i < arrSpecConfig.length; i++) {
			specConfMap.put(arrSpecConfig[i].split("::")[0].toLowerCase().trim(), arrSpecConfig[i].split("::")[1]);
		}

		Set<String> setSpecConf = specConfMap.keySet();

		for (Iterator<String> it = setSpecConf.iterator(); it.hasNext();) {
			String uriPart = it.next().toLowerCase().trim();
			// System.out.println(uriPart);
			// System.out.println(specConfMap.get(uriPart));

			/*
			 * if (uriPart.equalsIgnoreCase("baseuri") && specConfMap.get(uriPart) != "")
			 * bilder.setBaseUri(specConfMap.get(uriPart)); else if
			 * (uriPart.equalsIgnoreCase("port") && specConfMap.get(uriPart) != "")
			 * bilder.setPort(Integer.parseInt(specConfMap.get(uriPart))); else if
			 * (uriPart.equalsIgnoreCase("basepath") && specConfMap.get(uriPart) != "")
			 * bilder.setBasePath(specConfMap.get(uriPart));
			 */

			switch (uriPart) {

			case "baseuri":
				if (specConfMap.get(uriPart) != "")
					bilder.setBaseUri(specConfMap.get(uriPart));
				break;

			case "port":
				if (specConfMap.get(uriPart) != "")
					bilder.setPort(Integer.parseInt(specConfMap.get(uriPart)));
				break;

			case "basepath":
				if (specConfMap.get(uriPart) != "")
					bilder.setBasePath(specConfMap.get(uriPart));
				break;

			default:
				try {
					throw new Exception("Please enter specconfig properties as per standard.");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

		rspec = bilder.build();

		return rspec;

	}

	/**
	 * Get the Config Properties
	 */
	private void getConfigProperties() {
		// #region Environment App settings
		// prop.getProperty("browser"); // prop.getProperty("browser"); //
		// ConfigurationManager.
		global_environment = prop.getProperty("environment"); // ConfigurationManager.AppSettings["Environment"];
		global_waitTimeInSeconds = Long.parseLong(prop.getProperty("WaitTimeInSeconds")); // ConfigurationManager.AppSettings["WaitTimeInMinutes"];
		global_browserName = prop.getProperty("browser"); // ConfigurationManager.AppSettings["Browser"];
		global_driverPath = prop.getProperty("DriverPath"); // ConfigurationManager.AppSettings["DriverPath"];
		global_downloadPath = prop.getProperty("DownloadPath"); // ConfigurationManager.AppSettings["DownloadPath"];
		global_setPageLoadTimeout = Long.valueOf(prop.getProperty("PageLoadTimeout")); // ConfigurationManager.AppSettings["SetPageLoadTimeout"];

		global_applURL = prop.getProperty("applURL");
		global_remoteEnvironment = prop.getProperty("RemoteEnvironment"); // ConfigurationManager.AppSettings["RemoteEnvironment"];

		// #endregion
		global_gridBrowser = prop.getProperty("GridBrowser");
		global_gridbrowserVersion = prop.getProperty("GridBrowserVersion");
		global_gridPlatform = prop.getProperty("GridPlatform");
		global_gridCommandExecutionUri = prop.getProperty("GridCommandExecutionUri");

		// #region Browserstack settings
		global_remoteBSBrowser = prop.getProperty("BrowserStackRemoteBrowser"); // ConfigurationManager.AppSettings["RemoteBrowser"];
		global_remoteBSbrowserVersion = prop.getProperty("BrowserStackRemoteBrowserVersion"); // ConfigurationManager.AppSettings["RemoteBrowserVersion"];
		global_remoteBSPlatform = prop.getProperty("BrowserStackRemotePlatform");
		global_browserStackUser = prop.getProperty("BrowserStackUserName"); // ConfigurationManager.AppSettings.Get("BrowserStackUserName");
		global_browserStackpassword = prop.getProperty("BrowserStackPassword"); // ConfigurationManager.AppSettings.Get("BrowserStackPassword");
		global_browserStackCommandExecutionUri = prop.getProperty("BrowserStackCommandExecutionUri");
		// #endregion

		// #region Sauce labs Settings

		global_commandExecutionUri = prop.getProperty("CommandExecutionUri"); // ConfigurationManager.AppSettings["CommandExecutionUri"];
		global_remoteBrowser = prop.getProperty("RemoteBrowser"); // ConfigurationManager.AppSettings["RemoteBrowser"];
		global_remotebrowserVersion = prop.getProperty("RemoteBrowserVersion"); // ConfigurationManager.AppSettings["RemoteBrowserVersion"];
		global_remotePlatform = prop.getProperty("RemotePlatform"); // ConfigurationManager.AppSettings["RemotePlatform"];
		global_sauceLabsUserName = prop.getProperty("SauceLabsUserName"); // ConfigurationManager.AppSettings["SauceLabsUserName"];
		global_sauceLabsKey = prop.getProperty("SauceLabsUserPassword"); // ConfigurationManager.AppSettings["SauceLabsUserPassword"];
		// global_recordScreenshots = Convert.ToBoolean(prop.getProperty("browser"); //
		// ConfigurationManager.AppSettings["RecordScreenshots"]);
		// global_recordVideo = Convert.ToBoolean(prop.getProperty("browser"); //
		// ConfigurationManager.AppSettings["RecordVideo"]);
		global_remotescreenResolution = prop.getProperty("ScreenResolution"); // ConfigurationManager.AppSettings["ScreenResolution"];
		global_maxDuration = prop.getProperty("MaximumDuration"); // ConfigurationManager.AppSettings["MaximumDuration"];
		global_connectionString = prop.getProperty("ConnectionString");
		global_classForName = prop.getProperty("ClassForName");
		// api

		global_baseuri = prop.getProperty("baseuri");
		try {
			global_baseport = Integer.valueOf(prop.getProperty("baseport"));
		} catch (NumberFormatException e) {
			System.out.println("Error getting the 'global_baseport' from properties.");
			global_baseport = 0;
		}

		global_basepath = prop.getProperty("basepath");
		global_specNames = prop.getProperty("specnames");

		//APPIUM 
		global_application_name=prop.getProperty("application_name");
		global_resources_path=System.getProperty("user.dir") + prop.getProperty("resources_path");
		global_ipa_path=global_resources_path+prop.getProperty("ipa_path");
		global_apk_path=global_resources_path+prop.getProperty("apk_path");
		global_chrome_path=global_resources_path+prop.getProperty("chrome_path");
		global_chrome_mac_path=global_resources_path+prop.getProperty("chrome_mac_path");
		global_ie_path=global_resources_path+prop.getProperty("ie_path");
		global_properties_path=global_resources_path+prop.getProperty("properties_path");
		global_log4j_path=System.getProperty("user.dir") + prop.getProperty("log4j_path");
		global_platform_name=prop.getProperty("platform_name");
		global_platform_ios=prop.getProperty("platform_ios");
		global_patform_name_ios=prop.getProperty("patform_name_ios");
		global_app_Package=prop.getProperty("app_Package");
		global_app_Activity=prop.getProperty("app_Activity");
		
		global_mobileRunOn=prop.getProperty("RUN_ON");
		global_deviceType=prop.getProperty("deviceType");
		//Need to add other properties if required
		
		// #endregion

	}
	
	 public static HashMap<String,String> getPropValues(String file) {
	        InputStream inputStream;
	        HashMap<String,String> result = new HashMap<String, String>();

	        try {
	            Properties prop = new Properties();
	            String propFileName = file;
	           // inputStream = TestBase.class.getResourceAsStream(propFileName);
	            //inputStream = TestBase.class.getClassLoader().getResourceAsStream(propFileName);
	           // inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFileName);
	           // inputStream =   Thread.currentThread().getClass().getClassLoader().getResourceAsStream(propFileName);
	           // System.out.println(inputStream);
	            inputStream = new FileInputStream(
	            	//	"C:\\Users\\V.Kalluru\\workspace_demo\\TCOESeleniumFramework\\src\\test\\resources\\Configuration\\config.properties");
	            		System.getProperty("user.dir") + "/src/test/resources/Configuration/config.properties");
	            //inputStream = new FileInputStream(propFileName);
	            if (inputStream != null) {
	                prop.load(inputStream);
	            } else {
	                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
	            }
	            // get the property values
	            Set propNames = prop.stringPropertyNames();
	            Iterator<String> iterator = propNames.iterator();
	            while (iterator.hasNext())
	            {
	                String key = iterator.next();
	                result.put(key , prop.getProperty(key));
	            }

	            inputStream.close();


	        } catch (Exception e) {
	            System.out.println("Exception: " + e);
	        }
	        return result;
	    }
	 
	 public void setupMobileDriver() {
	        InitiateMDriver initiateDriver = new InitiateMDriver();
	        String deviceName_ = "", UDID_ = "", platformVersion_ = "";
	        String platform = global_configProperties.get("PLATFORM");

	        String platformName = platform; //String platformName = getPlatform();
	        ArrayList<ArrayList<String>> deviceDetails;

	        if (platform.equalsIgnoreCase("IOS") || platform.equalsIgnoreCase("ANDROID")) {
	            deviceDetails = getDeviceDetails(platformName);
	            deviceName_ = deviceDetails.get(0).get(0);
	            platformVersion_ = deviceDetails.get(0).get(1);
	            UDID_ = deviceDetails.get(0).get(2);

//	            System.out.println("UDID: "+UDID_);
//	            System.out.println("device Name: "+deviceName_);
//	            System.out.println("platform version: "+platformVersion_);

	            initiateDriver.InitiateDriverForMobile(deviceName_, UDID_, platformVersion_);
	      /*  String description = (getDescription(method).replace("@ru.yandex.qatools.allure.annotations.Stories(value=[", "")).replace(")", "").trim();
	        reportInfo("*********************** Appium Test is running on an "+platform+" - "+deviceName_+" device *****************************");
	        reportInfo("***********************************************************************************");
	        reportInfo(getClass().getSimpleName() + ", Starting Test: '" + method.getName() + "' with Description: '" + description + "'");
	        reportInfo("===================================================================================");
	        reportInfo("***********************************************************************************");
	        reportInfo("Test Name : " + method.getName());
	        reportInfo("Test Description : " + description);
	        reportInfo("===================================================================================");
*/
	    } 	else if (platform.equalsIgnoreCase("BROWSER")){
         initiateDriver.InitiateDriverForBrowser();
        /* String description = (getDescription(method).replace("@ru.yandex.qatools.allure.annotations.Stories(value=[", "")).replace(")", "").trim();
         reportInfo("*********************** Selenium Test is running on an "+platform+" *****************************");
         reportInfo("***********************************************************************************");
         reportInfo(getClass().getSimpleName() + ", Starting Test: '" + method.getName() + "' with Description: '" + description + "'");
         reportInfo("===================================================================================");
         reportInfo("***********************************************************************************");
         reportInfo("Test Name : " + method.getName());
         reportInfo("Test Description : " + description);
         reportInfo("===================================================================================");
*/
     }       
	        
	        else if (platform.equalsIgnoreCase("BROWSER")){
	            initiateDriver.InitiateDriverForBrowser();
	           /* String description = (getDescription(method).replace("@ru.yandex.qatools.allure.annotations.Stories(value=[", "")).replace(")", "").trim();
	            reportInfo("*********************** Selenium Test is running on an "+platform+" *****************************");
	            reportInfo("***********************************************************************************");
	            reportInfo(getClass().getSimpleName() + ", Starting Test: '" + method.getName() + "' with Description: '" + description + "'");
	            reportInfo("===================================================================================");
	            reportInfo("***********************************************************************************");
	            reportInfo("Test Name : " + method.getName());
	            reportInfo("Test Description : " + description);
	            reportInfo("===================================================================================");
*/
	        }

	        /*  String url = global_configProperties.get("mURL");
	            appiumDriver = initiateDriver.getAppiumDriver();
	           Base.appiumDriver = appiumDriver; commented this line on March 26 2019 by Suneel.KV
	           reportInfo("Appium started with URL: " + url); */

	    }
	 
	 /**
	     * This method will get the platform that system need to run on.
	     *
	     * @return platform name it will return
	     */
	    protected String getPlatform()
	    {
	        //String value = System.getProperty(AutomationConstants.AUTOMATION_PLATFORM_NAME);
	        String value = System.getProperty(global_platform_name);
	        if (value == null || value.isEmpty())
	        {
	            FileInputStream fis;
	            try
	            {
	                /*fis = new FileInputStream(AutomationConstants.AUTOMATION_PROPERTIES_PATH);*/
	            	fis = new FileInputStream(global_properties_path);
	                Properties prop = new Properties();
	                prop.load(fis);
	               // value = prop.getProperty(AutomationConstants.AUTOMATION_PLATFORM_NAME);
	                value = prop.getProperty(global_platform_name);
	            } catch (FileNotFoundException e)
	            {
	                e.printStackTrace();
	            } catch (IOException e)
	            {
	                e.printStackTrace();
	            }
	        }
	        return value;
	    }
	    
	    /**
	     * This method will get the device details runtime
	     *
	     * @param platform - input sting required on which platform we need to get the device details
	     * @return device name
	     * @return device OS version
	     * @return device UDID
	     */
	    protected ArrayList<ArrayList<String>> getDeviceDetails(String platform)
	    {
	        ArrayList<ArrayList<String>> deviceDetail = new ArrayList<ArrayList<String>>();
	        ArrayList<String> deviceDetails = new ArrayList<String>();
	        Process p = null;
	        BufferedReader in = null;
	        String osVersion = null;
	        if (platform.equalsIgnoreCase("ios"))
	        {
	            String udid = getUDID("", false);
	            try
	            {
	                p = new ProcessBuilder("/bin/bash", "-l", "-c", "instruments -s devices").start();
	                try
	                {
	                    p.waitFor();
	                } catch (Exception e)
	                {}
	                in = new BufferedReader(new InputStreamReader(p.getInputStream()));
	                while ((osVersion = in.readLine()) != null)
	                {
	                    deviceDetails.add(osVersion.trim());

	                }
	            } catch (IOException e)
	            {}

	            for (String s : deviceDetails)
	            {
	                if(s.contains("(null)")){
	                } else if (s.contains(udid))
	                {
	                    osVersion = s.replaceAll(udid, "").replaceAll("\\[", "").replaceAll("\\]", "").trim();
	                    String[] list = osVersion.split(" \\(");
	                    deviceDetails = new ArrayList<String>();
	                    String dUdid, dName, dVersion = null;
	                    dName = list[0].trim();
	                    dVersion = list[1].replaceAll("\\)", "").trim();
	                    dUdid = udid.trim();
	                    deviceDetails.add(dName);
	                    deviceDetails.add(dVersion);
	                    deviceDetails.add(dUdid);
	                    deviceDetail.add(deviceDetails);
	                    break;
	                }
	            }
	        }
	        else
	        {
	            try
	            {
	                String OS = System.getProperty("os.name").toLowerCase();
	                if (OS.startsWith("windows"))
	                {
	                    p = new ProcessBuilder("cmd.exe", "/C", "adb devices -l").start();
	                }
	                else if (OS.startsWith("mac os"))
	                {
	                    p = new ProcessBuilder("/bin/bash", "-l", "-c", "adb devices -l").start();
	                }
	                try
	                {
	                    p.waitFor();
	                } catch (Exception e)
	                {}
	                in = new BufferedReader(new InputStreamReader(p.getInputStream()));
	                while ((OS = in.readLine()) != null)
	                {
	                    if ( !OS.startsWith("List of devices attached"))
	                    {
	                        deviceDetails.add(OS.trim());
	                    }
	                }
	                for (String s : deviceDetails)
	                {
	                    if ( !s.equals(""))
	                    {
	                        ArrayList<String> deviceDetails1 = new ArrayList<String>();
	                        String[] details = null;
	                        String id = null, osV = null;
	                        details = s.split("model:");
	                        details = details[1].split(" ");// device Name
	                        deviceDetails1.add(details[0].trim());
	                        details = s.split(" ");
	                        id = details[0].trim();
	                        osV = getUDID(id, true);
	                        deviceDetails1.add(osV);// device osVersion
	                        deviceDetails1.add(id);// device UDID
	                        deviceDetail.add(deviceDetails1);
	                    }
	                }
	            } catch (IOException e)
	            {}
	        }
	        return deviceDetail;
	    }
	    
	    protected String getUDID(String udid, boolean android)
	    {
	        Process p = null;
	        String deviceName = null;
	        BufferedReader in = null;
	        if ( !android)
	        {
	            try
	            {
	                p = new ProcessBuilder("/bin/bash", "-l", "-c", "idevice_id -l").start();
	                try
	                {
	                    p.waitFor();
	                } catch (Exception e)
	                {}
	                in = new BufferedReader(new InputStreamReader(p.getInputStream()));
	                deviceName = in.readLine().trim();
	            } catch (IOException e)
	            {}
	        }
	        else
	        {
	            try
	            {
	                String OS = System.getProperty("os.name").toLowerCase();
	                String cmd = "adb -s " + udid.trim() + " shell getprop ro.build.version.release";
	                if (OS.startsWith("windows"))
	                {
	                    p = new ProcessBuilder("cmd.exe", "/C", cmd).start();
	                }
	                else if (OS.startsWith("mac os"))
	                {
	                    p = new ProcessBuilder("/bin/bash", "-l", "-c", cmd).start();
	                }
	                try
	                {
	                    p.waitFor();
	                } catch (Exception e)
	                {}
	                in = new BufferedReader(new InputStreamReader(p.getInputStream()));
	                deviceName = in.readLine().trim();
	            } catch (IOException e)
	            {}
	        }
	        return deviceName;
	    }
	
}

