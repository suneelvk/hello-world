package org.suneel.base;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import static org.suneel.base.TestBase.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class InitiateMDriver {

	private RemoteWebDriver driver;
	private AppiumDriver appiumDriver;
	public HashMap<String, String> getProperties;
	String OSName, runOn, platform, url, mUrl, browser;
	String webURL;

	public InitiateMDriver() {
		
		

		getProperties = getPropValues("config.properties");
		webURL = System.getProperty("WEB_URL") == null ? getProperties.get("WEB_URL") : System.getProperty("WEB_URL");
		runOn = System.getProperty("runOn") == null ? getProperties.get("RUN_ON") : System.getProperty("runOn");
		platform = System.getProperty("platform") == null ? getProperties.get("PLATFORM")
				: System.getProperty("platform");
		url = System.getProperty("url") == null ? getProperties.get("SELENIUMSERVERURL") : System.getProperty("url");
		mUrl = System.getProperty("mUrl") == null ? getProperties.get("mURL") : System.getProperty("mUrl");
		browser= System.getProperty("BROWSER") == null ? getProperties.get("BROWSER") : System.getProperty("browser");
	}

	public void InitiateDriverForMobile(String deviceName_, String UDID_, String platformVersion_) {
		try {

			if (platform.equalsIgnoreCase("ANDROID") && runOn.equalsIgnoreCase("ANDROID_APP")) {
				appiumDriver = new AndroidDriver(new URL(mUrl),
						getBrowserCapabilitiesForMobile(browser, runOn, deviceName_, UDID_, platformVersion_));
				appiumDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			} 
			else if (platform.equalsIgnoreCase("ANDROID") && runOn.equalsIgnoreCase("ANDROID_APP_PKG")) {
				appiumDriver = new AndroidDriver(new URL(mUrl),
						getBrowserCapabilitiesForMobile(browser, runOn, deviceName_, UDID_, platformVersion_));
				appiumDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			}
			else if (platform.equalsIgnoreCase("ANDROID") && runOn.equalsIgnoreCase("ANDROID_WEB_APP")) {
				appiumDriver = new AndroidDriver(new URL(mUrl),
						getBrowserCapabilitiesForMobile(browser, runOn, deviceName_, UDID_, platformVersion_));
				appiumDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			}
			else if (platform.equalsIgnoreCase("IOS") && runOn.equalsIgnoreCase("IOS_APP")) {
				appiumDriver = new IOSDriver(new URL(mUrl),
						getBrowserCapabilitiesForMobile(browser, runOn, deviceName_, UDID_, platformVersion_));
				appiumDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			}
			
			TestBase.appiumDriver = appiumDriver;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void InitiateDriverForBrowser() {
		try {
			getProperties = getPropValues("config.properties");
			String runOn = System.getProperty("runOn") == null ? getProperties.get("RUN_ON")
					: System.getProperty("runOn");
			String platform = System.getProperty("platform") == null ? getProperties.get("PLATFORM")
					: System.getProperty("platform");
			//String url = System.getProperty("url") == null ? getProperties.get("SELENIUMSERVERURL") : System.getProperty("url");
			String url = System.getProperty("url") == null ? getProperties.get("WEB_URL")
					: System.getProperty("url");
			String mUrl = System.getProperty("mUrl") == null ? getProperties.get("mURL") : System.getProperty("mUrl");
			String browser = null;
			OSName = getOsName();

			if (OSName.toLowerCase().contains("windows")) {
				if (runOn.equalsIgnoreCase("WEBSITE")) {
					browser = System.getProperty("browser") == null ? getProperties.get("BROWSER")
							: System.getProperty("browser");
					System.out.println(url);
					getBrowserCapabilitiesForBrowsers(browser, runOn, platform);
					driver.navigate().to(url);
					System.out.println("Driver is: " + driver);
					driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				}
			} else if (OSName.contains("Mac") && runOn.equalsIgnoreCase("WEBSITE")) {

				browser = System.getProperty("browser") == null ? getProperties.get("BROWSER")
						: System.getProperty("browser");
				System.out.println(url);
				getBrowserCapabilitiesForBrowsers(browser, runOn, platform);
				driver.navigate().to(url);
				System.out.println("Driver is: " + driver);
				driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			}
			
			TestBase.driver = driver;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public RemoteWebDriver getDriver() {
		if (driver == null)
			throw new RuntimeException("Driver has not been Instantiated");

		return driver;
	}

	public AppiumDriver getAppiumDriver() {
		if (appiumDriver == null)
			throw new RuntimeException("Driver has not been instantiated");

		return appiumDriver;
	}

	private DesiredCapabilities getBrowserCapabilitiesForMobile(String browser, String runOn, String deviceName_,
			String UDID_, String platformVersion_) {
		DesiredCapabilities capabilities = null;
		String appName = System.getProperty("appName") == null ? getProperties.get("AppName")
				: System.getProperty("appName");
		String appPath = System.getProperty("appPath") == null ? getProperties.get("AppPath")
				: System.getProperty("appPath");

		try {
			if (runOn.equalsIgnoreCase("ANDROID_APP")) {

				capabilities = new DesiredCapabilities();
				capabilities.setCapability("deviceName", deviceName_);
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("app", global_apk_path); // capabilities.setCapability("app",
																	// AutomationConstants.AUTOMATION_APK_PATH);
				capabilities.setCapability("udid", UDID_);
				capabilities.setCapability("noReset", true);
				capabilities.setCapability("autoGrantPermissions", true);
			} else if (runOn.equalsIgnoreCase("ANDROID_APP_PKG")) {

				capabilities = new DesiredCapabilities();
				capabilities.setCapability("deviceName", deviceName_);
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("appPackage", global_app_Package);
				capabilities.setCapability("appActivity", global_app_Activity);
				capabilities.setCapability("udid", UDID_);
				capabilities.setCapability("noReset", true);
				capabilities.setCapability("autoGrantPermissions", true);
			} //ANDROID_WEB_APP
			else if (runOn.equalsIgnoreCase("ANDROID_WEB_APP")) {

				capabilities = new DesiredCapabilities();
				capabilities.setCapability("deviceName", deviceName_);
				capabilities.setCapability("platformName", "Android");
//				capabilities.setCapability("appPackage", global_app_Package);
//				capabilities.setCapability("appActivity", global_app_Activity);
				capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, browser);
				capabilities.setCapability("udid", UDID_);
				capabilities.setCapability("noReset", true);
				capabilities.setCapability("autoGrantPermissions", true);
			} 
			else if (runOn.equalsIgnoreCase("IOS_APP")) {

				capabilities = new DesiredCapabilities();
				capabilities.setCapability("automationName", global_platform_ios);
				capabilities.setCapability("platformName", global_patform_name_ios);
				capabilities.setCapability("app", global_ipa_path);
				// capabilities.setCapability("automationName",
				// AutomationConstants.AUTOMATION_PLATFORM_IOS);
				// capabilities.setCapability("platformName",
				// AutomationConstants.AUTOMATION_PATFORM_NAME_IOS);
				// capabilities.setCapability("app", AutomationConstants.AUTOMATION_IPA_PATH);
				capabilities.setCapability("platformVersion", platformVersion_);
				capabilities.setCapability("deviceName", deviceName_);
				capabilities.setCapability("udid", UDID_);
				capabilities.setCapability("startIWDP", true);
				capabilities.setCapability("noReset", true);
//                capabilities.setCapability("xcodeOrgId", "46WHRWP273");
//                capabilities.setCapability("xcodeSigningId", "iPhone Developer");
				// capabilities.setCapability("usePrebuiltWDA", false);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return capabilities;
	}

	/*
	 * This code will pick up the desktop OS whether running on Windows or MAC
	 * desktop
	 */
	public String getOsName() {
		String OS = null;
		if (OS == null) {
			OS = System.getProperty("os.name");
		}
		return OS;
	}

	private DesiredCapabilities getBrowserCapabilitiesForBrowsers(String browser, String runOn, String platform) {
		DesiredCapabilities capabilities = null;

		try {
			if (runOn.equalsIgnoreCase("WEBSITE") && browser.equalsIgnoreCase("Firefox")) {
				capabilities = DesiredCapabilities.firefox();
				capabilities.setBrowserName("firefox");
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capabilities.setPlatform(Platform.ANY);
			} else if (runOn.equalsIgnoreCase("WEBSITE") && browser.equalsIgnoreCase("IE")) {
				// System.setProperty("webdriver.ie.driver",
				// AutomationConstants.AUTOMATION_IE_PATH);
				System.setProperty("webdriver.ie.driver", global_ie_path);
				driver = new InternetExplorerDriver();
				driver.navigate().to(webURL);
//                capabilities.setBrowserName("internet explorer");
//                capabilities.setPlatform(Platform.WINDOWS);
//                capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//                capabilities.setCapability("ie.ensureCleanSession", true);
			} else if (runOn.equalsIgnoreCase("WEBSITE") && browser.equalsIgnoreCase("Chrome")
					&& OSName.contains("Windows")) {
				System.out.println("launching Chrome browser on Windows");
				// System.setProperty("webdriver.chrome.driver",
				// AutomationConstants.AUTOMATION_CHROME_PATH);
				System.setProperty("webdriver.chrome.driver", global_chrome_path);
				driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.navigate().to(webURL);
			} else if (runOn.equalsIgnoreCase("WEBSITE") && browser.equalsIgnoreCase("Chrome")
					&& OSName.contains("Mac")) {
				/*
				 * This code is written to open PingID MAC app to authenticate Ping to open
				 * Shell website. But commented since Apple script is needed here on MAC
				 */
//
//                reportInfo("Running AppleScript to pick the passcode from PingID iMac app");
//                //in mac oxs
//                String command = "sh /Users/shell/Desktop/ping.sh";
//                StringBuffer output = new StringBuffer();
//
//                Process p;
//                try {
//                    p = Runtime.getRuntime().exec(command);
//                    p.waitFor();
//                    BufferedReader reader =
//                            new BufferedReader(new InputStreamReader(p.getInputStream()));
//
//                    String line = "";
//                    while ((line = reader.readLine())!= null) {
//                        output.append(line + "\n");
//                    }
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                reportInfo("End of Apple script");
//                delay(30);

				System.out.println("launching Chrome browser on MAC");
				// System.setProperty("webdriver.chrome.driver",
				// AutomationConstants.AUTOMATION_CHROME_PATH_MAC);
				System.setProperty("webdriver.chrome.driver", global_chrome_mac_path);

				driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.navigate().to(webURL);

			} else {
				// default is firefox
				capabilities = DesiredCapabilities.firefox();
				capabilities.setBrowserName("firefox");
				capabilities.setPlatform(Platform.ANY);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return capabilities;
	}

}
