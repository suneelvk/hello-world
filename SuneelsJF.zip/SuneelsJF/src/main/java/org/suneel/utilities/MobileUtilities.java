package org.suneel.utilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.suneel.base.InitiateMDriver;
import org.suneel.base.TestBase;
import org.testng.Assert;
/*import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;
import loginpage.LoginPageObjRepo;*/

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;


public class MobileUtilities {

    public static long wait = 60;
    WebDriver driver;
    RemoteWebDriver driver1;
    //public static AppiumDriver<MobileElement> appiumDriver;// please check again commented after import in to MobileUtilities
    public AppiumDriver<MobileElement> appiumDriver;
    protected static Logger log = Logger.getLogger(MobileUtilities.class);
    private HashMap<String,String> getProperties;
    //private static LoginPageObjRepo addLubeRpo; // please check again commented after import in to MobileUtilities



    public int TIMEOUT = 2;


    public MobileUtilities(AppiumDriver<MobileElement> appiumDriver) {
    	this.appiumDriver = appiumDriver;
	}


	/*
     * This method checks if a given element is present on web page
     *
     * @param locator - element the user wants to check existence of
     * @return boolean - returns true if element is present, false otherwise
     */
    protected boolean isElementPresent(MobileElement locator)
    {
        List<MobileElement> ae = appiumDriver.findElements(getSelector(locator));
        return (ae.size() > 0);
    }


    /*
     * This method checks if a given element is present on web page
     *
     * @param locator - element the user wants to check existence of
     * @return boolean - returns true if element is present, false otherwise
     */

    protected List<MobileElement> findElements(MobileElement locator)
    {
        return appiumDriver.findElements(getSelector(locator));
    }


    /*
     *
     * This method will waits for the entire time the browser is opened. This means that any search for elements on the
     * page could take the time the implicit wait is set for.
     *
     **/
    protected void setSleep(int seconds)
    {
        appiumDriver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
    }


    /*
     *
     * This method will read the properties from the shell.properties file which is located under src/test/properties
     * path.
     *
     * @param input will be the key value
     * @return it will return the key pair value
     * @return String - it will return the string value of the KeyPair
     *
     **/
/*    public String getProperty(String keyValue)
    {
        String value = null;
        FileInputStream file;
        try
        {
            file = new FileInputStream(AutomationConstants.AUTOMATION_PROPERTIES_PATH);
            Properties prop = new Properties();
            prop.load(file);
            value = prop.getProperty(keyValue);
        } catch (FileNotFoundException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return value;
    }*/


//    protected void moveToElement(MobileElement sourceElement, MobileElement targetElement)
//    {
//        TouchAction act = new TouchAction(appiumDriver);
//        act.press(sourceElement).moveTo(targetElement).release().perform();
//        delay(2);
//    }

    /*
     * This method will get the description from the test method in run time.
     *
     * @param method - method java method reflector
     *
     */
    protected String getDescription(Method method) {
        Annotation[] a = method.getAnnotations();
        return a[0].toString().split("description=")[1].split(", retryAnalyzer=")[0].split(",")[0].trim();
    }


    /*
     * Sets the value of an input field, as though you typed it in; like type() but without clearing the input
     * or doing a 'click' (needed for file uploads, since Selenium won't work with native OS file browser
     * dialog)
     *
     * <p>
     * Can also be used to set the value of combo boxes, check boxes, etc. In these cases, value should be the value of
     * the option selected, not the visible text.
     * </p>
     *
     * @param locator an <a href="#locators">element locator</a>
     * @param value the value to type
     */
    protected void sendKeys(MobileElement locator, String text)
    {
        locator.sendKeys(text);
    }


    /*
     * Gets the text of an element. This works for any element that contains text. This command uses either the
     * textContent (Mozilla-like browsers) or the innerText (IE-like browsers) of the element, which is the
     * rendered text shown to the user.
     *
     * @param locator an <a href="#locators">element locator</a>
     * @return the text of the element
     */
    protected String getText(MobileElement locator)
    {
        return locator.getText();
    }


    /*
     * Select an option from a drop-down by index.
     *
     * <li><strong>index</strong>=<em>index</em>: matches an option based on its index (offset from zero).
     * <ul class="first last simple">
     * <li>index=2</li>
     *
     * @param selectLocator an <a href="#locators">element locator</a> identifying a drop-down menu
     * @param optionLocator an option locator (a label by default)
     */
    protected void selectByIndex(MobileElement locator, int index)
    {
        Select se = new Select(locator);
        se.selectByIndex(index);
    }


    /*
     * This method uses the Selenium webDriver object to click on the element
     *
     * @param locator - the element the user want to click
     */
    protected void click(MobileElement locator,String message)
    {
        //reportInfo(message);
        locator.click();
    }


    /*
     * This method will Assert the expected value equals the actual value
     *
     * @param expectedValue String
     * @param actualValue String
     */
    protected void assertTrue(String expectedValue, String actualValue)
    {
        if (expectedValue.contentEquals(actualValue))
        {
           // reportPass("Passed: --> expected { " + expectedValue + " } Matches actual --> { " + actualValue + " }");
            Assert.assertTrue(expectedValue.trim().contentEquals(actualValue.trim()), " Expected Value: " + expectedValue + " Actual Value: " + actualValue);
        }
        else
        {
           // reportFail("Failed: --> expected { " + expectedValue + " } Not matches with actual --> { " + actualValue + " }");
            Assert.assertTrue(expectedValue.trim().contentEquals(actualValue.trim()), " Expected Value: " + expectedValue + " Actual Value: " + actualValue);
        }
    }


    /*
     * Assert the expected value equals the actual value message is added to describe what is being compared for logs
     *
     * @param expectedValue String
     * @param actualValue String
     */
    protected void assertEquals(String expectedValue, String actualValue)
    {
        if (expectedValue.trim().contentEquals(actualValue.trim()))
        {
           // reportPass("Passed: --> expected { " + expectedValue + " } Equals actual --> { " + actualValue + " }");
            Assert.assertEquals(expectedValue.trim(), actualValue.trim());
        }
        else
        {
           // reportFail("Failed: --> expected { " + expectedValue + " } Not equals with actual --> { " + actualValue + " }");
            Assert.assertEquals(expectedValue.trim(), actualValue.trim());
        }
    }

    /*
     * This method will swipe the page Up.
     *
     * @param pixcel need to scroll
     * @param Input must be the integer value.
     */
//    protected void swipeUpInAndroid(int value) {
//        //AndroidDriver<MobileElement> andDriver = (AndroidDriver<MobileElement>) appiumDriver;
//        for (int i = 0; i < value; i++) {
//            Dimension size = appiumDriver.manage().window().getSize();
//            int starty = (int) (size.height * 0.40);
//            int endy = (int) (size.height * 0.10);
//            int startx = size.width / 2;
//            appiumDriver.swipe(startx, starty, startx, endy, 3000);
//        }
//        delay(TIMEOUT);
//    }


    /*
     * This method will swipe the page Down.
     *
     * @param pixcel need to scroll
     * @param Input must be the integer value.
     */
//    protected void swipeDownInAndroid(int value) {
//        AndroidDriver<MobileElement> andDriver = (AndroidDriver<MobileElement>) appiumDriver;
//        for (int i = 0; i < value; i++) {
//            Dimension size = andDriver.manage().window().getSize();
//            int starty = (int) (size.height * 0.80);
//            int endy = (int) (size.height * 0.20);
//            int startx = size.width / 2;
//            andDriver.swipe(startx, endy, startx, starty, 3000);
//        }
//        delay(TIMEOUT);
//    }

    public void scrollDown(){

        JavascriptExecutor js = appiumDriver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "down");
        js.executeScript("mobile: scroll", scrollObject);
    }

    public void scrollUp(){

        JavascriptExecutor js = appiumDriver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "up");
        js.executeScript("mobile: scroll", scrollObject);
    }
    
   

    public boolean swipeToDirection_iOS_XCTest(MobileElement el, String direction) {
        try {
            IOSDriver iosDriver = (IOSDriver) appiumDriver;
            JavascriptExecutor js = iosDriver;
            HashMap<String, String> swipeObject = new HashMap<String, String>();
            if (direction.equals("d")) {
                swipeObject.put("direction", "down");
            } else if (direction.equals("u")) {
                swipeObject.put("direction", "up");
            } else if (direction.equals("l")) {
                swipeObject.put("direction", "left");
            } else if (direction.equals("r")) {
                swipeObject.put("direction", "right");
            }
            swipeObject.put("element", el.getId());
            js.executeScript("mobile:swipe", swipeObject);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    /*
     * This method will swipe the page Up.
     *
     * @param pixcel need to scroll
     * @param Input must be the integer value.
     */
//    protected void swipeUp(int value)
//    {
//        //AndroidDriver<MobileElement> driver = (AndroidDriver<MobileElement>)appiumDriver;
//        for (int i = 0; i < value; i++)
//        {
//            Dimension size = appiumDriver.manage().window().getSize();
//            int starty = (int)(size.height * 0.40);
//            int endy = (int)(size.height * 0.10);
//            int startx = size.width / 2;
//            appiumDriver.swipe(startx, starty, startx, endy, 3000);
//        }
//        delay(TIMEOUT);
//    }


    /*
     * This method will swipe the page Down.
     *
     * @param pixcel need to scroll
     * @param Input must be the integer value.
     */
//    protected void swipeDown(int value)
//    {
//        // AndroidDriver<MobileElement> driver = (AndroidDriver<MobileElement>)appiumDriver;
//        for (int i = 0; i < value; i++)
//        {
//            Dimension size = appiumDriver.manage().window().getSize();
//            int starty = (int)(size.height * 0.80);
//            int endy = (int)(size.height * 0.20);
//            int startx = size.width / 2;
//            appiumDriver.swipe(startx, endy, startx, starty, 3000);
//        }
//        delay(TIMEOUT);
//    }


    /*
     * Assert the element is present
     *
     * @param locator
     * @param message - print the elementName which is defined by the user
     */
    protected void assertElementExist(MobileElement locator, String message,String elementType)
    {
        if (isElementVisible(locator))
        {
            //reportPass(elementType + " is located on the page as Expected. Hence "+message);
            Assert.assertTrue(isElementVisible(locator));
        }
        else
        {
           // reportFailInWebView(elementType + " was not located on the page");
            Assert.assertTrue(isElementVisible(locator));
        }
    }


    /*
     * Gets the value of an element attribute. The value of the attribute may differ across browsers (this is the case
     * for the "style" attribute, for example).
     *
     * @param locator an element locator followed by an @ sign and then the name of the attribute, e.g. "foo@bar"
     * @return the value of the specified attribute
     */
    protected String getAttribute(MobileElement locator, String name)
    {
        return locator.getAttribute(name);
    }


    /*
     * This method will blind wait (this method is useful while running in grid)
     *
     * @param seconds - seconds to wait
     */
    protected void delay(long seconds)
    {
        try
        {
            TimeUnit.SECONDS.sleep(seconds);
        } catch (InterruptedException e)
        {}
    }


    /*
     * This method will return the "Point" object.
     * If you want to get the exact "x" and "y" coordinates of the element then use "getLocation()" method.
     *
     * @param webelement - locator to get the coordinates
     * @return the "x" and "y" coordinates :
     **/
    protected void getLocation(MobileElement locator)
    {
        locator.getLocation();
    }


    /*
     * This method will returns the selector type that need to use
     *
     * @param locator - locater type
     * @return By - Selenium By
     */
    private By getSelector(MobileElement locator)
    {
        String value = locator.toString();
        if (value.contains("xpath: "))
        {
            String[] info = locator.toString().split("xpath: ");
            String e = info[1];
            info = e.substring(0, info[1].trim().length() - 1).split("- ");
            e = info[0].replaceAll("\"", "");
            return By.xpath(e);
        }
        else if (value.contains("id: "))
        {
            String[] info = locator.toString().split("id: ");
            String e = info[1];
            info = e.substring(0, info[1].trim().length() - 1).split("- ");
            e = info[0].replaceAll("\"", "");
            return By.xpath(e);
        }
        else
        {
            String[] info = locator.toString().split("xpath: ");
            String e = info[1];
            info = e.substring(0, info[1].trim().length() - 1).split("- ");
            e = info[0].replaceAll("\"", "");
            return By.xpath(e);
        }
    }


    /*
     * Determines if the specified element is visible. An element can be rendered invisible by setting the
     * "visibility" property to "hidden", or the "display" property to "none", either for the element itself or
     * one if its ancestors.
     *
     * @param locator - Mobile element locator
     * @return true if the specified element is visible, false otherwise
     */
    protected boolean isElementVisible(MobileElement locator)
    {
        try
        {
            (new WebDriverWait(appiumDriver, TIMEOUT)).until(ExpectedConditions.visibilityOf(locator));
            return true;
        } catch (Exception e)
        {
            return false;
        }
    }

    /*
 * Determines if the specified element is visible. An element can be rendered invisible by setting the
 * "visibility" property to "hidden", or the "display" property to "none", either for the element itself or
 * one if its ancestors.
 *
 * @param locator - Mobile element locator
 * @return true if the specified element is visible, false otherwise
 */
    protected boolean isWebElementVisible(WebElement locator)
    {
        try
        {
            (new WebDriverWait(appiumDriver, TIMEOUT)).until(ExpectedConditions.visibilityOf(locator));
            return true;
        } catch (Exception e)
        {
            return false;
        }
    }


    protected boolean isElementVisible(MobileElement locator, int timeoutInSeconds)
    {
        try
        {
            (new WebDriverWait(appiumDriver, timeoutInSeconds)).until(ExpectedConditions.visibilityOf(locator));
            return true;
        } catch (Exception e)
        {
            return false;
        }
    }


    /*
     * This method will Scrolls the window Up for iOS operating system.
     *
     */
    protected void scrollUpJS()
    {
        JavascriptExecutor js = appiumDriver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "up");
        js.executeScript("mobile: scroll", scrollObject);
        delay(1);
    }


    /*
     * This method will Scrolls the window Down for iOS operating system.
     *
     */
    protected void scrollDownJS()
    {
        JavascriptExecutor js = appiumDriver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "down");
        js.executeScript("mobile: scroll", scrollObject);
        delay(1);
    }

    protected void scrollRightJS()
    {
        JavascriptExecutor js = appiumDriver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "right");
        js.executeScript("mobile: scroll", scrollObject);
        delay(1);
    }

    protected void scrollLeftJS()
    {
        JavascriptExecutor js = appiumDriver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "left");
        js.executeScript("mobile: scroll", scrollObject);
        delay(1);
    }

    protected void scrollScreenDown(){

        Dimension dimensions = appiumDriver.manage().window().getSize();
        Double screenHeightStart = dimensions.getHeight() * 0.8;
        int h1 = screenHeightStart.intValue();
        Double screenHeightEnd = dimensions.getHeight() * 0.2;
        int h2 = screenHeightEnd.intValue();
        new TouchAction(appiumDriver).press(PointOption.point(0, h1)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).moveTo(PointOption.point(0,-h2)).perform();

    }

    /*
     * Determines if the specified element is visible. An element can be rendered invisible by setting the
     * "visibility" property to "hidden", or the "display" property to "none", either for the element itself or
     * one if its ancestors.
     *
     * @param locator Mobile element locator, click action will be based on the element presence on the screen.
     * @param boolean value if click event if true locator will be clicked, if false locator will not be clicked.
     *
     * @return true if the specified element is visible, false otherwise
     */
    protected boolean isVisibleClick(MobileElement locator, boolean click)
    {
        boolean flag = false;
        try
        {
            flag = locator.isDisplayed();
        } catch (Exception e)
        {}
        if (flag)
        {
            if (click)
            {
                locator.click();
            }
        }
        return flag;
    }


    /*
     * This method will return the current system time in user defined format.
     *
     * @return String - system time
     */
    protected String getSystemTime(String timeFormat)
    {
        // SimpleDateFormat sdf = new SimpleDateFormat("h:mm a");
        SimpleDateFormat sdf = new SimpleDateFormat(timeFormat);
        return sdf.format(new Date());
    }


    /*
     * This method will return the current system date in user defined format.
     *
     * @return String - system date
     */
    protected String getSystemDate(String dateFormat)
    {
        // SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy");
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        return sdf.format(new Date());
    }


    /*
     * This method will check the presence of the element on the page
     *
     * @param locator need to check
     * @param message will print in the console and Extent reports
     */
    protected void checkElement(MobileElement locator, String message)
    {
        if (isVisibleClick(locator, false))
        {
           // reportPass(message.trim() + " is displaying as Expected");
            Assert.assertTrue(true, message.trim() + " is displaying as Expected");
        }
        else
        {
           // reportFail(message.trim() + " was Not displaying as Expected");
        	Assert.assertTrue(false, message.trim() + " was not displaying as Expected");
        }
    }


    /*
     * This method uses the Selenium driver object to click on the Mobile Element, clear the field and send the text in
     * to the locator
     *
     * @param locator - the element the user want to send the text
     * @param text - Character sequence need to send to the locator
     */
    protected void type(MobileElement locator, String text,String message)
    {
        locator.click();
        locator.clear();
        reportInfo(message);
        locator.setValue(text);
    }

    protected void typeUsingKeyboard(MobileElement locator,String data){

        String number = "";
        String letter = "";
        String symbol = "";
        String whitespace = "";

        locator.click();
        JavascriptExecutor js = appiumDriver;
        js.executeScript("keyboard().typeString('K')");
        switchToNativeView();
        js.executeScript("keyboard().typeString('K')");

        for (int i = 0; i < data.length(); i++){
            char a = data.charAt(i);
            appiumDriver.findElementByXPath("//XCUIElementTypeButton[@name=\"shift\"]");
            if (Character.isDigit(a))
            {
                //number = number + a;
                appiumDriver.findElementByXPath("(//XCUIElementTypeKey[@name=\"more\"])[1]");
                appiumDriver.findElementByAccessibilityId((Character.toString(a)));
                continue;
            }

            if(Character.isLetter(a))
            {
                letter = letter + a;
                //appiumDriver.findElementByXPath("(//XCUIElementTypeKey[@name=\"more\"])[1]");
                appiumDriver.findElementByAccessibilityId("K");
            }
            else
            {
                symbol = symbol + a;
                try{

                } catch (Exception e){

                }
            }

            if (Character.isWhitespace(a)) {
                whitespace = whitespace + a;
                appiumDriver.findElementByAccessibilityId("space");
            }
//            } else if(Character.isUpperCase(a)){
//                appiumDriver.findElementByXPath("//XCUIElementTypeButton[@name=\"shift\"]");
//            }

        }
        System.out.println("Alphabets in string:"+letter);
        System.out.println("Numbers in String:"+number);
        System.out.println("Numbers in Whitespace:"+whitespace);

        switchToWebView();
    }



    public void hideKeyboard(){
        switchToNativeView();
        appiumDriver.hideKeyboard();
        switchToWebView();
    }


    /*
     * This method Will wait for timeoutInSeconds seconds for the Mobile Element to be present on screen.
     *
     * @param locator ( xpath, id)
     * @throws ElementNotVisibleException if timeout has been reached and Mobile Element Object still not found
     */
    protected boolean waitForElementVisible(MobileElement element, int time0utSeconds)
    {
        boolean flag = false;
        WebDriverWait wait = new WebDriverWait(appiumDriver, time0utSeconds);
        try
        {
            wait.until(ExpectedConditions.visibilityOf(element));
            flag = true;
        } catch (Exception e)
        {
            flag = false;
        }
        return flag;
    }


    /*
     * This method Will wait for timeoutInSeconds seconds for the Mobile Element to be present on screen.
     *
     * @param locator ( xpath, id)
     * @throws ElementNotVisibleException if timeout has been reached and Mobile Element Object still not found
     */
    protected boolean waitForElementVisible(MobileElement locator)
    {
        return waitForElementVisible(locator, 20);
    }


    /*
     * This method Will wait for x seconds for the gui element to be hidden.
     *
     * @param locator MobileElement
     * @throws ElementNotVisibleException if timeout has been reached and GUI Object still found
     */
    protected boolean waitForElementHidden(MobileElement locator, int timeout)
    {
        boolean visible = true;
        for (int i = 0; i < timeout; i++)
        {
            visible = isElementVisible(locator);
            if ( !visible)
            {
                visible = false;
                break;
            }
            else
            {
                visible = true;
                delay(TIMEOUT);
            }
        }
        return visible;
    }

    /*
 * This method Will wait for x seconds for the gui element to be hidden.
 *
 * @param locator MobileElement
 * @throws ElementNotVisibleException if timeout has been reached and GUI Object still found
 */
    protected boolean waitForElementHidden(WebElement locator, int timeout)
    {
        boolean visible = true;
        for (int i = 0; i < timeout; i++)
        {
            visible = isWebElementVisible(locator);
            if ( !visible)
            {
                visible = false;
                break;
            }
            else
            {
                visible = true;
                delay(TIMEOUT);
            }
        }
        return visible;
    }

       /*
     * This method will verify for the entered data in the text field.
     * Also compared the text which was given by user with the value which is entered in this text field
     */

    public void verifyForDataEnteredInTextField(MobileElement element,String expectedText){

        String actualText=element.getAttribute("value");
        if(actualText.equalsIgnoreCase(expectedText)){
            reportPass("This text field takes the provided data. Input Data is: " + actualText);
        } else reportFailInWebView("This text field is not accepting any text");

    }
    
    public void androidScrollInToView(String containerElementId,String elementTxt) {
    	
    	MobileElement elementToClick = (MobileElement) ((AndroidDriver<MobileElement>) appiumDriver)
    		    .findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()"
    		            + ".resourceId(\""+containerElementId+"\")).scrollIntoView("                      
    		        + "new UiSelector().textContains(\""+elementTxt+"\"));");
    		elementToClick.click();
    }
    
  public void androidScrollInToViewSingleContainer(String elementTxt) {
    	
	  MobileElement elementToClick = (MobileElement) ((AndroidDriver<MobileElement>) appiumDriver)
			    .findElementByAndroidUIAutomator("new UiScrollable("
			        + "new UiSelector().scrollable(true)).scrollIntoView("                      
    		        + "new UiSelector().textContains(\""+elementTxt+"\"));");
			elementToClick.click();
    }

    /*
     * This method will get the platform that system need to run on.
     *
     * @return platform name it will return
     */
    
    protected String getPlatform() {
    	return TestBase.global_platform_name;
    }
   /* protected String getPlatform()
    {
        String value = System.getProperty(AutomationConstants.AUTOMATION_PLATFORM_NAME);
        if (value == null || value.isEmpty())
        {
            FileInputStream fis;
            try
            {
                fis = new FileInputStream(AutomationConstants.AUTOMATION_PROPERTIES_PATH);
                Properties prop = new Properties();
                prop.load(fis);
                value = prop.getProperty(AutomationConstants.AUTOMATION_PLATFORM_NAME);
            } catch (FileNotFoundException e)
            {
                e.printStackTrace();
            } catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        return value;
    }*/


    /*
     * This methods waits timeout seconds for the locator to appear if it doesn't appear by the end of the timeout
     * seconds then it returns false
     *
     * @param locator - element the user wants to check existence of
     * @return boolean - returns true if element is present, false otherwise
     */
    protected boolean isElementPresentWithWait(MobileElement locator, int timeout)
    {
        boolean flag = false;
        for (int i = 0; i < timeout; i++)
        {
            try
            {
                (new WebDriverWait(appiumDriver, TIMEOUT)).until(ExpectedConditions.visibilityOf(locator));
                flag = true;
                break;
            } catch (TimeoutException toe)
            {
                flag = false;
            }
        }
        return flag;
    }

    /*protected String getDeviceType(){

    getProperties = PropertyReader.getPropValues("config.properties");
    String deviceType = getProperties.get("deviceType");

        return deviceType;
    }*/
    
    protected String getDeviceType(){
    	 
    	 return TestBase.global_deviceType;
    }


    /*
     * This method returns the platform. (Ex. Android, iOS..)
     *
     * @return Platform - system platform
     */
    protected String getCurrentPlatform()
    {
        Capabilities cap = appiumDriver.getCapabilities();
        return cap.getCapability("platformName").toString();
    }


    protected boolean returnPlatform()
    {
        return getCurrentPlatform().equalsIgnoreCase("ios");
    }

    /*
     * This method returns the VIEWS we need to switch to. (Ex. NATIVE_APP, WEBVIEW_<APP_PKG_NAME>)
     * This code is used to switch to WEBVIEW when we have some elements not able to be detected by Appium we need to switch to WebVIEW and use @FindBy
     *
     * @return Context VIEW - system platform
     */

    protected AppiumDriver<MobileElement> switchToWebView() {
        try {
            // Switching to webview
            Set<String> contextNames = appiumDriver.getContextHandles();
            for (String contextName : contextNames) {
                System.out.println(contextName); //prints out something like [NATIVE_APP, WEBVIEW_<APP_PKG_NAME>]
                if (contextName.contains("WEBVIEW")) {
                    appiumDriver.context(contextName);
                    System.out.println("Switched to: " + contextName);
                    break;
                }
            }

        } catch (Exception e){

        }
        return appiumDriver;
    }


     /*
     * This method returns the VIEWS we need to switch to. (Ex. NATIVE_APP, WEBVIEW_<APP_PKG_NAME>)
     * This code is used to switch to NATIVEAPP when we switched to WEBVIEW and want to come back to NATIVEVIEW
     *
     * @return Context VIEW - system platform
     */

    protected void switchToNativeView() {
        try {
            // Switching to native view
            Set<String> contextNames = appiumDriver.getContextHandles();
            for (String contextName : contextNames) {
                //   System.out.println(contextName); //prints out something like [NATIVE_APP, WEBVIEW_<APP_PKG_NAME>]
                if (contextName.contains("NATIVE_APP")) {
                    appiumDriver.context(contextName);
                    //    System.out.println("Switched to: "+contextName);
                    break;
                }
            }
        } catch (Exception e){

        }

    }

    protected boolean isiOSScroll(boolean scrollUp, int scrollFrequency)
    {
        if (getCurrentPlatform().equalsIgnoreCase("ios"))
        {
            if (scrollUp)
            {
                for (int i = 1; i <= scrollFrequency; i++)
                {
                    scrollDownJS();
                }
            }
            else
            {
                for (int i = 1; i <= scrollFrequency; i++)
                {
                    scrollUpJS();
                }
            }
            return true;
        }
        else
        {
            return false;
        }
    }


/*    @Attachment(value = "Take Screenshot", type = "image/png")
    public byte[] attachScreenShotToAllure() throws IOException {
        return appiumDriver.getScreenshotAs(OutputType.BYTES);
    }*/



    /*
     * This method will make sure that proper information will get populated in the Allure report and print the logger in
     * Console.
     *
     */
    protected void reportInfo(String message) {

        log.info("Step Info: " + message);
       // log(message);
    }


    /*
     * This method will make sure that test case will get pass in the Allure report and print the logger in Console.
     *
     */
    protected void reportPass(String message) {

        log.info("Passed: " + message);
       // log("Passed: " + message);
    }


    /*
     * This method will make sure that test case will get fail in the  Allure report and print the logger in Console. Mean while
     * it will take the screenshot.
     *
     */
    protected void reportFail(String message) {

//        log.info("Failed: " + message);
//        Assert.assertFalse(true,message);
       // log("Failed: " + message);
        try {
            switchToNativeView();
         //log(message + attachScreenShotToAllure());
        } catch (Exception e) {
            //log(message + " Failed");
        	log.info("Failed: " + message);
            Assert.assertFalse(true,message);
        }
        
        log.info("Failed: " + message);
        Assert.assertFalse(true,message);
    }

    /*
  * This method will make sure that test case will get fail in the  Allure report and print the logger in Console. Mean while
  * it will take the screenshot.
  *
  */
    protected void reportFailInWebView(String message) {

//        log.info("Failed: " + message);
//        Assert.assertFalse(true,message);
//        log("Failed: " + message);
        try {
            switchToNativeView();
           // log(message + attachScreenShotToAllure());
            switchToWebView();
        } catch (Exception e) {
            //log(message + " Failed");
        	log.info("Failed: " + message);
            Assert.assertFalse(true,message);
        }
        

        log.info("Failed: " + message);
        Assert.assertFalse(true,message);
    }


    // Attach Screenshots taken to Allure report
/*    @Attachment(value = "Failure in method {0}", type = "image/png")
    public byte[] takeScreenShot() throws IOException {
        return appiumDriver.getScreenshotAs(OutputType.BYTES);
    }*/
    
     /*
     * This methods will allow to print log in Allure Report
     */

/*    @Step("{0}")
    public void log(final String message) {
        //Kept empty Intentionally
    }*/

    public void waitForElementAndClick(MobileElement locator, String message) {

        waitForElementVisible(locator);
        click(locator,message);
    }

    protected boolean waitForDataLoading() {
        //reportInfo("Loading Data... Please wait");
        boolean isProgressVisible = waitForElementHidden(appiumDriver.findElement(By.xpath("//img[@id='loading']")), 5);
        int counter=0;
            do {
                delay(1);
                isProgressVisible = waitForElementHidden(appiumDriver.findElement(By.xpath("//img[@id='loading']")), 5);
                reportInfo("Loading Data... Please wait");
                counter++;
                if(counter>=120){
                    reportFailInWebView("App is taking too long time to load the screen");
                    break;
                }
            } while (isProgressVisible == true);

        reportInfo("Looks like data has already loaded and hence there is no Loading spinner displayed");
        return isProgressVisible;
    }

    protected void scroll(MobileElement element){
        TouchActions action = new TouchActions(appiumDriver);
        action.scroll(element, 10, 100);
        action.perform();
        action.release();

    }

       /*
  * This method will generate Random strings needed to be input some of the test fields.
  * 'finalRandString' - This is the variable used to return the final string with appending 'Automation_'
  *
  */

    public String randomIdentifier() {

        final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        final Random rand = new Random();
        final Set<String> identifiers = new HashSet<String>();
        String finalRandString;
        StringBuilder builder = new StringBuilder();
        while (builder.toString().length() == 0) {
            int length = rand.nextInt(5) + 5;
            for (int i = 0; i < length; i++) {
                builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
            }
            if (identifiers.contains(builder.toString())) {
                builder = new StringBuilder();
            }
        }
        finalRandString = "Automation_"+builder.toString();
        return finalRandString;
    }

    /* This function will help in getting the location of an element and tap on that element based on X and Y cordinates*/

    public void tapElementOnCordinates(MobileElement locator){

        Point location = locator.getLocation();
        String[] splitCordinates = ((location.toString()).split(","));
        int x = Integer.parseInt((splitCordinates[0].replace("(","")));
        int y = Integer.parseInt(((splitCordinates[1].replace(")",""))).replace(" ",""));
      // (new TouchAction(appiumDriver)).tap(x,y).perform();
        (new TouchAction(appiumDriver)).tap(PointOption.point(x,y)).perform();
    }

    /* This function will check if the App is given permission to access Camera. On every new installing user tries to capture camera App will ask for permission*/
    public void allowPermissionForCamera(){

        switchToNativeView();
        try{
            reportInfo("Verify if App is given permission to access camera");
            if(isElementVisible(appiumDriver.findElementByAccessibilityId("OK"))){
                appiumDriver.findElementByAccessibilityId("OK").click();
            }
        } catch (Exception e){
            reportInfo("Looks like App is given permission to capture device Camera");
        }
        switchToWebView();
    }

    public void deleteOneCharacterFromKeyboard(){
        switchToNativeView();
        appiumDriver.findElementByAccessibilityId("delete").click();
        switchToWebView();
    }


}
