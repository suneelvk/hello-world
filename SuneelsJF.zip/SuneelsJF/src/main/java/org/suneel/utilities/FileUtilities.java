package org.suneel.utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.XMLUnit;

public class FileUtilities {
	
    static ArrayList<File> al = new ArrayList<File>();
    static File fileLocation = null;

	public static void compareXMLFiles(String expectedFolder, String actualFolder, String typeOfFile) {
		//File filePath = new File("C:\\Users\\V.Kalluru\\Desktop\\New folder\\xmlfiles1");
		File filePath = new File(expectedFolder);

		File[] listingAllFiles = filePath.listFiles();

		ArrayList<File> allFiles = iterateOverFiles(listingAllFiles,typeOfFile);

		for (File file : allFiles) {
			if (file != null) {
				String fileName = file.getName();

				String sourceFilepath = file.getAbsolutePath();
				File targetFilePath = new File(actualFolder+ "\\" + fileName);
				String targetPath = targetFilePath.getPath();

				// Files.move(Paths.get(sourceFilepath), Paths.get("D:\\TestFiles\\" +
				// fileName));
				FileReader file_origin;
				FileReader file_replica;
				try {
					file_origin = new FileReader(sourceFilepath);
					
					 file_replica = new FileReader(targetPath);

					assertXMLEquals(file_origin, file_replica);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

			}

		}

	}

	public static void assertXMLEquals(FileReader expectedXML, FileReader actualXML) throws Exception {
		XMLUnit.setXSLTVersion("2.0");
		XMLUnit.setIgnoreWhitespace(true);
		XMLUnit.setIgnoreAttributeOrder(true);
		XMLUnit.setIgnoreDiffBetweenTextAndCDATA(Boolean.TRUE);
		XMLUnit.setIgnoreComments(Boolean.TRUE);
		XMLUnit.setNormalizeWhitespace(Boolean.TRUE);
		XMLUnit.setCompareUnmatched(true);

		// String node;
		DetailedDiff diff = new DetailedDiff(XMLUnit.compareXML(expectedXML, actualXML));
		// System.out.println("similarity"+diff.similar());
		if (!diff.similar()) {

			List<Difference> lDiff = diff.getAllDifferences();
			throw new RuntimeException("Xml comparison failed because of follwoing error" + lDiff);
		}
	}

	public static ArrayList<File> iterateOverFiles(File[] files,String fileType) {

		for (File file : files) {

			if (file.isDirectory()) {

				iterateOverFiles(file.listFiles(),fileType);// Calls same method again.

			} else {

				fileLocation = findFileswithTxtExtension(file,fileType);
				if (fileLocation != null) {
					System.out.println(fileLocation);
					al.add(fileLocation);
				}

			}
		}

		return al;
	}

	public static File findFileswithTxtExtension(File file,String fileType) {

		if (file.getName().toLowerCase().endsWith(fileType)) {
			return file;
		}

		return null;
	}
}