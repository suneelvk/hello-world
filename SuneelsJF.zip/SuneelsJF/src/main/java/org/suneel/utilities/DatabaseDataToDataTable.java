package org.suneel.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import cucumber.api.DataTable;
import cucumber.api.Transformer;
import cucumber.runtime.ParameterInfo;
import cucumber.runtime.table.TableConverter;
import cucumber.runtime.xstream.LocalizedXStreams;
import gherkin.formatter.model.Comment;
import gherkin.formatter.model.DataTableRow;

public class DatabaseDataToDataTable extends Transformer<DataTable> {

	/**
	 * Returns List<List<String>> based on the database query
	 * 
	 * @param quer
	 * @return List<List<String>>
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static List<List<String>> retList(String quer) throws SQLException, ClassNotFoundException {
		Connection conn = null;
		Statement st = null;
		List<List<String>> outerList = null;
		try {
			SqlUtilities sqlUtil = new SqlUtilities();
			conn = sqlUtil.getSQLConnection();
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(quer);

			outerList = new LinkedList<>();
			int columnCount = rs.getMetaData().getColumnCount();
			while (rs.next()) {
				List<String> innerList = new LinkedList<>();
				for (int i = 1; i <= columnCount; i++) {
					System.out.println(rs.getObject(i).toString());
					innerList.add(rs.getObject(i).toString());
				}
				System.out.println(innerList);
				outerList.add(innerList);
			}
			System.out.println(outerList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			st.close();
			conn.close();
		}

		return outerList;

	}

	/* (non-Javadoc)
	 * @see cucumber.api.Transformer#transform(java.lang.String)
	 */
	@Override
	public DataTable transform(String value) {
		List<List<String>> excelData = null;
		try {
			excelData = DatabaseDataToDataTable.retList(value);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<DataTableRow> dataTableRows = getDataTableRows(excelData);

		DataTable table = getDataTable(dataTableRows);

		return table;
	}

	/**
	 * Returns datatable
	 * 
	 * @param dataTableRows
	 * @return
	 */
	private DataTable getDataTable(List<DataTableRow> dataTableRows) {
		ParameterInfo parameterInfo = new ParameterInfo(null, null, null, null);
		TableConverter tableConverter = new TableConverter(
				new LocalizedXStreams(Thread.currentThread().getContextClassLoader()).get(Locale.getDefault()),
				parameterInfo);

		DataTable table = new DataTable(dataTableRows, tableConverter);
		return table;
	}

	/**
	 * Returns the datatable rows
	 * 
	 * @param excelData
	 * @return
	 */
	private List<DataTableRow> getDataTableRows(List<List<String>> excelData) {
		List<DataTableRow> dataTableRows = new LinkedList<>();
		int line = 1;

		for (List<String> list : excelData) {
			Comment commnet = new Comment("", line);
			DataTableRow tableRow = new DataTableRow(Arrays.asList(commnet), list, line++);
			dataTableRows.add(tableRow);
		}
		return dataTableRows;
	}
}
