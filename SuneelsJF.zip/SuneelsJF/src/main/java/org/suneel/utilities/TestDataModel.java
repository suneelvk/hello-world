package org.suneel.utilities;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.suneel.utilities.ExcelReader;
import org.suneel.utilities.SqlUtilities;

public class TestDataModel {

	public static <T> List<T> DataBaseDapper(String sql, Class<T> type,Object... params)
			throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, Exception {
		
		SqlUtilities sqlUtil = new  SqlUtilities();		
	
		Connection conn = sqlUtil.getSQLConnection();//DriverManager.getConnection(connString);
		
		JDapper jd = new JDapper(conn);

		List<T> objList = jd.query(sql, type, params);

		conn.close();

		return objList;
	}
	
	public static <T> List<T> getExcelDapper(Class<T> type, String fileLoc, String sheetname)
			throws IOException, InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		List<T> results = new ArrayList<>();
		Field[] fields = type.getDeclaredFields();

		String filePath = System.getProperty("user.dir") + fileLoc;
		ExcelReader reader = new ExcelReader.ExcelReaderBuilder().setFileLocation(filePath).setSheet(sheetname).build();
		List<List<String>> mainOut = reader.getSheetData();

		for (List<String> list : mainOut) {
			T obj = type.getConstructor().newInstance();
			int i = 0;
			for (Field field : fields) {
				Object data = list.get(i);
				field.set(obj, data);
				i++;
			}

			results.add(obj);
		}

		return results;
	}
	
	

}

 class JDapper {
	private final Connection conn;

	public JDapper(Connection conn) {
		this.conn = conn;
	}
	
	public <T> List<T> query(String sql, Class<T> type, Object...params) throws Exception {
		List<T> results = new ArrayList<>();
		
		Field[] fields = type.getDeclaredFields();
		for (Field field : fields) {
			field.setAccessible(true);
		}
		
		PreparedStatement statement = conn.prepareStatement(sql);
		
		for (int i = 0; i < params.length; i++) {
			statement.setObject(i+1, params[i]);
		}
		
		ResultSet rs = statement.executeQuery();
		
		while(rs.next()){
			T obj = type.getConstructor().newInstance();
			
			for (Field field : fields) {
				Object data = rs.getObject(field.getName());
				field.set(obj, data);
			}
			
			results.add(obj);
		}
		
		return results;
	}
	
	/*private static final String RAW_INSERT = "INSERT INTO %s (%s) VALUES (%s);";
	public void insert(String tableName, Object data) throws Exception{
		Class<?> type = data.getClass();
		Field[] fields = type.getFields();
		
		String columnNames = "";
		String values = "";
		for (Field field : fields) {
			columnNames += "," + field.getName();
			values += ",?";
		}
		columnNames = columnNames.substring(1);
		values = values.substring(1);
		
		String sql = String.format(RAW_INSERT, tableName, columnNames, values);
		
		PreparedStatement statement = conn.prepareStatement(sql);
		
		for (int i = 0; i < fields.length; i++) {
			statement.setObject(i+1, fields[i].get(data));
		}
		
		statement.execute();
	}*/
}
