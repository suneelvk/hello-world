package org.suneel.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.suneel.base.TestBase;



/**
 * @author V.Kalluru
 *
 */

public class SqlUtilities {
	// #region Database parameters

	private String connectionString;
	private String classForName;

	// #endregion

	/**
	 * Constructor
	 */
	public SqlUtilities() {

		connectionString = TestBase.global_connectionString;
		classForName = TestBase.global_classForName;
	}

	/**
	 * Gets the SQL Connection required
	 */
	/**
	 * @return
	 */
	public Connection getSQLConnection() {

	try {
			if (!classForName.isEmpty()) {
				try {
					Class.forName(classForName);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			Connection connection = DriverManager.getConnection(connectionString);
			
			return connection;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error: " + e.getMessage());
			return null;
		}

	}
	
	
	/**
	 * Executes a query that does modificats and retuns true if rows effected
	 * 
	 * @param query
	 * @return boolean
	 */
	public boolean ExecuteNonQuery(String query) {

		try {
			if (!classForName.isEmpty()) {
				try {
					Class.forName(classForName);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			Connection connection = DriverManager.getConnection(connectionString);
			Statement st = connection.createStatement();
			st.executeQuery(query);
			connection.close();
			return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error: " + e.getMessage());
			
			return false;
		}

	}

	/**
	 * @param query
	 * @return queryresult
	 */
	public Object ExecuteScalar(String query) {

//		String connectionString = String.format("Data Source={0}; Initial catalog = {1}; User ID = {2}; Password = {3}",
//				global_dataSource, global_dataBaseName, global_userId, global_password);

		try {
			if (!classForName.isEmpty()) {
				try {
					Class.forName(classForName);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			Connection connection = DriverManager.getConnection(connectionString);
			Statement st = connection.createStatement();
			Object result = st.executeQuery(query);
			connection.close();
			return result;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error: " + e.getMessage());
			return null;
		}

	}

	
}