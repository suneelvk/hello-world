package org.suneel.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class Utilities {
	
	public WebDriver driver;
	public RemoteWebDriver remoteDriver;
    public AppiumDriver<MobileElement> appiumDriver;
    public MobileUtilities mobileUtilities ;
	
	public Utilities(AppiumDriver<MobileElement> appiumDriver) {
		mobileUtilities = new MobileUtilities(appiumDriver);
	}

	
	public Utilities(WebDriver driver) {
		//mobileUtilities = new MobileUtilities(appiumDriver); Need to construct for other Utilities
	}
	
	
}
