package org.suneel.utilities;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.suneel.base.TestBase;
import org.suneel.enums.Browsers;



/**
 * @author V.Kalluru
 *
 */

public class BrowserUtilities {
	private static WebDriver driver = TestBase.driver;

	public String CategorySeleniumSmokeTest = "SeleniumSmokeTest";
	public String CategorySeleniumRegressionTest = "SeleniumRegressionTest";

	/**
	 * The current address in the address-bar of the window
	 */
	public static String CurrentAddress = driver.getCurrentUrl();

	/**
	 * navigate to an address
	 * 
	 * @param address
	 */
	public static void navigateToAddress(String address) {
		// For some reason a NullReferenceException is thrown if driver isn't accessed
		// before the .navigate() method call.
		if (driver == null)
			System.out.println("Driver is null");

		driver.navigate().to(address);
	}

	/**
	 * Resize Browser window to specific ratio
	 * 
	 * @param width
	 * @param hight
	 */
	public static void ResizeBrowser(int width, int hight) {
		driver.manage().window().setPosition(new Point(0, 0)); // window.Position.Offset(new Point(0, 0));
		driver.manage().window().setSize(new Dimension(width, hight)); // = new Size(width, hight);
	}

	/**
	 * Refresh the page (F5)
	 */
	public static void Refresh() {
		driver.navigate().refresh();
	}

	/**
	 * Click the browser back-button
	 */
	public static void ClickBackButton() {
		driver.navigate().back();
	}

	/**
	 * Switch tabs on the browser
	 * 
	 * @param tabIndex The tab-index to switch to
	 */
	public static void SwitchTab(int tabIndex) {
		/*
		 * Set<String> tabs = driver.getWindowHandles();
		 * driver.switchTo().Window(tabs[tabIndex]);
		 */
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(tabIndex));
	}

	// #region javascript Methods

	/**
	 * Execute a snippet of javascript on the page
	 * 
	 * @param script The script to execute
	 * @return The result of the javascript
	 */
	public static String ExecuteScript(String script) {
		try {

			JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) TestBase.driver;
			Object result = javaScriptExecutor.executeScript(script);
			return result.toString();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return ""; // String.Empty;
		}
	}

	/**
	 * Get current scroll position
	 */
	// public static int ScrollPosition => int.Parse(ExecuteScript("return
	/// window.scrollY;"), CultureInfo.InvariantCulture);

	/**
	 * Scroll to the bottom
	 */
	public static void ScrollToBottom() {
		JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) TestBase.driver;
		javaScriptExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	}

	/**
	 * Scroll a specific amount in pixels
	 * 
	 * @param amountToScroll The amount to scroll
	 */
	public static void Scroll(int amountToScroll) {
		JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) TestBase.driver;
		javaScriptExecutor.executeScript(String.format("window.scrollBy(0,{0})", amountToScroll));

	}

	// #endregion

	// #region Action Methods

	/**
	 * An extension method Hover on an element
	 * 
	 * @param webElement The element to hover on
	 */
	public static void Hover(WebElement webElement) {
		Actions action = new Actions(driver);
		action.moveToElement(webElement).perform();

	}

	/**
	 * An extension method to upload File
	 * 
	 * @param webElement
	 * @param filePath
	 */
	public static void UploadFile(WebElement webElement,String filePath) {		 
	     webElement.sendKeys(filePath);
	     }
	 


	// #endregion

	// #region Alert Methods

	/**
	 * Returns if a alert exits
	 * 
	 * @return True if alert exits
	 */
	public static boolean AlertExits() {
		//Alert alert = ExpectedConditions.alertIsPresent().apply(driver);
		//return alert != null;
		boolean stat=false;
		try 
		{ 
		    driver.switchTo().alert(); 
		    System.out.println(" Alert Present");
		    stat=true;
		    
		}  
		catch (NoAlertPresentException e) 
		{ 
		    System.out.println("No Alert Present");
		}   
		return stat;
	}

	/**
	 * Submits a Alert
	 */
	public static void SubmitAlert() {
		Alert alert = driver.switchTo().alert();
		alert.accept();
	}

	/**
	 * Dismiss a Alert
	 */
	public static void DismissAlert() {
		Alert alert = driver.switchTo().alert();
		alert.dismiss();
	}

	/**
	 * Sends the String value to Alert (example file upload path)
	 * 
	 * @param value
	 */
	public static void SendKeysToAlert(String value) {
		Alert alert = driver.switchTo().alert();
		alert.sendKeys(value);
	}


	/**
	 * Sets the Credentials when prompted by the browser
	 * 
	 * @param UserName User Name
	 * @param Password Password
	 */
	public static void SetCredentials(String UserName, String Password) {
		Alert alert = driver.switchTo().alert();
		alert.sendKeys(UserName + Keys.TAB + Password);
		alert.accept();
	}

	// #endregion

	// #region Screen Shot methods

	/**
	 * Takes a screen shot of specific element
     *
	 * @param ele
	 * @return
	 * @throws IOException 
	 */
	public static File TakeScreenshotOfWebElement(WebElement ele) throws IOException { 
		// Get entire page screenshot
		  File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		  BufferedImage  fullImg = ImageIO.read(screenshot);

		  // Get the location of element on the page
		  Point point = ele.getLocation();

		  // Get width and height of the element
		  int eleWidth = ele.getSize().getWidth();
		  int eleHeight = ele.getSize().getHeight();

		  // Crop the entire page screenshot to get only element screenshot
		  BufferedImage eleScreenshot= fullImg.getSubimage(point.getX(), point.getY(),
		      eleWidth, eleHeight);
		  ImageIO.write(eleScreenshot, "png", screenshot);

		  // Copy the element screenshot to disk
		  /*File screenshotLocation = new File("C:\\images\\GoogleLogo_screenshot.png");
		  FileUtils.copyFile(screenshot, screenshotLocation); */
		  
		  return screenshot;
		  
	  
	  }



	/**
	 * Takes a screen shot of the application in the browser
	 * 
	 * @return The path of the screenshot
	 * @throws IOException 
	 */
	public static String GetScreenShotPath() throws IOException {
		File sourcePath = ((TakesScreenshot) TestBase.driver).getScreenshotAs(OutputType.FILE);

		File tmpFile = File.createTempFile("savefig", ".png");

		// Copy taken screenshot from source location to destination location
		FileUtils.copyFile(sourcePath, tmpFile);

		return tmpFile.toString();
	}

	

	// #endregion

	// region Process Methods

	/**
	 * Kills All Browser and Driver process based on configurations
	 *
	 * @param eBrow
	 */
	public static void KillBrowserDriverProcess(Browsers eBrow) {
		switch (eBrow) {
		case FIREFOX:
			KillProcess("geckodriver");
			break;

		case CHROME:
			KillProcess("chromedriver");
			break;

		case IE:
			KillProcess("iexplore");
			KillProcess("IEDriverServer");
			break;

		case MSEDGE:
			KillProcess("MicrosoftWebDriver");
			KillProcess("MicrosoftEdgeCP");
			break;

		default:
			try {
				throw new Exception(
						String.format("Browser: %s is not valid. Try changing to FIREFOX, CHROME , IE or MSEDGE ",
								eBrow));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// To update above method

	/**
	 * Kills all processes specified in process name
	 *
	 * @param processName
	 */
	private static void KillProcess(String processName) {

		Process processes;
		try {
			processes = Runtime.getRuntime().exec(processName);
			processes.destroy();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	// need to check if the above works

	// #endregion

	// #region File operations

	/**
	 * Delete file if it exist
	 * 
	 * @param FilePath
	 */
	public static void DeleteIfFileExists(String FilePath) {
		File fi = new File(FilePath);
		if (fi.exists())
			fi.delete();
	}

	/**
	 * Move file to specified path *
	 * 
	 * 
	 * @param FilePath
	 * @param NewFilePath
	 * @return boolean
	 */
	public static boolean MoveFileTo(String FilePath, String NewFilePath) {
		/*
		 * var currentFile = new FileInfo(FilePath); currentFile.MoveTo(NewFilePath);
		 */
		File file = new File(FilePath);
		// renaming the file and moving it to a new location
		if (file.renameTo(new File(NewFilePath))) {
			// if file copied successfully then delete the original file
			file.delete();
			return true;
		} else {
			System.out.println("Failed to move the file");
			return false;
		}
	}

	/**
	 * Check if specified file exists
	 * 
	 * @param FilePath
	 * @return boolean
	 */
	public static boolean FileExists(String FilePath) {
		File fi = new File(FilePath);
		return (fi.exists());
	}

	/**
	 * Create Directory at the path specified
	 * 
	 * @param DirPath
	 */
	public static void CreateDirectory(String DirPath) {
		// Directory.CreateDirectory(DirPath);
		/*
		 * Files.createDirectories(Paths.get(DirPath));
		 * FileUtils.forceMkdir("/path/directory"); Path path =
		 * Paths.get("/your/path/string"); if(!Files.exists(path)) { try {
		 * Files.createDirectories(path); } catch (IOException e) { e.printStackTrace();
		 * } }
		 */
		File dir = new File(DirPath);
		dir.mkdir();
	}

	// #endregion

	// #endregion
}
