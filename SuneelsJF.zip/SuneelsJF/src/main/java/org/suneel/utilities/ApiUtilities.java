package org.suneel.utilities;

import static io.restassured.RestAssured.given;

import io.restassured.authentication.AuthenticationScheme;
import io.restassured.authentication.CertificateAuthSettings;
import io.restassured.authentication.FormAuthConfig;
import io.restassured.authentication.OAuthSignature;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.AuthenticationSpecification;
import io.restassured.specification.MultiPartSpecification;
import io.restassured.specification.ProxySpecification;
import io.restassured.specification.RequestSpecification;

import static org.hamcrest.Matchers.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.StringWriter;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.output.WriterOutputStream;
import org.shell.tcoe.base.TestBase;
import org.testng.Assert;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.vimalselvam.cucumber.listener.Reporter;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;;

public class ApiUtilities {

	// private static Response response;

	/*
	 * public static StringWriter requestWriter; public static PrintStream
	 * requestCapture; public static StringWriter responseWriter; public static
	 * PrintStream responseCapture; public static StringWriter errWriter; public
	 * static PrintStream errCapture;
	 */

	/**
	 * Invoke a specific RequestSpecification
	 * 
	 * @param specName 
	 * 
	 * if  specName empty will Invoke the default RequestSpecification
	 * 
	 * @return RequestSpecification
	 */
	public static RequestSpecification invokeRequestSpecification(String specName) {
		if (specName != "")
			return given().spec(TestBase.global_specMap.get(specName.trim()));
		else
			return given().spec(TestBase.global_request_spec);
	}

	/**
	 * SetUp the BaseURI 
	 * 
	 * @param baseURI
	 * Use this baseURI to send the complete URI 
	 * 
	 * example : http://localhost:8080/resource
	 * 
	 * @return RequestSpecification
	 */
	public static RequestSpecification setUpBaseURI(String baseURI) {
		// rspec = given().spec(TestBase.global_request_spec);
		// this will set the whole uri and the basepath will be null
		/*
		 * baseURi = http://localhost:3000/posts basePath = "" u need to use endpoint /1
		 */
		return given().spec(TestBase.global_request_spec).baseUri(baseURI).basePath("");
	}

	/**
	 * SetUp the BasePath/Endpoint
	 * 
	 * @param basePath 
	 * basePath is the end point
	 * 
	 * 
	 * @return RequestSpecification
	 */
	public static RequestSpecification setUpBasePath(String basePath) {
		return given().spec(TestBase.global_request_spec).basePath(basePath);

	}

	/**
	 * Execute GET - Method on a RequestSpecification using an endPoint
	 * 
	 * @param rspec
	 * @param endPoint
	 * 
	 * 
	 * @return Response
	 */
	public static Response executeMethodGET(RequestSpecification rspec, String endPoint) {

		return rspec.get(endPoint);

	}

	/**
	 *  * Execute POST - Method on a RequestSpecification using an endPoint and an object to be posted
	 * 
	 * @param rspec
	 * @param endPoint
	 * @param objPost  object to be posted
	 * 
	 * @return Response
	 */
	public static Response executeMethodPOST(RequestSpecification rspec, String endPoint, Object objPost) {

		return rspec.body(objPost).when().contentType(ContentType.JSON).post(endPoint);

	}

	/**
	 * Execute PUT - Method on a RequestSpecification using an endPoint and an object to be updated
	 * 
	 * @param rspec
	 * @param endPoint
	 * @param objPost
	 * @return Response
	 */
	public static Response executeMethodPUT(RequestSpecification rspec, String endPoint, Object objPost) {

		return rspec.body(objPost).when().contentType(ContentType.JSON).put(endPoint);

	}
	/**
	 * Execute PATCH - Method on a RequestSpecification using an endPoint and an object to be patched
	 * 
	 * @param rspec
	 * @param endPoint
	 * @param objPost
	 * @return Response
	 */
	public static Response executeMethodPATCH(RequestSpecification rspec, String endPoint, Object objPost) {

		return rspec.body(objPost).when().contentType(ContentType.JSON).patch(endPoint);

	}
	/**
	 * Execute DELETE - Method on a RequestSpecification using an endPoint 
	 * 
	 * @param rspec
	 * @param endPoint
	 * 
	 * @return Response
	 */
	public static Response executeMethodDELETE(RequestSpecification rspec, String endPoint) {

		return rspec.when().delete(endPoint);

	}

	/**
	 * Basic Authentication
	 * 
	 * @param rspec
	 * @param username
	 * @param password
	 */
	public static void authenticateBasic(RequestSpecification rspec, String username, String password) {
		// rspec.auth().preemptive().basic(username, password);

		rspec.auth().preemptive().basic(username, password);

	}

	/**
	 * OAuth2 Authentication
	 * 
	 * @param rspec
	 * @param accessToken
	 * @param signature
	 */
	public static void authenticateOauth2(RequestSpecification rspec, String accessToken, OAuthSignature signature) {

		rspec.auth().oauth2(accessToken, signature);

	}

	/**
	 * 	 OAuth2 Authentication
	 * 
	 * 
	 * @param rspec
	 * @param accessToken
	 */
	public static void authenticateOauth2(RequestSpecification rspec, String accessToken) {

		rspec.auth().oauth2(accessToken);

	}

	/**
	 * Form Authentication
	 * 
	 * @param rspec
	 * @param userName
	 * @param password
	 */
	public static void authenticateUsingForm(RequestSpecification rspec, String userName, String password) {

		rspec.auth().form(userName, password);

	}

	/**
	 * Form Authentication
	 * @param rspec
	 * @param userName
	 * @param password
	 * @param config
	 */
	public static void authenticateUsingForm(RequestSpecification rspec, String userName, String password,
			FormAuthConfig config) {

		rspec.auth().form(userName, password, config);

	}

	/**
	 * Oauth Authentication
	 * 
	 * @param rspec
	 * @param consumerKey
	 * @param consumerSecret
	 * @param accessToken
	 * @param secretToken
	 * @param signature
	 */
	public static void authenticateOauth(RequestSpecification rspec, String consumerKey, String consumerSecret,
			String accessToken, String secretToken, OAuthSignature signature) {

		rspec.auth().oauth(consumerKey, consumerSecret, accessToken, secretToken, signature);
	}

	/**
	 * Oauth Authentication
	 * 
	 * @param rspec
	 * @param consumerKey
	 * @param consumerSecret
	 * @param accessToken
	 * @param secretToken
	 */
	public static void authenticateOauth(RequestSpecification rspec, String consumerKey, String consumerSecret,
			String accessToken, String secretToken) {

		rspec.auth().oauth(consumerKey, consumerSecret, accessToken, secretToken);
	}

	/**
	 * Dijest Authentication
	 * 
	 * @param rspec
	 * @param userName
	 * @param password
	 */
	public static void authenticateDigest(RequestSpecification rspec, String userName, String password) {

		rspec.auth().digest(userName, password);
	}

	/**
	 * Certificate Authentication
	 * 
	 * @param rspec
	 * @param certURL
	 * @param password
	 */
	public static void authenticateCertificate(RequestSpecification rspec, String certURL, String password) {

		rspec.auth().certificate(certURL, password);
	}

	/**
	 * Certificate Authentication
	 * 
	 * @param rspec
	 * @param certURL
	 * @param password
	 * @param certificateAuthSettings
	 */
	public static void authenticateCertificate(RequestSpecification rspec, String certURL, String password,
			CertificateAuthSettings certificateAuthSettings) {

		rspec.auth().certificate(certURL, password, certificateAuthSettings);
	}

	/**
	 * Assert responses in List format are equal
	 * 
	 * @param res1
	 * @param res2
	 */
	public static void assertListResponsesAreEqual(Response res1, Response res2) {

		JsonParser parser = new JsonParser();
		Set<JsonElement> arr1elems = setOfElements(parser.parse(res1.asString()).getAsJsonArray());
		Set<JsonElement> arr2elems = setOfElements(parser.parse(res2.asString()).getAsJsonArray());
		Assert.assertTrue(arr1elems.equals(arr2elems), "Validation of Api - Responses");
		// Reporter.addScenarioLog(TestBase.errWriter.toString());
	}

	/**
	 * Assert responses in Map format are equal
	 * 
	 * @param res1
	 * @param res2
	 * @return
	 */
	public static MapDifference<Object, Object> assertMapResponsesAreEqual(Response res1, Response res2) {

		Gson objGson = new Gson();
		Type mapType = new TypeToken<List<HashMap<Object, Object>>>() {
		}.getType();
		Map<Object, Object> firstMap = objGson.fromJson(res1.asString(), mapType);
		Map<Object, Object> secondMap = objGson.fromJson(res2.toString(), mapType);
		return Maps.difference(firstMap, secondMap);

	}

	/**
	 * Return Set of input responses
	 * 
	 * @param arr
	 * @return
	 */
	static Set<JsonElement> setOfElements(JsonArray arr) {
		Set<JsonElement> set = new HashSet<JsonElement>();
		for (JsonElement j : arr) {
			set.add(j);
		}
		return set;
	}

	/**
	 * 
	 * Assert the response status code
	 * 
	 * @param response
	 * @param statusCode
	 */
	public static void assertStatusCode(Response response, int statusCode) {
		response.then().assertThat().statusCode(statusCode);
	}

	/**
	 * Validate the given path in response
	 * 
	 * @param response
	 * @param path
	 * @param value
	 */
	public static void validateResponseUsingPath(Response response, String path, String value) {
		Assert.assertEquals(value, response.path(path).toString(), "Validate - API response path");
	}

	/**
	 * Validate response with a jsonschema
	 * 
	 * @param response
	 * @param classPath
	 */
	public static void validateResponseJsonSchema(Response response, String classPath) {

		response.then().assertThat().body(matchesJsonSchemaInClasspath(classPath));

	}

	/**
	 * Validate the time taken for the response is Less than the specified time
	 * 
	 * @param response
	 * @param time
	 */
	public static void validateResponseTimeisLessthan(Response response, Long time) {

		response.then().time(lessThan(time));

	}

	

	/**
	 * set the Proxy using host and port
	 * 
	 * @param rspec
	 * @param host
	 * @param port
	 */
	public static void setProxy(RequestSpecification rspec, String host,int port) {
		rspec.proxy(host, port);
	}
	
	/**
	 * 
	 * set the Proxy using  port
	 * 
	 * @param rspec
	 * @param port
	 */
	public static void setProxy(RequestSpecification rspec,int port) {
		rspec.proxy(port);
	}
	
	/**
	 * 
	 * 	 set the Proxy using  ProxySpecification
	 * 
	 * @param rspec
	 * @param proxySpecification
	 */
	public static void setProxy(RequestSpecification rspec,ProxySpecification proxySpecification) {
		rspec.proxy(proxySpecification);
	}
	
	/**
	 * set the Proxy using  host Or Uri
	 * 
	 * @param rspec
	 * @param hostOrUri
	 */
	public static void setProxy(RequestSpecification rspec,String hostOrUri) {
		rspec.proxy(hostOrUri);
	}
	
	/**
	 * set the Proxy using host and port and scheme
	 * @param rspec
	 * @param host
	 * @param port
	 * @param scheme
	 */
	public static void setProxy(RequestSpecification rspec, String host,int port,String scheme) {
		rspec.proxy(host, port, scheme);
	}
	
	
	/**
	 * Use relaxed HTTP validation with SSLContext protocol SSL. This means that
	 * you'll trust all hosts regardless if the SSL certificate is invalid.
	 * 
	 * By using thismethod you don't need to specify a keystore (see
	 * keyStore(String, String) or trust store (see
	 * trustStore(java.security.KeyStore)
	 * 
	 * @param rspec
	 */
	public static void useRelaxedHTTPSValidation(RequestSpecification rspec) {

		rspec.relaxedHTTPSValidation();

	}

	/**
	 * Specify a parameter that'll be sent with the request
	 * 
	 * @param rspec
	 * @param strParamKey
	 * @param strParamValue
	 */
	public static void specifyParameter(RequestSpecification rspec, String strParamKey, String strParamValue) {

		rspec.param(strParamKey, strParamValue);

	}
	
	
	
	/**
	 *  * Execute POST - Method on a RequestSpecification using an endPoint and a file to be uploaded
	 * 
	 * @param rspec
	 * @param endPoint
	 * @param filePath   path of the file which need to be uploaded
	 * @param mimetype type of formdata       example: "multipart/form-data" in case of xml
	 * 
	 * @return Response
	 */
	public static Response executeMethodFileUpload(RequestSpecification rspec, String endPoint, String filePath, String mimetype) {
		
		File testUploadFile = new File(filePath);
		
		return rspec.multiPart(testUploadFile.getName(), testUploadFile, mimetype).when().post(endPoint);

	}
	
	/**
	 *  * Execute - Method on a Response to download a file
	 * 
	 * @param response
	 * @param downloadFilePath   path of the file where needs to be downloaded
	 * @param downloadFileName   name of the file which need to be downloaded
	 * 
	 */
	public static void downloadFileFromResponse(Response response, String downloadFilePath, String downloadFileName) {
		File outputPath = new File(downloadFilePath);

		File checkDownloaded = new File(outputPath.getPath(), downloadFileName);

		if (response.getStatusCode() == 200) {

			// I am choosing to delete the file if it already exists and write it again
			// if it already exists you might choose to return and not overwrite it
			if (checkDownloaded.exists()) {
				checkDownloaded.delete();
			}

			// I might choose to use the mime type of the file to control the file extension
			// here I am just outputting it to the console to demonstrate how to get the
			// type
			System.out.println("Downloaded an " + response.getHeader("Content-Type"));

			// get the contents of the file
			byte[] fileContents = response.getBody().asByteArray();

			// output contents to file
			OutputStream outStream = null;

			try {

				outStream = new FileOutputStream(checkDownloaded);
				outStream.write(fileContents);

			} catch (Exception e) {

				System.out.println("Error writing file " + checkDownloaded.getAbsolutePath());

			} finally {

				if (outStream != null) {
					try {
						outStream.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}

	
	
	/**
	 *  * Execute POST - Method on a RequestSpecification using an endPoint and multiple file to be uploaded
	 * 
	 * @param rspec
	 * @param endPoint	 * 
	 * @param mimetype type of formdata       example: "multipart/form-data" in case of xml
	 * @param Files[]   array of the files which need to be uploaded
	 * 
	 * @return Response
	 */
	public static Response executeBulkFileUpload(RequestSpecification rspec, String endPoint,  String mimetype,File[] files) {
				
		for (File file : files) {
			rspec.multiPart(file.getName(), file.getAbsolutePath(), mimetype);
			
		}		
		
		return rspec.when().post(endPoint);

	}

		
	
	/*
	 * public static ErrorLoggingFilter enableErrorLoggingFilter() {
	 * TestBase.requestWriter = new StringWriter(); TestBase.requestCapture = new
	 * PrintStream(new WriterOutputStream(TestBase.requestWriter),true);
	 * TestBase.responseWriter = new StringWriter(); TestBase.responseCapture = new
	 * PrintStream(new WriterOutputStream(TestBase.responseWriter),true);
	 * TestBase.errWriter = new StringWriter(); TestBase.errCapture = new
	 * PrintStream(new WriterOutputStream(TestBase.errWriter),true); errCapture =
	 * new PrintStream(new WriterOutputStream(new StringWriter()),true); return new
	 * ErrorLoggingFilter(errCapture); }
	 * 
	 * public static void enableRequestLoggingFilter(RequestSpecification rspec) {
	 * TestBase.requestWriter = new StringWriter(); TestBase.requestCapture = new
	 * PrintStream(new WriterOutputStream(TestBase.requestWriter),true);
	 * TestBase.responseWriter = new StringWriter(); TestBase.responseCapture = new
	 * PrintStream(new WriterOutputStream(TestBase.responseWriter),true);
	 * TestBase.errWriter = new StringWriter(); TestBase.errCapture = new
	 * PrintStream(new WriterOutputStream(TestBase.errWriter),true);
	 * 
	 * requestCapture = new PrintStream(new WriterOutputStream(requestWriter),true);
	 * rspec.filter(new RequestLoggingFilter(requestCapture));
	 * 
	 * }
	 */

	/*
	 * public static RequestSpecification setUpBasePath(RequestSpecBuilder builder,
	 * String basePath) { builder = TestBase.global_builder;
	 * builder.setBasePath(basePath); return builder.build(); // rspec =
	 * given().spec(TestBase.global_request_spec); // rspec.basePath(basePath); }
	 */
}
