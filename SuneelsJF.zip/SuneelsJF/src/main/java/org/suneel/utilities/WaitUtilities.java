package org.suneel.utilities;

import java.time.Duration;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.suneel.base.TestBase;

import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;

public class WaitUtilities {
	// #region Private Declarations
	
	private static WebDriverWait wait = new WebDriverWait(TestBase.driver, 40);

	// #endregion

	// #region Public Methods

	
	/**
	 * Wait until the address-bar matches a certain value
	 * 
	 * @param address  The address bar to match
	 */
	public static void WaitForAddressBarMatches(String address) {
		wait.until(ExpectedConditions.urlMatches(address));
	}


	/**
	 * Wait until the address-bar contains a certain value
	 * 
	 * @param address  The address bar to match
	 */
	public static void WaitForUrlContains(String address) {
		wait.until(ExpectedConditions.urlContains(address));
	}

	/**
	 * Wait for an element to be visible
	 * 
	 * @param locator  The locator for the element to wait for
	 */
	public static void WaitForElement(By locator) {
		// wait.until(ExpectedConditions.ElementIsVisible(locator));
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}


	/**
	 *  Waits till the web element is clickable
	 * 
	 * @param element
	 */
	public static void WaitTillElementIsClickable(WebElement element) {
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}


	
	  /**
	   * WaitTillElementIsDisplayed
	   * 
	 * @param driver
	 */

	public static void WaitTillElementIsSelected(WebDriver driver , By ele) {
	  
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)                            
				.pollingEvery(Duration.ofMillis(250))
				.withTimeout(Duration.ofSeconds(120))       
				.ignoring(NoSuchElementException.class);    

				  WebElement aboutMe= wait.until(new Function<WebDriver, WebElement>() {       
				public WebElement apply(WebDriver driver) { 
				return driver.findElement(ele);     
				 }  
				});  
	  
	  }
	 
	/**
	 * Waits for an element to be selected , if not it is selected and checked again
	 * 
	 * @param element Web element
	 */
	public static void WaitTillElementIsSelected(WebElement element) {

		Wait<WebElement> waitElement = new FluentWait<WebElement>(element).pollingEvery(Duration.ofMillis(250))
				.withTimeout(Duration.ofSeconds(120));

		Function<WebElement, Boolean> waiter = new Function<WebElement, Boolean>() {

			public Boolean apply(WebElement element) {
				// TODO Auto-generated method stub
				if (element.isSelected()) {
					return true;
				}

				element.click();
				return false;
			}

		};

		waitElement.until(waiter);

	}

	// #endregion
}