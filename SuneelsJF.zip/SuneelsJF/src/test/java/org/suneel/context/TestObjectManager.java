package org.shell.tcoe.context;

//import static org.shell.tcoe.stepdefinitions.TestDataModel.getExcelDapper;

import static org.shell.tcoe.utilities.TestDataModel.getExcelDapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.stream.Collectors;

import org.shell.tcoe.models.CrmModel;
import org.shell.tcoe.models.SfModel;
import org.shell.tcoe.pageobjects.HomePageControls;
import org.shell.tcoe.pages.HomePage;

public class TestObjectManager {

	public static List<CrmModel> listCrmModel;

	public static List<CrmModel> td_Test_Login;

	public static List<CrmModel> td_Test_Homepage;

	public static List<CrmModel> td_Test_cartpage;
	
	public static List<CrmModel> td_Test_hello;
	
	public static List<SfModel> listSfModel;

	public static List<SfModel> td_SfTest_Login;
	
	public static List<CrmModel> listAmzon;

	public TestObjectManager() throws InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException, IOException {
		// Getting List of data for 'Crm_Appl' - Sheet from		'CrmApplTestData.xlsx'
		listCrmModel = getExcelDapper(CrmModel.class, "\\src\\test\\resources\\TestData\\CrmApplTestData.xlsx",
				"Crm_Appl");
		
		listSfModel = getExcelDapper(SfModel.class, "\\src\\test\\resources\\TestData\\SfApplTestData.xlsx",
				"Crm_Appl");
		
		//listCountryModel = List<Country_DefaultData> countries = DataBaseDapper("select * from emp",Country_DefaultData.class);
		
		//List<Country_DefaultData> countries = DataBaseDapper("select * from emp where eno = ? ",Country_DefaultData.class, 1);
		
			
		
	}

	
	public List<CrmModel> setTestDataForTest_Amazon() {
		listAmzon = listCrmModel.stream().filter(it -> it.testCaseName.contains("Test_Amazon"))
				.collect(Collectors.toList());

		return listAmzon;
	}
	
	public List<SfModel> setSfTestDataForTest_login() {
		td_SfTest_Login = listSfModel.stream().filter(it -> it.testCaseName.contains("Test_login"))
				.collect(Collectors.toList());

		return td_SfTest_Login;
	}

	public List<CrmModel> setTestDataForTest_login() {
		td_Test_Login = listCrmModel.stream().filter(it -> it.testCaseName.contains("Test_login"))
				.collect(Collectors.toList());

		return td_Test_Login;
	}
	
	public List<CrmModel> setTestDataForTest_homepage() {
		td_Test_Homepage = listCrmModel.stream().filter(it -> it.testCaseName.contains("Test_homepage"))
				.collect(Collectors.toList());

		return td_Test_Homepage;
	}
	
	public List<CrmModel> setTestDataForTest_cartpage() {
		td_Test_cartpage = listCrmModel.stream().filter(it -> it.testCaseName.contains("Test_cartpage"))
				.collect(Collectors.toList());

		return td_Test_cartpage;
	}
	
	public List<CrmModel> setTestDataForTest_hello() {
		td_Test_hello = listCrmModel.stream().filter(it -> it.testCaseName.contains("Test_hello"))
				.collect(Collectors.toList());

		return td_Test_hello;
	}

}
