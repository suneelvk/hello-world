package org.shell.tcoe.context;

import org.openqa.selenium.WebDriver;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.pageobjects.CrmHomePageControls;
import org.shell.tcoe.pageobjects.CrmLoginPageControls;
import org.shell.tcoe.pageobjects.DemoAppPageControls;
import org.shell.tcoe.pageobjects.GoogleWebAppPageControls;
import org.shell.tcoe.pageobjects.HomePageControls;
import org.shell.tcoe.pageobjects.LoginPageControls;
import org.shell.tcoe.pageobjects.SalesforceLoginPageControls;
import org.shell.tcoe.pages.CrmHomePage;
import org.shell.tcoe.pages.CrmLoginPage;
import org.shell.tcoe.pages.DemoAppPage;
import org.shell.tcoe.pages.GoogleWebAppPage;
import org.shell.tcoe.pages.HomePage;

import org.shell.tcoe.pages.LoginPage;
import org.shell.tcoe.pages.SalesforceLoginPage;


import io.appium.java_client.AppiumDriver;

/*import org.shell.tcoe.pagesConfirmationPage;

import org.shell.tcoe.pagesHomePage;

import org.shell.tcoe.pagesProductListingPage;*/



public class PageObjectManager {

	private WebDriver driver;
	
	private AppiumDriver appiumDriver;
	
	private LoginPage loginPage;

	private HomePage homePage;
	
	private CrmLoginPage crmloginPage;

	private CrmHomePage crmhomePage;
	
	private DemoAppPage demoappPage;
	
	private GoogleWebAppPage googleWebAppPage;
	
	private SalesforceLoginPage salesforceLoginPage;
	
	
/*	private ProductListingPage productListingPage;

	private CheckoutPage checkoutPage;

	private ConfirmationPage confirmationPage;*/

	

	public PageObjectManager() {

		//this.driver = driver;

		this.driver = TestBase.driver;
		
		this.appiumDriver = TestBase.appiumDriver;
	}
	
	
	public SalesforceLoginPage getSalesforceLoginPage(){

		return (salesforceLoginPage == null) ? salesforceLoginPage = new SalesforceLoginPage(driver, new SalesforceLoginPageControls()) : salesforceLoginPage;

	}

	public DemoAppPage getDemoAppPage(){

		return (demoappPage == null) ? demoappPage = new DemoAppPage(appiumDriver, new DemoAppPageControls()) : demoappPage;

	}



	public HomePage getHomePage(){

		return (homePage == null) ? homePage = new HomePage(driver, new HomePageControls()) : homePage;

	}

	

	public LoginPage getLoginPage() {

		return (loginPage == null) ? loginPage = new LoginPage(driver,new LoginPageControls()) : loginPage;

	}

	public CrmHomePage getCrmHomePage(){

		return (crmhomePage == null) ? crmhomePage = new CrmHomePage(driver, new CrmHomePageControls()) : crmhomePage;

	}

	

	public CrmLoginPage getCrmLoginPage() {

		return (crmloginPage == null) ? crmloginPage = new CrmLoginPage(driver,new CrmLoginPageControls()) : crmloginPage;

	}
	
	public GoogleWebAppPage getGoogleWebAppPage() {
		return (googleWebAppPage == null) ? googleWebAppPage = new GoogleWebAppPage(appiumDriver,new GoogleWebAppPageControls()) : googleWebAppPage;

	}

	/*public CartPage getCartPage() {

		return (cartPage == null) ? cartPage = new CartPage(driver) : cartPage;

	}

	

	public CheckoutPage getCheckoutPage() {

		return (checkoutPage == null) ? checkoutPage = new CheckoutPage(driver) : checkoutPage;

	}*/
}