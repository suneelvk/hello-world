package org.shell.tcoe.context;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class TestContext {

	private PageObjectManager pageObjectManager;
	
	private TestObjectManager testObjectManager;

	public TestContext() throws InstantiationException, IllegalAccessException,
	IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, IOException {
		this.pageObjectManager = new PageObjectManager();
		this.testObjectManager = new TestObjectManager();
		
	}

	public PageObjectManager getPageObjectManager() {
		return pageObjectManager;
	}
	
	public TestObjectManager getTestObjectManager() {
		return testObjectManager;
	}
	
	
	

}
