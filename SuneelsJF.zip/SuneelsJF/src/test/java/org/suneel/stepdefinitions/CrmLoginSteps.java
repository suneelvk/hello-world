package org.shell.tcoe.stepdefinitions;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.context.TestContext;
import org.testng.Assert;

import com.mysql.jdbc.Driver;

import org.shell.tcoe.helper.LoggerHelper;
import org.shell.tcoe.models.CrmModel;
import org.shell.tcoe.pages.CrmHomePage;
import org.shell.tcoe.pages.CrmLoginPage;

import org.shell.tcoe.utilities.BrowserUtilities;
import org.shell.tcoe.utilities.ExcelDataToDataTable;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CrmLoginSteps {
	TestContext testContext;
	CrmLoginPage crmloginPage;
	CrmHomePage crmhomePage;
	String uname, pwd;
	List<CrmModel> testdata_Test_Login;
	List<CrmModel> testdata_Test_homepage;
	List<CrmModel> testdata_Test_hello;
	

	public CrmLoginSteps(TestContext context) {
		testContext = context;
		crmloginPage = testContext.getPageObjectManager().getCrmLoginPage();
		crmhomePage = testContext.getPageObjectManager().getCrmHomePage();
		
		testdata_Test_Login = testContext.getTestObjectManager().setTestDataForTest_login();
		testdata_Test_homepage = testContext.getTestObjectManager().setTestDataForTest_homepage();
		testdata_Test_hello=testContext.getTestObjectManager().setTestDataForTest_hello();
		
	}
	
	
	@Given("^I am on the login page of CRM application$")
	public void i_am_on_the_login_page_of_CRM_application() throws Throwable {
		crmloginPage.navigatetoLoginPage(TestBase.global_configProperties.get("applURL"));
	}

	@When("^invalid credentials are submitted$")
	public void invalid_credentials_are_submitted() throws Throwable {
		crmloginPage.loginToGuru99(testdata_Test_Login.get(0).userName, testdata_Test_Login.get(0).password);
		
		/*System.out.println(testdata_Test_Login.get(1).userName);
		System.out.println(testdata_Test_hello.get(0).water);*/
		Thread.sleep(5000);
		//System.out.println("testdata_Test_hello.get(0).userName"+testdata_Test_hello.get(0).userName);
	}

	@Then("^I validate proper error message appears$")
	public void i_validate_proper_error_message_appears() throws Throwable {
		
		boolean stat = false;
	    try 
		{ 
	    	TestBase.driver.switchTo().alert(); 
		    System.out.println(" Alert Present");
		    stat=true;
		}  
		catch (NoAlertPresentException e) 
		{ 
		    System.out.println("No Alert Present");
		}   
	    if(stat) {
	    	Assert.assertEquals(TestBase.driver.switchTo().alert().getText(),"User or Password is not valid");
	    }
	}
	
	@When("^valid credentials are submitted$")
	public void valid_credentials_are_submitted() throws Throwable {
		crmloginPage.loginToGuru99(testdata_Test_homepage.get(0).userName, testdata_Test_homepage.get(0).password);
	}

	@Then("^I validate home-page appears$")
	public void i_validate_home_page_appears() throws Throwable {
		System.out.println(crmhomePage.getHomePageDashboardUserName().toLowerCase());
		//Assert.assertTrue(crmhomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mngr198534"));
		Assert.assertTrue(crmhomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : hkhmngr198534"));
		//Assert.assertTrue(crmhomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : "+testdata_Test_homepage.get(0).userName));
	}

}
