package org.shell.tcoe.stepdefinitions;

import java.util.List;

import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.context.TestContext;
import org.shell.tcoe.helper.LoggerHelper;
import org.shell.tcoe.pages.DemoAppPage;
import org.shell.tcoe.pages.GoogleWebAppPage;
import org.shell.tcoe.utilities.DatabaseDataToDataTable;
import org.shell.tcoe.utilities.ExcelDataToDataTable;
import org.testng.Assert;

import cucumber.api.DataTable;
import cucumber.api.Transform;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleWebAppSteps {
	TestContext testContext;

	GoogleWebAppPage googleWebapppage;

	public GoogleWebAppSteps(TestContext context) {
		testContext = context;
		googleWebapppage = testContext.getPageObjectManager().getGoogleWebAppPage();		
	}

	@When("^I do a basic flow on google url$")
	public void i_do_a_basic_flow_on_google_url() throws Throwable {
		googleWebapppage.navigate();		
	}

}
