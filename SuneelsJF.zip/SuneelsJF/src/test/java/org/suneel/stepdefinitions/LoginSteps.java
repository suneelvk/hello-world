package org.shell.tcoe.stepdefinitions;

import java.util.List;

import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.context.TestContext;
import org.testng.Assert;

import org.shell.tcoe.helper.LoggerHelper;
import org.shell.tcoe.pages.HomePage;
import org.shell.tcoe.pages.LoginPage;

import org.shell.tcoe.utilities.ExcelDataToDataTable;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	TestContext testContext;
	LoginPage loginPage;
	HomePage homePage;
	String uname, pwd;

	public LoginSteps(TestContext context) {
		testContext = context;
		loginPage = testContext.getPageObjectManager().getLoginPage();
		homePage = testContext.getPageObjectManager().getHomePage();
		// super();
	}

	@Given("^I am on the Login page of \"([^\"]*)\"$")
	public void i_am_on_the_Login_page_of(String arg1) throws Throwable {
		// driver.navigate().to(arg1);
		loginPage.navigatetoLoginPage(arg1);
	}

	@Then("^I should see the login page$")
	public void i_should_see_the_login_page() throws Throwable {
		// loginPage = new LoginPage();
		Assert.assertEquals("Sign in [Jenkins]", loginPage.validateLoginPageTitle());
	}

	@When("^I enter username as \"([^\"]*)\"$")
	public void i_enter_username_as(String arg1) throws Throwable {
		uname = arg1;
	}

	@When("^I enter password as \"([^\"]*)\"$")
	public void i_enter_password_as(String arg1) throws Throwable {
		loginPage.login(uname, arg1);
		System.out.println(uname);
		System.out.println(arg1);
	}

	@When("^click on login button$")
	public void click_on_login_button() throws Throwable {
		System.out.println("Login _button Clicked");
	}

	@Then("^I should see Login Error message$")
	public void i_should_see_Login_Error_message() throws Throwable {
		loginPage.validateInvalidLoginMessage();
	}

	@Then("^I should see Home -page$")
	public void i_should_see_Home_page() throws Throwable {
		//homePage = new HomePage();
		Assert.assertEquals("Dashboard [Jenkins]", homePage.validateLoginPageTitle());

	}

	@Given("^I want to write a step with name(\\d+)$")
	public void i_want_to_write_a_step_with_name(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^I check for the (\\d+) in step$")
	public void i_check_for_the_in_step(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// Assert.assertTrue(false);

	}

	@Then("^I verify the success in step$")
	public void i_verify_the_success_in_step() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^I verify the Fail in step$")
	public void i_verify_the_Fail_in_step() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^I enter different credentials for login from excel file \"([^\"]*)\"$") // DatabaseUtilities
	public void i_enter_different_credentials_for_login_from_excel_file(
			@Transform(ExcelDataToDataTable.class) DataTable table) throws Throwable {
		LoggerHelper.getlogger(LoginSteps.class).info("Staring Step with different test data");
		System.out.println(table.toString());
		List<List<String>> list = table.asLists(String.class);
		/*
		 * for(int i=1; i<list.size(); i++) { //i starts from 1 because i=0 represents
		 * the header System.out.println(list.get(i).get(0));
		 * System.out.println(list.get(i).get(1));
		 * System.out.println(list.get(i).get(2)); loginPage.login(list.get(i).get(1),
		 * list.get(i).get(2)); System.out.println("------------"); }
		 */
		loginPage.login(list.get(0).get(1), list.get(0).get(2));
		loginPage.validateInvalidLoginMessage();
		LoggerHelper.getlogger(LoginSteps.class).info("Ending Step with different test data");
	}
}
