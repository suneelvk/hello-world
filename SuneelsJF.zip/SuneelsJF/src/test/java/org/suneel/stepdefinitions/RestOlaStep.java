package org.shell.tcoe.stepdefinitions;

//
import cucumber.api.DataTable;
import cucumber.api.Transform;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.*;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hamcrest.Matcher;
import org.shell.tcoe.api.ApiUtilities;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.pojos.PostsPojo;
import org.shell.tcoe.utilities.ExcelDataToDataTable;
import org.testng.Assert;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.vimalselvam.cucumber.listener.Reporter;
//

import io.restassured.RestAssured;
import io.restassured.filter.log.*;
import io.restassured.response.Response;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RestOlaStep {
	RequestSpecification rspec;

	Response response;
	Response response2;

	@Given("^I am using rest api  \"([^\"]*)\"$")
	public void i_am_using_rest_api(String baseURI) {

		rspec = ApiUtilities.setUpBaseURI(baseURI);

	}

	@When("^I change basepath as \"([^\"]*)\"$")
	public void i_change_basepath_as(String basePath) {
		rspec = ApiUtilities.setUpBasePath(basePath);

		response = ApiUtilities.executeMethodGET(rspec, "");
	}

	@When("^I enter endpoint as \"([^\"]*)\"$")
	public void i_enter_endpoint_as(String endPoint) {

		response = ApiUtilities.executeMethodGET(rspec, endPoint);
	}

	@Then("^I should get status \"([^\"]*)\"$")
	public void i_should_get_status(int statusCode) {

		ApiUtilities.assertStatusCode(response, statusCode);

	}

	@Then("^I should validate path \"([^\"]*)\" as \"([^\"]*)\"$")
	public void i_should_validate_path_as(String path, String pathValue) {

		ApiUtilities.validateResponseUsingPath(response, path, pathValue);
	}

	@When("^and I POST data id:\"([^\"]*)\",Title:\"([^\"]*)\",Author:\"([^\"]*)\"$")
	public void and_I_POST_data_id_Title_Author(String id, String Title, String Author) {
		PostsPojo bodyPosts = new PostsPojo();
		bodyPosts.setId(id);
		bodyPosts.setTitle(Title);
		bodyPosts.setAuthor(Author);

		rspec = ApiUtilities.invokeRequestSpecification("");

		response = ApiUtilities.executeMethodPOST(rspec, "", bodyPosts);
	}

	@Then("^I validate the statuscode is (\\d+)$")
	public void i_validate_the_statuscode_is(int statusCode) {
		ApiUtilities.assertStatusCode(response, statusCode);
	}

	@Then("^check the response body path of \"([^\"]*)\" as \"([^\"]*)\"$")
	public void check_the_response_body_path_of_as(String path, String pathValue) {
		ApiUtilities.validateResponseUsingPath(response, path, pathValue);
	}

	@When("^and I PUT data id:\"([^\"]*)\",Title:\"([^\"]*)\",Author:\"([^\"]*)\" on endpoint \"([^\"]*)\"$")
	public void and_I_PUT_data_id_Title_Author_on_endpoint(String id, String Title, String Author, String endpoint) {
		PostsPojo bodyPosts = new PostsPojo();
		bodyPosts.setId(id);
		bodyPosts.setTitle(Title);
		bodyPosts.setAuthor(Author);

		rspec = ApiUtilities.invokeRequestSpecification("");

		response = ApiUtilities.executeMethodPUT(rspec, endpoint, bodyPosts);

	}

	@When("^and I PATCH data Author:\"([^\"]*)\" on endpoint \"([^\"]*)\"$")
	public void and_I_PATCH_data_Author_on_endpoint(String author, String endpoint) {
		PostsPojo bodyPosts = new PostsPojo();
		/*
		 * bodyPosts.setId(id); bodyPosts.setTitle(Title);
		 */
		bodyPosts.setAuthor(author);

		// String objStr = "\"author\": \"pal";

		rspec = ApiUtilities.invokeRequestSpecification("");

		response = ApiUtilities.executeMethodPATCH(rspec, endpoint, bodyPosts);

	}

	@When("^I delete data on endpoint \"([^\"]*)\"$")
	public void i_delete_data_on_endpoint(String endpoint) {
		rspec = ApiUtilities.invokeRequestSpecification("");

		response = ApiUtilities.executeMethodDELETE(rspec, endpoint);

	}

	@When("^I try a GET service$")
	public void i_try_a_GET_service() {
		rspec = ApiUtilities.invokeRequestSpecification("");

		response = ApiUtilities.executeMethodGET(rspec, "");

	}

	@Then("^I validate the time is lessthan (\\d+)$")
	public void i_validate_the_time_is_lessthan(long time) throws Throwable {
		ApiUtilities.validateResponseTimeisLessthan(response, time);
	}

	@Then("^I validate the schema is fine using classpath \"([^\"]*)\"$")
	public void i_validate_the_schema_is_fine_using_classpath(String classPath) {
		ApiUtilities.validateResponseJsonSchema(response, classPath);

	}

	@When("^I do a basic premptive authentication using \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_do_a_basic_premptive_authentication_using(String uName, String uPwd) {

		ApiUtilities.authenticateBasic(rspec, uName, uPwd);

		response = ApiUtilities.executeMethodGET(rspec, "");

	}

	@When("^I have send get request to api \"([^\"]*)\" and api \"([^\"]*)\"$")
	public void i_have_send_get_request_to_api_and_api(String arg1, String arg2) {

		rspec = ApiUtilities.setUpBaseURI(arg1);
		response = ApiUtilities.executeMethodGET(rspec, arg1);

		rspec = ApiUtilities.setUpBaseURI(arg2);
		response2 = ApiUtilities.executeMethodGET(rspec, arg2);
	}

	@Then("^I should validate response in api is equal to api$")
	public void i_should_validate_response_in_api_is_equal_to_api() {

		ApiUtilities.assertListResponsesAreEqual(response, response2);

	}

	@When("^I enter different endpoints and verify the status and path from excel file \"([^\"]*)\"$")
	public void i_enter_different_endpoints_and_verify_the_status_and_path_from_excel_file(
			@Transform(ExcelDataToDataTable.class) DataTable table) {
		System.out.println(table.toString());

		List<List<String>> list = table.asLists(String.class);
		for (int i = 1; i < list.size(); i++) {
			// i starts from 1 because i=0 represents the header

			Reporter.addStepLog("setUp BasePath as " + list.get(i).get(0));
			rspec = ApiUtilities.setUpBasePath(list.get(i).get(0).trim());

			response = ApiUtilities.executeMethodGET(rspec, "");

			double dStat = Double.parseDouble(list.get(i).get(1).trim());
			int intStatus = (int) dStat;
			Reporter.addStepLog("assert StatusCode as " + intStatus);
			ApiUtilities.assertStatusCode(response, intStatus);

			Reporter.addStepLog(
					"validate the Response of Path  " + list.get(i).get(2).trim() + " as " + list.get(i).get(3).trim());
			ApiUtilities.validateResponseUsingPath(response, list.get(i).get(2).trim(), list.get(i).get(3).trim());

			Reporter.addStepLog("------------");
		}

	}

	@When("^and I use spec \"([^\"]*)\"$")
	public void and_I_use_spec(String arg1) {

		rspec = ApiUtilities.invokeRequestSpecification(arg1);
		response = ApiUtilities.executeMethodGET(rspec, "");
	}

	@When("^I use spec \"([^\"]*)\" using proxy \\[ host :\"([^\"]*)\" and port : (\\d+) and POST \\] data as node: \"([^\"]*)\", emailto :\"([^\"]*)\"$")
	public void i_use_spec_using_proxy_host_and_port_and_POST_data_as_node_emailto(String specName, String host,
			int port, String arg4, String arg5) throws Throwable {
		String bodyPosts = "{\"" + arg4 + "\": \"" + arg5 + "\"}";

		rspec = ApiUtilities.invokeRequestSpecification(specName);

		ApiUtilities.setProxy(rspec, host, port);

		rspec.filter(new RequestLoggingFilter(TestBase.requestCapture));
		rspec.filter(new ResponseLoggingFilter(TestBase.responseCapture));
		response = ApiUtilities.executeMethodPOST(rspec, "", bodyPosts);
//given().multiPart(new File("anb")).expect().body(rspec)
		// upload file

		/*
		 * rspec.multiPart("file1", new File("arg1")) .when().
		 * post("/advancedFileUpload");
		 */

		// download file
		/*
		 * private void downloadUrlAsFile( final Map<String,String> cookies, final
		 * Map<String,String> headers, final String urlToDownload, final File
		 * outputPath, final String filename) throws IOException {
		 * 
		 * File outputFile = new File(outputPath.getPath(), filename);
		 * 
		 * 
		 * final Response response = RestAssured.given(). headers(headers).
		 * cookies(cookies). when(). get(urlToDownload). andReturn();
		 * 
		 * // check if the URL actually exists if(response.getStatusCode() == 200){
		 * 
		 * if (outputFile.exists()) { outputFile.delete(); }
		 * 
		 * System.out.println("Downloaded an " + response.getHeader("Content-Type"));
		 * 
		 * byte[] fileContents = response.getBody().asByteArray();
		 * 
		 * // output contents to file OutputStream outStream=null;
		 * 
		 * try { outStream = new FileOutputStream(outputFile);
		 * outStream.write(fileContents); }catch(Exception e){
		 * System.out.println("Error writing file " + outputFile.getAbsolutePath());
		 * }finally { if(outStream!=null){ outStream.close(); } } } }
		 */

		/*
		 * public static void assertXMLEquals(FileReader expectedXML, FileReader
		 * actualXML) throws Exception { XMLUnit.setXSLTVersion("2.0");
		 * XMLUnit.setIgnoreWhitespace(true); XMLUnit.setIgnoreAttributeOrder(true);
		 * XMLUnit.setIgnoreDiffBetweenTextAndCDATA(Boolean.TRUE);
		 * XMLUnit.setIgnoreComments(Boolean.TRUE);
		 * XMLUnit.setNormalizeWhitespace(Boolean.TRUE);
		 * XMLUnit.setCompareUnmatched(true);
		 * 
		 * // String node; DetailedDiff diff = new
		 * DetailedDiff(XMLUnit.compareXML(expectedXML, actualXML)); //
		 * System.out.println("similarity"+diff.similar()); if(!diff.similar()){
		 * 
		 * List<Difference> lDiff=diff.getAllDifferences(); throw new
		 * RuntimeException("Xml comparison failed because of follwoing error"+lDiff); }
		 * }
		 * 
		 * To validate the code create a main method read expected and actual file using
		 * file reader as follows:
		 * 
		 * public static void main(String[] args) throws Exception { // TODO
		 * Auto-generated method stub FileReader file=new
		 * FileReader(System.getProperty("user.dir") +"/backup/config.xml"); FileReader
		 * file1=new FileReader(System.getProperty("user.dir") +"/config.xml");
		 * assertXMLEquals(file,file1); }
		 */

		// http://himadridas20.blogspot.com/2015/02/how-to-compare-two-xml-files-in-java.html
	}

	@Given("^I use spec \"([^\"]*)\"$")
	public void i_use_spec(String arg1) throws Throwable {
		rspec = ApiUtilities.invokeRequestSpecification(arg1);
	}

	@When("^I try to upload file placed at \"([^\"]*)\"$")
	public void i_try_to_upload_file_placed_at(String arg1) throws Throwable {
		// response = ApiUtilities.executeMethodPOST(rspec, endPoint, objPost) need to
		// update this to upload file

	}

	@Then("^I validate the response is (\\d+)$")
	public void i_validate_the_response_is(int statusCode) throws Throwable {
		ApiUtilities.assertStatusCode(response, statusCode);
	}

	@Given("^I use uri \"([^\"]*)\"$")
	public void i_use_uri(String arg1) throws Throwable {

	}

	@When("^I try to download file placed at \"([^\"]*)\"$")
	public void i_try_to_download_file_placed_at(String arg1) throws Throwable {
		String specName = "downloads";

		rspec = ApiUtilities.invokeRequestSpecification(specName);

		ApiUtilities.setProxy(rspec, "zproxy-bngeco.asia-pac.shell.com", 8080);

		rspec.filter(new RequestLoggingFilter(TestBase.requestCapture));
		rspec.filter(new ResponseLoggingFilter(TestBase.responseCapture));

		// sometimes we might be bypassing login or need login credentials created by
		// cookies
		// we can create a hashmap of cookies if we need to
						Map<String, String> cookies = new HashMap();
		// e.g. if I needed to inject a session cookie
						// cookies.put("session_id", Secret.SESSION_ID);

		// sometimes our access controls might be via headers so I might need to set
		// those up
		// we can create a hashmap of headers if we need to
						Map<String, String> headers = new HashMap();
						// cookies.put("X-AUTH-CODE", Secret.AUTH_CODE_HEADER);

		// rspec.headers(headers).cookies(cookies)

		response = ApiUtilities.executeMethodGET(rspec, "");

		String downloadFolder = "downloads";
		File outputPath = new File(downloadFolder);

		// create the folder structure if it does not exist
		outputPath.mkdirs();
		
		// if your url was extracted from a json respose in another message then you
		// might need to decode it first
		// to make sure it is a completely valid URL e.g. doesn't have any \u0026 type
		// values
		//    String urlToDownload = "https://avatars3.githubusercontent.com/u/2621217?s=40&v=4";
		// String
		// urlToDownload="https://raw.githubusercontent.com/eviltester/libraryexamples/master/src/test/java/uk/co/compendiumdev/libraryexamples/restassured/SwapiAPIUsageTest.java";
		// urlToDownload = UrlDecoder.urlDecode(urlToDownload, Charset.defaultCharset(),
		// false);  ///this line of code requires higher restassured package

		// Sometimes I add a timestamp to the file e.g.
		// String downloadFileName = "downloadedFile_" + System.currentTimeMillis() +
		// "_.txt";

		// Sometimes I add a GUID to the file e.g.
		// String downloadFileName = "downloadedFile_" + UUID.randomUUID() + "_.txt";

		// the point is, control the filename so you know what you are downloading
		

		String downloadFileName = "downloadedFile.png";

		File checkDownloaded = new File(outputPath.getPath(), downloadFileName);
		if (checkDownloaded.exists()) {
			checkDownloaded.delete();
		}

		if (response.getStatusCode() == 200) {

			
			
			ApiUtilities.downloadFileFromResponse(response, downloadFolder, downloadFileName);

			// Added an assert to check if file exists
			checkDownloaded = new File(outputPath.getPath(), downloadFileName);
			Assert.assertTrue(checkDownloaded.exists());

		}

	}

}