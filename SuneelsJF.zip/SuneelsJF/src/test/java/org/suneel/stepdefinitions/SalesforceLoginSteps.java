package org.shell.tcoe.stepdefinitions;

import java.util.List;

import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.context.TestContext;
import org.shell.tcoe.models.CrmModel;
import org.shell.tcoe.models.SfModel;
import org.shell.tcoe.pages.SalesforceLogOutPage;
import org.shell.tcoe.pages.SalesforceLoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SalesforceLoginSteps {
	
	TestContext testContext;
	SalesforceLoginPage salesforceLoginPage;
	SalesforceLogOutPage salesforceLogOutPage;
	
	
	String uname, pwd;
	
	
	List<SfModel> testdata_Test_Login;
	
	public SalesforceLoginSteps(TestContext context) {
		testContext = context;
		salesforceLoginPage= testContext.getPageObjectManager().getSalesforceLoginPage();		
		testdata_Test_Login = testContext.getTestObjectManager().setSfTestDataForTest_login();
		
	}
	
	
	@Given("^I am on the login page of Salesforce application$")
	public void i_am_on_the_login_page_of_Salesforce_application() {
		//salesforceLoginPage.navagetoSalesforceLoginPage(TestBase.global_configProperties.get("applURL").toString());
		
		salesforceLoginPage.navagetoSalesforceLoginPage("https://www.google.com/");
		
	}

	@When("^valid Salesforce credentials are submitted$")
	public void valid_salesforce_credentials_are_submitted() throws Throwable {
		//salesforceLoginPage.salesforcelogin(testdata_Test_Login.get(0).userName, testdata_Test_Login.get(0).password);
		System.out.println(testdata_Test_Login.get(0).userName);
	}

	@Then("^I validate Salesforce home-page appears$")
	public void i_validate_salesforce_home_page_appears() throws Throwable {
		//salesforceLogOutPage.SalesforceLogOut();
		System.out.println(testdata_Test_Login.get(0).password);
	}

}

