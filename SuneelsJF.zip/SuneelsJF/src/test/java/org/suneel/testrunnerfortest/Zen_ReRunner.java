package org.shell.tcoe.testrunnerfortest;


import java.io.File;

import org.shell.tcoe.base.TestBase;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		features = {"@target/cucumber-reports/*.txt"},
		glue = { "org.shell.tcoe.stepdefinitions","org.shell.tcoe.testrunner","org.shell.tcoe.testrunnerfortest" }, 
	  monochrome=true,
//	  dryRun =true,
		plugin = { "pretty","html:target/cucumber-reports/cucumber-pretty",
				"json:target/cucumber-reports/CucumberTestReport.json",
				"rerun:target/cucumber-reports/rerun.txt",
				"com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:output/TCOE_API_Report.html" 		})


	public class Zen_ReRunner extends AbstractTestNGCucumberTests {
	@AfterClass
    public static void teardown2() { 
		try {
        Reporter.loadXMLConfig(new File("src/test/resources/Configuration/extent_config.xml"));//C:\Users\V.Kalluru\workspace\TCOE_SeleniumFramework\src\test\resources\Configuration\extent_config.xml
       
        
        Reporter.setSystemInfo("user", System.getProperty("user.name"));
        Reporter.setSystemInfo("os", "Windows");
        Reporter.setTestRunnerOutput("Sample test runner output message");
		}
        catch(Exception e) 
        {
        	System.out.println(e.getMessage());
        }
		
        

        	
        
    }
	
	@BeforeClass
	public static void setup() {
		TestBase.execVia="runner";
		
	}

}
