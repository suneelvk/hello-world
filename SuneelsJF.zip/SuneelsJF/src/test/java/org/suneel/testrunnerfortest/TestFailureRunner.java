package org.suneel.testrunnerfortest;

import java.io.File;
//--
/*import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;*/
//import com.github.mkolisnyk.cucumber.runner.ExtendedTestNGRunner;

import org.suneel.base.TestBase;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

//@ExtendedCucumberOptions(retryCount=3 ,includeCoverageTags = {"@failed" } )
@CucumberOptions(
		features = "@target/cucumber-reports/rerun.txt",

		glue = { "org.shell.tcoe.stepdefinitions","org.shell.tcoe.testrunner","org.shell.tcoe.testrunnerfortest" }, 
	  monochrome=true,
//	  dryRun =true,
		plugin = { "pretty","html:target/cucumber-reports/cucumber-pretty",
				"json:target/cucumber-reports/CucumberTestReport.json",
				"rerun:target/cucumber-reports/rerun.txt",
				"com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:output/TCOE_API_Report.html" 		})
public class TestFailureRunner extends AbstractTestNGCucumberTests {
	@AfterClass
    public static void teardown() { 
        Reporter.loadXMLConfig(new File("src/test/resources/Configuration/extent_config.xml"));//C:\Users\V.Kalluru\workspace\TCOE_SeleniumFramework\src\test\resources\Configuration\extent_config.xml
       
        
        Reporter.setSystemInfo("user", System.getProperty("user.name"));
        Reporter.setSystemInfo("os", "Windows");
        Reporter.setTestRunnerOutput("Sample test runner output message");
    }
	
	@BeforeClass
	public static void setup() {
		TestBase.execVia="runner";
		
	}

}
