package org.shell.tcoe.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesforceLogOutPageControls {

	@FindBy(xpath="//*[@class='action-link' and @href='/secur/logout.jsp']")
	public WebElement LogOut;
	
	
	@FindBy(xpath="//img[@class='icon noicon' and @title='User']")
	public WebElement UserProfile;
	
	@FindBy(xpath="//*[@class='profile-link-label logout uiOutputURL']")
	public WebElement UserProfileLogOut;
	
	@FindBy(xpath="//input[@id='username']")
	public WebElement UserName;	
	
}
