package org.shell.tcoe.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePageControls {
	
	@FindBy(name="j_username")
	public WebElement txtBox_username;
	
	@FindBy(name="j_password")
	public WebElement txtBox_password;
	
	@FindBy(name="Submit")
	public WebElement btn_Submit;
	
	@FindBy(className="alert-danger")
	public WebElement lbl_Invalid_Login_Error_Message;
	

}
