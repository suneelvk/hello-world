package org.shell.tcoe.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class DemoAppPageControls {
	
	   	//@iOSFindBy(xpath = "//*[contains(text(),'Test')]")
		@iOSXCUITFindBy(xpath = "//*[contains(text(),'Test')]")
	    @AndroidFindBy(xpath = "//*[contains(text(),'Test')]")
	    public MobileElement btn_Test1;
		
//		@iOSXCUITFindBy(id = "Accessibility")
//	    @AndroidFindBy(id = "Accessibility")
//	    public MobileElement lbl_Accessibility;
		
		@iOSXCUITFindBy(id = "Accessibility")
	    @AndroidFindBy(id = "Accessibility")
	    public MobileElement lbl_Accessibility;
		
		
		@iOSXCUITFindBy(id = "Views")
	    @AndroidFindBy(id = "Views")
	    public MobileElement lbl_Views;
		
		@iOSXCUITFindBy(id = "Tabs")
	    @AndroidFindBy(id = "Tabs")
	    public MobileElement lbl_Tabs;
		
		@iOSXCUITFindBy(id = "1")
	    @AndroidFindBy(id = "com.android.calculator2:id/digit_1")
	    public MobileElement cal_Btn_1;
		
		@iOSXCUITFindBy(id = "2")
	    @AndroidFindBy(id = "com.android.calculator2:id/digit_2")
	    public MobileElement cal_Btn_2;
	

		@iOSXCUITFindBy(id = "x")
		@AndroidFindBy(id = "com.android.calculator2:id/op_add")
		public MobileElement cal_Btn_X;
}
