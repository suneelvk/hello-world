package org.shell.tcoe.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesforceLoginPageControls {

	@FindBy(xpath="//*[@id='use_new_identity']")
	public WebElement LogInWithADifferentUsername;
	
	@FindBy(xpath="//input[@id='username']")
	public WebElement UserName;
	
	@FindBy(xpath="//input[@id='password']")
	public WebElement Password;
	
	@FindBy(xpath="//*[@id='Login' and @type='submit']")
	public WebElement Submit;
	
	@FindBy(xpath="//*[@id='confirmpassword']")
	public WebElement ConfirmPassword;
}

