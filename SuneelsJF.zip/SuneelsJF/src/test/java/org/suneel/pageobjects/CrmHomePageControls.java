package org.shell.tcoe.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CrmHomePageControls {
	

    @FindBy(xpath="//table//tr[@class='heading3']")
   public  WebElement homePageUserName;    

	

}
