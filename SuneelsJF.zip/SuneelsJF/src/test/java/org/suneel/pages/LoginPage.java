package org.shell.tcoe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.pageobjects.LoginPageControls;
import org.testng.Assert;

public class LoginPage {

	WebDriver driver;
	LoginPageControls loginPageControls;

	public LoginPage(WebDriver driver, LoginPageControls loginPageControls) {
		this.driver = driver;
		this.loginPageControls = loginPageControls;
		PageFactory.initElements(driver, this.loginPageControls);
	}

	public void navigatetoLoginPage(String url) {
		driver.navigate().to(url);
	}

	public String validateLoginPageTitle() {
		return driver.getTitle();
	}

	public void login(String uName, String pwd) {
		loginPageControls.txtBox_username.sendKeys(uName);
		loginPageControls.txtBox_password.sendKeys(pwd);
		loginPageControls.btn_Submit.submit();

	}

	public void validateInvalidLoginMessage() {
		Assert.assertTrue(loginPageControls.lbl_Invalid_Login_Error_Message.isDisplayed());
	}

}
