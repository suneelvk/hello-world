package org.shell.tcoe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.shell.tcoe.base.BasePage;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.pageobjects.DemoAppPageControls;
import org.shell.tcoe.utilities.Utilities;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class DemoAppPage extends Utilities{

	
	AppiumDriver appiumDriver;
	DemoAppPageControls demoAppPageControls;

	

	public DemoAppPage(AppiumDriver appiumDriver, DemoAppPageControls demoAppPageControls) {
		super(appiumDriver);
		this.appiumDriver = appiumDriver;
		this.demoAppPageControls = demoAppPageControls;

		PageFactory.initElements(new AppiumFieldDecorator(this.appiumDriver), this.demoAppPageControls);
		
	}
	
	
	

	public void clickLabel() {
		demoAppPageControls.lbl_Views.click();
	}
	
	public void CalcFun() throws InterruptedException {
		demoAppPageControls.cal_Btn_1.click();
		Thread.sleep(1000);
		demoAppPageControls.cal_Btn_X.click();
		demoAppPageControls.cal_Btn_2.click();
		
		
	}
	
	
	
	
	
}
