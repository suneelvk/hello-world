package org.shell.tcoe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.shell.tcoe.pageobjects.SalesforceLogOutPageControls;
import org.testng.Assert;

public class SalesforceLogOutPage {

	WebDriver driver;
	SalesforceLogOutPageControls salesforceLogOutPageControls;
	
	public SalesforceLogOutPage(WebDriver driver, SalesforceLogOutPageControls salesforceLogOutPageControls) {
		this.driver = driver;
		this.salesforceLogOutPageControls = salesforceLogOutPageControls;
		PageFactory.initElements(driver, this.salesforceLogOutPageControls);
	}
	
	//LogOut from Salesforce Application
	public void SalesforceLogOut() {
		if (salesforceLogOutPageControls.LogOut.isEnabled()) {
			salesforceLogOutPageControls.LogOut.click();
				if (salesforceLogOutPageControls.UserName.isEnabled()){
					System.out.println("Sucessfully Logged Out of salesforce Application");
				}
			} 
		else if (salesforceLogOutPageControls.UserProfile.isEnabled()) {
			salesforceLogOutPageControls.UserProfile.click();
			salesforceLogOutPageControls.UserProfileLogOut.click();	
				if (salesforceLogOutPageControls.UserName.isEnabled()){
					System.out.println("Sucessfully Logged Out of salesforce Application");
				}
			} 
		else {
			System.out.println("Logged Out from salesforce Application is Not Successful");
		}
	}
}




