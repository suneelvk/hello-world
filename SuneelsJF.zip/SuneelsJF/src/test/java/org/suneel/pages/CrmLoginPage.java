package org.shell.tcoe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.shell.tcoe.pageobjects.CrmLoginPageControls;



public class CrmLoginPage {

    
	WebDriver driver;
	CrmLoginPageControls crmLoginPageControls;
   

	public CrmLoginPage(WebDriver driver, CrmLoginPageControls crmloginPageControls) {
		this.driver = driver;
		this.crmLoginPageControls = crmloginPageControls;
		PageFactory.initElements(driver, this.crmLoginPageControls);
	}

	public void navigatetoLoginPage(String url){

       this.driver.navigate().to(url);   
    }
	
    //Set user name in textbox
    public void setUserName(String strUserName){

        crmLoginPageControls.user99GuruName.sendKeys(strUserName);     
    }

    //Set password in password textbox

    public void setPassword(String strPassword){

    	crmLoginPageControls.password99Guru.sendKeys(strPassword);

    }

    //Click on login button

    public void clickLogin(){

    	crmLoginPageControls.login.click();

    }  

    //Get the title of Login Page

    public String getLoginTitle(){

     return    crmLoginPageControls.titleText.getText();

    }

    /**

     * This POM method will be exposed in test case to login in the application

     * @param strUserName

     * @param strPasword

     * @return

     */

    public void loginToGuru99(String strUserName,String strPasword){

        //Fill user name

        this.setUserName(strUserName);

        //Fill password

        this.setPassword(strPasword);

        //Click Login button

        this.clickLogin();           

    }

}