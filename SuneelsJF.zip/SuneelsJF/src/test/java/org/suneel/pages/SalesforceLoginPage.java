package org.shell.tcoe.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.shell.tcoe.pageobjects.SalesforceLoginPageControls;
import org.testng.Assert;


public class SalesforceLoginPage {

	WebDriver driver;
	SalesforceLoginPageControls salesforceLoginPageControls;
	
	public SalesforceLoginPage(WebDriver driver, SalesforceLoginPageControls salesforceLoginPageControls) {
		this.driver = driver;
		this.salesforceLoginPageControls = salesforceLoginPageControls;
		PageFactory.initElements(driver, this.salesforceLoginPageControls);
		System.out.println("I am there!");
	}
	
	//Launch Browser and access Salesforce Login Page
	public void navagetoSalesforceLoginPage(String url) {
		this.driver.navigate().to(url);
	}
	
	//Enter User Name and Password
	public void salesforcelogin(String uName, String pwd) {
		
		if (salesforceLoginPageControls.UserName.isEnabled()) {
			salesforceLoginPageControls.UserName.sendKeys(uName);
			salesforceLoginPageControls.Password.sendKeys(pwd);
			salesforceLoginPageControls.Submit.click();
			}
		else {
			salesforceLoginPageControls.LogInWithADifferentUsername.click();
			salesforceLoginPageControls.UserName.sendKeys(uName);
			salesforceLoginPageControls.Password.sendKeys(pwd);
			salesforceLoginPageControls.Submit.click();			
		}
		
	}
		
	
	//Validate Invalid Login
	public void validateInvalidLoginMessage() {
		Assert.assertTrue(salesforceLoginPageControls.ConfirmPassword.isDisplayed());
	}
}
