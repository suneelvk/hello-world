package org.shell.tcoe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.pageobjects.CrmHomePageControls;
import org.shell.tcoe.pageobjects.HomePageControls;




public class CrmHomePage {

	WebDriver driver;
	CrmHomePageControls crmhomePageControls;
	
	
	
	public CrmHomePage(WebDriver driver, CrmHomePageControls crmhomePageControls) {
		this.driver = driver;
		this.crmhomePageControls = crmhomePageControls;
		
		PageFactory.initElements(driver, this.crmhomePageControls);
	}


    //Get the User name from Home Page

        public String getHomePageDashboardUserName(){

         return    crmhomePageControls.homePageUserName.getText();

        }



}
