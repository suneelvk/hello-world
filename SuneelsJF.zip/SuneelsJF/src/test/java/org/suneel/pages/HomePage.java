package org.shell.tcoe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.pageobjects.HomePageControls;
import org.shell.tcoe.utilities.BrowserUtilities;

public class HomePage {

	WebDriver driver;
	HomePageControls homePageControls;

	

	public HomePage(WebDriver driver, HomePageControls homePageControls) {
		this.driver = driver;
		this.homePageControls = homePageControls;

		PageFactory.initElements(driver, this.homePageControls);
	}

	public String validateLoginPageTitle() throws InterruptedException {
		Thread.sleep(10000);
		return driver.getTitle();
	}
	

}
