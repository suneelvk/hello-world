package org.shell.tcoe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.shell.tcoe.base.BasePage;
import org.shell.tcoe.base.TestBase;
import org.shell.tcoe.pageobjects.DemoAppPageControls;
import org.shell.tcoe.pageobjects.GoogleWebAppPageControls;
import org.shell.tcoe.utilities.Utilities;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class GoogleWebAppPage extends Utilities{

	
	AppiumDriver appiumDriver;
	GoogleWebAppPageControls googleWebAppPageControls;

	

	public GoogleWebAppPage(AppiumDriver appiumDriver, GoogleWebAppPageControls googleWebAppPageControls) {
		super(appiumDriver);
		this.appiumDriver = appiumDriver;
		this.googleWebAppPageControls = googleWebAppPageControls;

		PageFactory.initElements(new AppiumFieldDecorator(this.appiumDriver), this.googleWebAppPageControls);
		
	}
	
	
	

	public void clickLabel() {
		googleWebAppPageControls.lbl_Views.click();
	}
	
	public void CalcFun() {
		googleWebAppPageControls.cal_Btn_1.click();
		googleWebAppPageControls.cal_Btn_X.click();
		googleWebAppPageControls.cal_Btn_2.click();
		
		
	}
	
	public void navigate() {
		this.appiumDriver.get("https://www.google.com");
	}
	
	
	
	
	
}
