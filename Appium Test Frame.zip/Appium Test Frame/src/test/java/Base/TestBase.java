package Base;

import io.appium.java_client.AppiumDriver;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import ru.yandex.qatools.allure.annotations.Attachment;
import utils.AutomationConstants;
import utils.Base;
import utils.InitiateDriver;
import utils.PropertyReader;

import java.awt.AWTException;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.WritableRaster;
import java.io.*;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import javax.imageio.ImageIO;

import static org.testng.Reporter.log;

public class TestBase implements IHookable {

	protected AppiumDriver appiumDriver;
	protected WebDriver driver;
	public static HashMap<String, String> configProperties;
	// public static HashMap<String,String> registrationProperties;
	// public static HashMap<String,String> profileProperties;
	protected static Logger log = Logger.getLogger(Base.class);

	public TestBase() {
		configProperties = PropertyReader.getPropValues("config.properties");
		// registrationProperties=
		// PropertyReader.getPropValues("registration.properties");
	}

	@BeforeMethod(alwaysRun = true)
	@Parameters({ "platform" })
	public void setup(Method method, String platform) {
		InitiateDriver initiateDriver = new InitiateDriver();
		String deviceName_ = "", UDID_ = "", platformVersion_ = "";
		// String platform = configProperties.get("PLATFORM");

		String platformName = getPlatform();
		ArrayList<ArrayList<String>> deviceDetails;

		if (platform.equalsIgnoreCase("Mobile") || platform.equalsIgnoreCase("ANDROID")) {
			deviceDetails = getDeviceDetails(platformName);
			deviceName_ = deviceDetails.get(0).get(0);
			platformVersion_ = deviceDetails.get(0).get(1);
			UDID_ = deviceDetails.get(0).get(2);

			initiateDriver.InitiateDriverForMobile(deviceName_, UDID_, platformVersion_);

			String description = (getDescription(method)
					.replace("@ru.yandex.qatools.allure.annotations.Stories(value=[", "")).replace(")", "").trim();
			reportInfo("*********************** Appium Test is running on an " + platform + " - " + deviceName_
					+ " device *****************************");
			reportInfo("***********************************************************************************");
			reportInfo(getClass().getSimpleName() + ", Starting Test: '" + method.getName() + "' with Description: '"
					+ description + "'");
			reportInfo("===================================================================================");
			reportInfo("***********************************************************************************");
			reportInfo("Test Name : " + method.getName());
			reportInfo("Test Description : " + description);
			reportInfo("===================================================================================");

			appiumDriver = initiateDriver.getAppiumDriver();
			Base.appiumDriver = appiumDriver;

		} else if (platform.equalsIgnoreCase("Browser")) {
			initiateDriver.InitiateDriverForBrowser();
			String description = (getDescription(method)
					.replace("@ru.yandex.qatools.allure.annotations.Stories(value=[", "")).replace(")", "").trim();
			reportInfo("*********************** Selenium Test is running on an " + platform
					+ " *****************************");
			reportInfo("***********************************************************************************");
			reportInfo(getClass().getSimpleName() + ", Starting Test: '" + method.getName() + "' with Description: '"
					+ description + "'");
			reportInfo("===================================================================================");
			reportInfo("***********************************************************************************");
			reportInfo("Test Name : " + method.getName());
			reportInfo("Test Description : " + description);
			reportInfo("===================================================================================");

			driver = initiateDriver.getDriver();
			Base.driver = driver;

		}

	}

	protected void reportInfo(String message) {

		log.info("Step Info: " + message);
		log(message);

	}

	/**
	 * This method will get the description from the test method in run time.
	 *
	 * @param method - method java method reflector
	 **/
	protected String getDescription(Method method) {
		Annotation[] a = method.getAnnotations();
		return a[1].toString().split("description=")[0].trim();
	}

	// Take Screenshot, whenever test cases Fail. The screenshots taken will be
	// attached to Allure report
	//@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {

		callBack.runTestMethod(testResult);
		// -------------------
		if (testResult.getThrowable() != null && testResult.getName().toString().contains("UFT")) {
			try {
				reportInfo("Take screenshot");
				takeUFTScreenShot();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// -------------------
		if (testResult.getThrowable() != null) {
			try {
				reportInfo("Take screenshot");
				takeScreenShot();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// appiumDriver.quit(); // changed recently
	}

	// Attach Screenshots taken to Allure report
	@Attachment(value = "Failure in method {0}", type = "image/png")
	public byte[] takeScreenShot() throws IOException {
		return appiumDriver.getScreenshotAs(OutputType.BYTES);
	}

	// Attach Screenshots taken to Allure report
	@Attachment(value = "Failure in method {0}", type = "image/png")
	public byte[] takeUFTScreenShot() throws IOException {
		byte[] imageInByte = null;
		Rectangle screenRect = new Rectangle(0, 0, 0, 0);
		for (GraphicsDevice gd : GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices()) {
			screenRect = screenRect.union(gd.getDefaultConfiguration().getBounds());
		}
		try {
			BufferedImage capture = new Robot().createScreenCapture(screenRect);
			// WritableRaster raster = capture.getRaster();
			// buffer = (DataBufferByte) raster.getDataBuffer();
			try {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ImageIO.write(capture, "png", baos);
				baos.flush();
				imageInByte = baos.toByteArray();
				baos.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/*
			 * try { ImageIO.write(capture, "png", new
			 * File("C:\\Users\\V.Kalluru\\Desktop\\gfg.png")); } catch (IOException e) { //
			 * TODO Auto-generated catch block e.printStackTrace(); }
			 */
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return imageInByte;
	}

	/**
	 * This method will get the device details runtime
	 *
	 * @param platform - input sting required on which platform we need to get the
	 *                 device details
	 * @return device name
	 * @return device OS version
	 * @return device UDID
	 */
	protected ArrayList<ArrayList<String>> getDeviceDetails(String platform) {
		ArrayList<ArrayList<String>> deviceDetail = new ArrayList<ArrayList<String>>();
		ArrayList<String> deviceDetails = new ArrayList<String>();
		Process p = null;
		BufferedReader in = null;
		String osVersion = null;
		if (platform.equalsIgnoreCase("ios")) {
			String udid = getUDID("", false);
			try {
				p = new ProcessBuilder("/bin/bash", "-l", "-c", "instruments -s devices").start();
				try {
					p.waitFor();
				} catch (Exception e) {
				}
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
				while ((osVersion = in.readLine()) != null) {
					deviceDetails.add(osVersion.trim());

				}
			} catch (IOException e) {
			}

			for (String s : deviceDetails) {
				if (s.contains("(null)")) {
				} else if (s.contains(udid)) {
					osVersion = s.replaceAll(udid, "").replaceAll("\\[", "").replaceAll("\\]", "").trim();
					String[] list = osVersion.split(" \\(");
					deviceDetails = new ArrayList<String>();
					String dUdid, dName, dVersion = null;
					dName = list[0].trim();
					dVersion = list[1].replaceAll("\\)", "").trim();
					dUdid = udid.trim();
					deviceDetails.add(dName);
					deviceDetails.add(dVersion);
					deviceDetails.add(dUdid);
					deviceDetail.add(deviceDetails);
					break;
				}
			}
		} else {
			try {
				String OS = System.getProperty("os.name").toLowerCase();
				if (OS.startsWith("windows")) {
					p = new ProcessBuilder("cmd.exe", "/C", "adb devices -l").start();
				} else if (OS.startsWith("mac os")) {
					p = new ProcessBuilder("/bin/bash", "-l", "-c", "adb devices -l").start();
				}
				try {
					p.waitFor();
				} catch (Exception e) {
				}
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
				while ((OS = in.readLine()) != null) {
					if (!OS.startsWith("List of devices attached")) {
						deviceDetails.add(OS.trim());
					}
				}
				for (String s : deviceDetails) {
					if (!s.equals("")) {
						ArrayList<String> deviceDetails1 = new ArrayList<String>();
						String[] details = null;
						String id = null, osV = null;
						details = s.split("model:");
						details = details[1].split(" ");// device Name
						deviceDetails1.add(details[0].trim());
						details = s.split(" ");
						id = details[0].trim();
						osV = getUDID(id, true);
						deviceDetails1.add(osV);// device osVersion
						deviceDetails1.add(id);// device UDID
						deviceDetail.add(deviceDetails1);
					}
				}
			} catch (IOException e) {
			}
		}
		return deviceDetail;
	}

	protected String getUDID(String udid, boolean android) {
		Process p = null;
		String deviceName = null;
		BufferedReader in = null;
		if (!android) {
			try {
				p = new ProcessBuilder("/bin/bash", "-l", "-c", "idevice_id -l").start();
				try {
					p.waitFor();
				} catch (Exception e) {
				}
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
				deviceName = in.readLine().trim();
			} catch (IOException e) {
			}
		} else {
			try {
				String OS = System.getProperty("os.name").toLowerCase();
				String cmd = "adb -s " + udid.trim() + " shell getprop ro.build.version.release";
				if (OS.startsWith("windows")) {
					p = new ProcessBuilder("cmd.exe", "/C", cmd).start();
				} else if (OS.startsWith("mac os")) {
					p = new ProcessBuilder("/bin/bash", "-l", "-c", cmd).start();
				}
				try {
					p.waitFor();
				} catch (Exception e) {
				}
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
				deviceName = in.readLine().trim();
			} catch (IOException e) {
			}
		}
		return deviceName;
	}

	/**
	 * This method will get the platform that system need to run on.
	 *
	 * @return platform name it will return
	 */
	protected String getPlatform() {
		String value = System.getProperty(AutomationConstants.AUTOMATION_PLATFORM_NAME);
		if (value == null || value.isEmpty()) {
			FileInputStream fis;
			try {
				fis = new FileInputStream(AutomationConstants.AUTOMATION_PROPERTIES_PATH);
				Properties prop = new Properties();
				prop.load(fis);
				value = prop.getProperty(AutomationConstants.AUTOMATION_PLATFORM_NAME);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return value;
	}

	@AfterMethod(alwaysRun = true)
	@Parameters({ "platform" })
	protected void quit(Method method, ITestResult result, String platform) throws IOException {
		try {
			if (platform.equalsIgnoreCase("Mobile") || platform.equalsIgnoreCase("android")) {
				appiumDriver.quit();
			} else {
				driver.quit();}
		} catch (Exception e) {
		} finally {
			
	}
}
}
