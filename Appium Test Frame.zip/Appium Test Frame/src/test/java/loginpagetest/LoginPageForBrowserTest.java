package loginpagetest;

import Base.TestBase;
import Pages.Pages;
import org.testng.Assert;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Test cases related to New Project")
    public class LoginPageForBrowserTest extends TestBase {
    protected static final String GROUP = "GeneralInformation Test";

    @Test
    @Stories("<Add your story here>")
    public void Test_Method_01() {

        Assert.assertEquals(Pages.LoginPageForBrowser().method_01(),true);

    }

}