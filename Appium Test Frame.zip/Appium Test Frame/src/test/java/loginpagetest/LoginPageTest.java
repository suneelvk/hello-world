package loginpagetest;

import Base.TestBase;
import Pages.Pages;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.testng.Assert;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Test cases related to UFT")
public class LoginPageTest extends TestBase {
	protected static final String GROUP = "GeneralInformation Test";

	@Test
	@Stories("UFT story")
	@Description("The most beautiful UFT story- Description")
	public void UFT_Test_Method_021() {

		Pages.LoginPage().method_02();

		try {

			String[] parms = { "cscript", System.getProperty("user.dir") + "\\uft_invoker\\InvokeQTP.vbs",
					"/QTPTestName:" + System.getProperty("user.dir") + "\\uft_scripts\\GUITest1" };

			Process p = Runtime.getRuntime().exec(parms);
			
			try {
				System.out.println("Started Waiting for UFT to open....");
				p.waitFor();
				System.out.println("exit value: " + p.exitValue());
				System.out.println("Waiting is over....");
			} 
		catch (InterruptedException e) {
				// TODO Auto-generated catch block e.printStackTrace();
			}
			
			
			// Get Input Stream from the Process
			BufferedReader is = new BufferedReader(new InputStreamReader(p.getInputStream()));

			// Do something with stream, read etc.
				StringBuilder bld = new StringBuilder();
				String line;
				while ((line = is.readLine()) != null) {
					bld.append(line);
					System.out.println(line);
	
				}
			System.out.println(bld.toString().toLowerCase().trim());
			System.out.println(bld.toString().toLowerCase().trim().contains("true"));

			Assert.assertEquals(bld.toString().toLowerCase().trim().contains("true"), true);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		// Pages.LoginPage().method_02();

		// Assert.assertEquals(Pages.LoginPage().method_01(), true);

	}

	@Test
	@Stories("Story Name: Login method 02 ")
	@Description("Test Case Description: The most beautiful 02  story- Description")
	public void Test_Method_02() {

		Assert.assertEquals(Pages.LoginPage().method_01(), true);

		Pages.LoginPage().mStep1();

		Pages.LoginPage().mStep2();

	}

}