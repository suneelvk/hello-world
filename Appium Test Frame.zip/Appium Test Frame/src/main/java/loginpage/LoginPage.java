package loginpage;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import ru.yandex.qatools.allure.annotations.Step;
import utils.Base;
import utils.PropertyReader;

import java.util.HashMap;

public class LoginPage extends Base{

    private static LoginPageObjRepo rpoObj;
    String runOn;

    public LoginPage(){

        rpoObj = new LoginPageObjRepo(appiumDriver);
        getProperties = PropertyReader.getPropValues("config.properties");
        runOn = System.getProperty("runOn") == null ? getProperties.get("RUN_ON") : System.getProperty("runOn");
    }

    private HashMap<String, String> getProperties;
    RemoteWebDriver driver;

    @Step("Test the method 1")
    public boolean method_01(){

     try{
         switchToWebView();
         if(runOn.equalsIgnoreCase("ANDROID_APP")){
         //waitForElementAndClick(rpoObj.btn_Test1,"Click on Continue button");
         delay(10);
         reportInfo("*************** End of test *****************");

         } else if(runOn.equalsIgnoreCase("ANDROID_BROWSER")){
             reportInfo("Open Shell Site");
             appiumDriver.navigate().to("https://www.shell.com/");
             reportInfo("*************** End of test *****************");
         }

     }catch (Exception e){
         e.printStackTrace();
         return false;
     }

     return true;
    }
    
    
    @Step("Test the method 2")
    public boolean method_02(){

     try{
         //switchToWebView();
         if(runOn.equalsIgnoreCase("ANDROID_APP")){
         //waitForElementAndClick(rpoObj.btn_Test1,"Click on Continue button");
         System.out.println("Andriod");
         reportInfo("*************** End of test *****************");

         } else if(runOn.equalsIgnoreCase("ANDROID_BROWSER")){
             reportInfo("Open Shell Site");
             appiumDriver.navigate().to("https://www.shell.com/");
             reportInfo("*************** End of test *****************");
         }

     }catch (Exception e){
         e.printStackTrace();
         return false;
     }

     return true;
    }


    @Step("Step Name:Test the method 2 - Step 1 ")
    public void mStep1() {
    	System.out.println("Step 1");
    }
    
    @Step("Test the method 2 - Step 2 ")
    public void mStep2() {
    	System.out.println("Step 2");
    	Assert.assertEquals(true, true);
    }
    
}
