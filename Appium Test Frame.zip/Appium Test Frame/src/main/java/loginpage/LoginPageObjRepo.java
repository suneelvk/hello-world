package loginpage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITBy;

import org.openqa.selenium.support.FindBy;
import utils.ObjectBase;

import java.util.List;

public class LoginPageObjRepo extends ObjectBase{

    public LoginPageObjRepo(AppiumDriver appiumDriver) {
        super(appiumDriver);
    }

    /* Your Xpath here */

    @iOSFindBy(xpath = "//*[contains(text(),'Test')]")
    @AndroidFindBy(accessibility = "text6")
    public MobileElement btn_Test1;
    
    @iOSXCUITBy(xpath = "//*[contains(text(),'Test')]")
    @AndroidFindBy(accessibility = "text6")
    public MobileElement btn_Test12;
    
    @iOSXCUITBy(iOSNsPredicateString = "//*[contains(text(),'Test')]")
    @AndroidFindBy(accessibility = "text6")
    public MobileElement btn_Test12;

}
