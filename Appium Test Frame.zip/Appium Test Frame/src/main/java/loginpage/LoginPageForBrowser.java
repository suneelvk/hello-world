package loginpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import ru.yandex.qatools.allure.annotations.Step;
import utils.Base;
import utils.PropertyReader;

import java.util.HashMap;

public class LoginPageForBrowser extends Base{

    private static LoginPageForBrowserObjRepo rpoObj;
    String runOn;

    public LoginPageForBrowser(){

        rpoObj = new LoginPageForBrowserObjRepo(driver);
        getProperties = PropertyReader.getPropValues("config.properties");
        runOn = System.getProperty("runOn") == null ? getProperties.get("RUN_ON") : System.getProperty("runOn");
    }

    private HashMap<String, String> getProperties;
    WebDriver driver;

    @Step("Test the method 1")
    public boolean method_01(){

     try{
         driver.findElement(By.xpath("//button[@class='evidon-banner-acceptbutton']")).click();
         //waitForElementAndClickForBrowser(rpoObj.motorist_Tab,"Click on Motorist tab");
         reportInfo("Browser test run");
     }catch (Exception e){
         e.printStackTrace();
         return false;
     }

     return true;
    }


}
