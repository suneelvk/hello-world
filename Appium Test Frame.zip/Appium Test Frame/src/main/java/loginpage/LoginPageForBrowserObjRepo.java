package loginpage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.ObjectBase;
import utils.ObjectBaseForBrowser;

import java.util.List;

public class LoginPageForBrowserObjRepo {

    public LoginPageForBrowserObjRepo(WebDriver driver) {

        PageFactory.initElements(driver, this);
    }

    /* Your Xpath here */

   @FindBy(xpath = "//button[@class='evidon-banner-acceptbutton']")
    public WebElement motorist_Tab;

}
