package utils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;


public class ObjectBaseForBrowser {

        public ObjectBaseForBrowser(WebDriver driver){
            PageFactory.initElements(driver, this);
        }
    }
