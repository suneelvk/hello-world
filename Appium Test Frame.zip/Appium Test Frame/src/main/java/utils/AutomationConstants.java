package utils;

public class AutomationConstants
{

   public static final String APPLICATION_NAME = "Project Name";
   public static final String AUTOMATION_RESOURCES = System.getProperty("user.dir") + "/src/main/resources/";

   /* Appium based Strings */
   public static final String AUTOMATION_IPA_PATH = AUTOMATION_RESOURCES + "apps/";
   public static final String AUTOMATION_APK_PATH = AUTOMATION_RESOURCES + "apps/";


   /* Selenium based Strings */
   public static final String AUTOMATION_CHROME_PATH = AUTOMATION_RESOURCES + "chromedriver.exe";
   public static final String AUTOMATION_CHROME_PATH_MAC = AUTOMATION_RESOURCES + "chromedriver";
   public static final String AUTOMATION_IE_PATH = AUTOMATION_RESOURCES + "IEDriverServer.exe";

   public static final String AUTOMATION_PROPERTIES_PATH = AUTOMATION_RESOURCES + "config.properties";
   public static final String AUTOMATION_LOG4J_PATH = AUTOMATION_RESOURCES + "log4j.properties";

   public static final String AUTOMATION_PLATFORM_NAME = "platformName";
   public static final String AUTOMATION_PLATFORM_IOS = "XCUITest";
   public static final String AUTOMATION_PATFORM_NAME_IOS = "iOS";

}
