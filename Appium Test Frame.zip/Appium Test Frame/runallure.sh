#!/usr/bin/env bash
cd target
allure serve
