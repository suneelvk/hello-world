import {browser, element, by, $$, $, ElementFinder,protractor} from 'protractor';
import { Locator,By, WebElementPromise } from 'selenium-webdriver';

export class ServiceNowHomePageControls {

    public SearchTextBox: ElementFinder;
    public CreateChangeLink: ElementFinder;

    public FirstIframe: WebElementPromise;
    public RiskIframe: WebElementPromise;

    public HeaderSaveButton: ElementFinder;
    public HeaderUpdateAndSaveButton: ElementFinder;
    public HeaderSubmitButton: ElementFinder;
    public HeaderNextPhase: ElementFinder;
    public HeaderSetActive: ElementFinder;
    public HeaderUpdate: ElementFinder;
    public HeaderCloseTask: ElementFinder;
    public HeaderAddAttachment: ElementFinder;
    public HeaderApprove: ElementFinder;

    public BussnessServiceOffering: ElementFinder;
    public BussnessServiceOfferingError: ElementFinder;
    public ITServiceOffering: ElementFinder;
    public ITServiceOfferingPreview: ElementFinder;
    public ITServiceOfferingError: ElementFinder;
    public ShortDescription: ElementFinder;
    public Description: ElementFinder;
    public Justification: ElementFinder;
    public RequestedByDate: ElementFinder;

    public AssignedTo: ElementFinder;
    public ReasonForChange: ElementFinder;
    public ChangeType: ElementFinder;

    public PlannedStartDate: ElementFinder;
    public PlannedEndDate: ElementFinder;
    public OutageRequired: ElementFinder;

    public PlanningTab: ElementFinder;
    public ChangePlan: ElementFinder;
    public BackoutPlan: ElementFinder;

    public TestPlan: ElementFinder;
    public TestStrategy: ElementFinder;
    public FirstTestStrategyFromTable: ElementFinder;
    public FunctionalTesting: ElementFinder;
    public UnitTesting: ElementFinder;
    public SystemTesting: ElementFinder;
    public SystemTestingExitCriteria: ElementFinder;

    public FillRiskAssessment: ElementFinder;
    public RiskAssessmentSelectNonProdchange: ElementFinder;
    public RiskAssessmentSelectSingleNonBusiness: ElementFinder;
    public RiskAssessmentSelectBusinessProcess: ElementFinder;
    public RiskAssessmentSelectSingleLocation: ElementFinder;
    public RiskAssessmentSelectLow: ElementFinder;
    public RiskAssessmentSelectChangeRegularly: ElementFinder;
    public RiskAssessmentSelectFullRedundancy: ElementFinder;
    public RiskAssessmentSelectVeryLikely: ElementFinder;
    public RiskAssessmentSelectGC51Yes: ElementFinder;
    public RiskAssessmentSelectGC52Yes: ElementFinder;
    public RiskAssessmentSubmit: ElementFinder;

    public ChangeTasksTab: ElementFinder;
    public ChangeTasksTable: ElementFinder;
    public ChangeTasksBuild: ElementFinder;
    public ChangeTasks_Build_AssignedTo: ElementFinder;
    public ChangeTasks_Build_ClosureCode: ElementFinder;
    public ChangeTasks_Build_ClosingComments: ElementFinder;


    public ChangeTasksTest: ElementFinder;
    public ChangeTask_Test_AttachTestPlan: ElementFinder;
    public ChangeTask_Test_CloseTestPlanPopUp: ElementFinder;

    public ChangeTestTaskApprovalItem: ElementFinder;
    public ChangeTestTaskApprovalTab: ElementFinder;

    constructor() {
        this.SetChangeSearchControls();
        this.SetIframeControls();
        this.SetRFCloggingControls();
        this.SetHeaderActionButtons();
        this.SetRFCReviewAndCategorization();
        this.SetAssessmentAndPlannig();
        this.SetBuildControls();
        this.SetTestControls();
    }

    private SetIframeControls(){
        this.FirstIframe = browser.driver.findElement(by.tagName('iframe')); 
        this.RiskIframe = browser.driver.findElement(by.xpath("//iframe[@class='gb_iframe']")); 
    }

    private SetChangeSearchControls(){
        this.SearchTextBox = $('input[ng-model="filterTextValue"]');
        this.CreateChangeLink = element(by.xpath("//a[@id='323bb07bc611227a018aea9eb8f3b35e']//div[@class='sn-widget-list-title'][contains(text(),'Create New')]"));
    }

    private SetRFCloggingControls(){
        this.BussnessServiceOffering = $('input[id="sys_display.change_request.business_service"]');
        this.BussnessServiceOfferingError = element(by.xpath("//div[@id='change_request.business_service_fieldmsg']//div[@class='fieldmsg notification notification-error'][contains(text(),'Invalid reference')]"));
        this.ITServiceOffering = $('input[id="sys_display.change_request.u_it_service_offering"]');
        this.ITServiceOfferingPreview = $('button[id="viewr.change_request.u_it_service_offering"]');
        this.ITServiceOfferingError = element(by.xpath("//div[@id='change_request.u_it_service_offering_fieldmsg']//div[@class='fieldmsg notification notification-error'][contains(text(),'Invalid reference')]"));
        this.ShortDescription = $('input[id="change_request.short_description"]');
        this.Description = $('textarea[id="change_request.description"]');
        this.Justification = $('textarea[id="change_request.justification"]');
        this.RequestedByDate = $('input[id="change_request.requested_by_date"]');
    }

    private SetHeaderActionButtons(){
        this.HeaderSaveButton = element(by.xpath("//BUTTON[@id='sysverb_insert_and_stay']"));
        this.HeaderUpdateAndSaveButton = element(by.xpath("//BUTTON[@id='sysverb_update_and_stay']"));
        this.HeaderSubmitButton = element(by.xpath("//BUTTON[@id='sysverb_insert']"));
        this.HeaderNextPhase = element(by.xpath("//BUTTON[@id='chg_next_phase']"));
        this.HeaderSetActive = element(by.xpath("//BUTTON[@id='set_active']"));
        //this.HeaderUpdate = $('#sysverb_update');
        this.HeaderUpdate = element(by.xpath("//BUTTON[@id='sysverb_update']"));
        //this.HeaderCloseTask = element(by.xpath("//BUTTON[contains(text(),'Close Task')]"));
        this.HeaderCloseTask = element(by.xpath("//SPAN[@class='navbar_ui_actions']//BUTTON[@id='d6d80b6edbb58b00a5affd051d9619ff']"));
        this.HeaderAddAttachment = element(by.xpath("//DIV[@class='navbar-right']//BUTTON[@id='header_add_attachment']"));
        this.HeaderApprove = element(by.xpath("//BUTTON[@id='approve']/self::BUTTON"));
    }

    private SetRFCReviewAndCategorization(){
        this.ChangeType = $('input[id="sys_display.change_request.category"]');
        this.AssignedTo = $('input[id="sys_display.change_request.assigned_to"]');
        this.ReasonForChange = element(by.xpath("//select[@id='change_request.u_reason_for_change']")); 
    }


    private SetAssessmentAndPlannig(){
        this.PlannedStartDate = $('input[id="change_request.start_date"]');
        this.PlannedEndDate = $('input[id="change_request.end_date"]');
        this.OutageRequired = element(by.xpath("//SPAN[@data-section-id='ee95827dc0a8016400f6e15e01fc13ed']//SELECT[@id='change_request.u_outage_required']"));
        this.OutageRequired = element(by.xpath("//SPAN[@data-section-id='ee95827dc0a8016400f6e15e01fc13ed']//SELECT[@id='change_request.u_outage_required']//option[@value='No']"));
        this.PlanningTab = element(by.xpath("//SPAN[@class='tab_caption_text'][text()='Planning']"));
        this.ChangePlan = element(by.xpath("//SPAN[@data-section-id='ee9e7d75c0a8016401581b9fd4dcf2ec']//TEXTAREA[@id='change_request.change_plan']"));
        this.BackoutPlan = element(by.xpath("//SPAN[@data-section-id='ee9e7d75c0a8016401581b9fd4dcf2ec']//TEXTAREA[@id='change_request.backout_plan']"));
        this.TestPlan = element(by.xpath("//SPAN[@data-section-id='ee9e7d75c0a8016401581b9fd4dcf2ec']//TEXTAREA[@id='change_request.test_plan']"));

        this.TestStrategy = element(by.xpath("//SPAN[@class='tab_caption_text'][contains(text(),'Test')]"));
        this.FirstTestStrategyFromTable = element(by.xpath("//table[@id='change_request.u_change_strategy.u_change_table']//tbody[@class='list2_body']//a//div[@class='datex date-calendar']"));
        this.FunctionalTesting = element(by.xpath("//LABEL[@id='label.ni.u_change_strategy.u_functional_testing']"));
        this.UnitTesting = element(by.xpath("//LABEL[@id='label.ni.u_change_strategy.u_unit_component_testing']"));
        this.SystemTesting = element(by.xpath("//LABEL[@id='label.ni.u_change_strategy.u_system_testing']"));
        this.SystemTestingExitCriteria = element(by.xpath("//TEXTAREA[@id='u_change_strategy.u_system_testing_exit_criteria']"));

        this.FillRiskAssessment = element(by.xpath("//A[@id='0b06cf2edbb58b00a5affd051d9619cc']"));
        this.RiskAssessmentSelectNonProdchange = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Non-production change')]"));
        this.RiskAssessmentSelectSingleNonBusiness = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Single non-business critical service/application')]"));
        this.RiskAssessmentSelectBusinessProcess = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Business processes / IT services can operate normally')]"));
        this.RiskAssessmentSelectSingleLocation = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Users or devices in a single location / small number of users or devices')]"));
        this.RiskAssessmentSelectLow = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Low - Fully automated code integration, testing and deployment (DevOps)')]"));
        this.RiskAssessmentSelectChangeRegularly = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Teams implement this type of change regularly (i.e. at least quarterly)')]"));
        this.RiskAssessmentSelectFullRedundancy = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Full redundancy is in place and fall-back is tested regularly')]"));
        this.RiskAssessmentSelectVeryLikely = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Very Likely - Back-out plan has already been successfully tested in non-prod or executed in prod by the team')]"));
        this.RiskAssessmentSelectGC51Yes = element(by.xpath("//LABEL[@class='radio-label'][contains(text(),'a. Yes')]"));
        this.RiskAssessmentSelectGC52Yes = element(by.xpath("//tr[@id='element.QUESTION:b574207edbad47c0bd27f9231d961941']//LABEL[@class='radio-label'][contains(text(),'a. Yes')]"));
        this.RiskAssessmentSubmit = element(by.xpath("//BUTTON[@id='post_survey']"));

    }

    
    private SetBuildControls(){
         this.ChangeTasksTab = element(by.xpath("//SPAN[@class='tab_caption_text'][starts-with(text(),'Change')]"));
         //this.ChangeTasksTable =  element(by.xpath("//table[@id='change_request.change_task.change_request_table']"));
         this.ChangeTasksBuild = element(by.xpath("//table[@id='change_request.change_task.change_request_table']//tbody[@class='list2_body']//td[@class='vt'][contains(text(),'Build')]/preceding-sibling::td//a[@class='linked formlink']"));
         this.ChangeTasks_Build_AssignedTo = $('input[id="sys_display.change_task.assigned_to"]');
         this.ChangeTasks_Build_ClosureCode = element(by.xpath("//select[@id='change_task.u_closure_code']")); 
         this.ChangeTasks_Build_ClosingComments = element(by.xpath("//TEXTAREA[@id='change_task.u_closing_comments']"));
    }

    private SetTestControls(){
        this.ChangeTasksTest = element(by.xpath("//table[@id='change_request.change_task.change_request_table']//tbody[@class='list2_body']//td[@class='vt'][contains(text(),'Test')]/preceding-sibling::td//a[@class='linked formlink']"));
        this.ChangeTask_Test_AttachTestPlan = element(by.xpath("//INPUT[@id='attachFile']"));
        this.ChangeTask_Test_CloseTestPlanPopUp = element(by.xpath("//BUTTON[@id='attachment_closemodal']"));
        this.ChangeTestTaskApprovalItem = element(by.xpath("//A[@class='linked formlink'][text()='Requested']"));
        this.ChangeTestTaskApprovalTab = element(by.xpath("//SPAN[@class='tab_caption_text'][contains(text(),'Approvers')]"));
    }

}