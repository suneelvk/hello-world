const { When, Then, Given, And } = require("cucumber");
import { ServiceNowHomePageFunctions} from "../FunctionLibrary/ServiceNowHomePageFunctions";
import { ChangeDataModel } from "../DataModels/ChangeDataModel";
import { ChangeTestdata } from "../TestData/ChangeTestData"

const homePageFunctions = new ServiceNowHomePageFunctions();
const changeDataModel = new ChangeDataModel(ChangeTestdata);

//     Scenario: Create new Change request

Given(/^I am at the servie now home page$/, async () =>{
    await homePageFunctions.AssertNavigateToServiceHomePage();
});

When(/^I search for change$/, async () => {
    await homePageFunctions.CreateNewChangeRequest(changeDataModel);
});

When(/^I click on create new change$/, async () => {
     //await homePageFunctions.FillRFCloggingDetails(changeDataModel);
});

Then(/^A new chage request is created$/, async () => {
    await homePageFunctions.AssertNewChangeRequsetIsCreated();
   //await homePageFunctions.FillRFCreviewAndCategorization(changeDataModel);
   //await homePageFunctions.FillAssessmentAndPlanning(changeDataModel);
});


//    Scenario: Create RFC Logging

Given(/^I am in the RFC Logging tab$/, async () =>{
    await homePageFunctions.AssertNavigateToRFCLoggingPage();
});

When(/^I fill all required RFC Logging details and click next phase$/, async () => {
    await homePageFunctions.FillRFCloggingDetails(changeDataModel);
});

Then(/^I navigate to RFC Review and Categorization$/, async () => {
    await homePageFunctions.AssertNavigateToRFCreviewAndCategorization();
 });
 

 //    Scenario: Create RFC Review and Categorization

Given(/^I am in the RFC Review and Categorization tab$/, async () =>{
    await homePageFunctions.AssertNavigateToRFCreviewAndCategorization();
});

When(/^I fill all required Categorization details and click next phase$/, async () => {
    await homePageFunctions.FillRFCreviewAndCategorization(changeDataModel); 
});

Then(/^I navigate to Assessment and Planning$/, async () => {
    await homePageFunctions.AssertNavigateToAssessmentAndPlanning();
    //await homePageFunctions.FakeFailure();
 });
 

 //     Scenario: Create Assessment and Planning

Given(/^I am in Assessment and Planning tab$/, async () =>{
    await homePageFunctions.AssertNavigateToAssessmentAndPlanning(); 
});

When(/^I fill all required Assessment and Planning details and click next phase$/, async () => {
    await homePageFunctions.FillAssessmentAndPlanning(changeDataModel); 
});

Then(/^I navigate to Build and Test$/, async () => {
    await homePageFunctions.AssertNavigateToBuildAndTest();
 });
 

  //     Scenario: Create Build and Test

Given(/^I am in Build and Test tab$/, async () =>{
    await homePageFunctions.AssertNavigateToBuildAndTest(); 
});

When(/^I fill all required Build and Test details and click next phase$/, async () => {
    await homePageFunctions.FillBuildAndTest(changeDataModel); 
});

Then(/^I navigate to Approval$/, async () => {
    // await homePageFunctions.FillRFCreviewAndCategorization(changeDataModel);
 });


 //Failed Scenario

 Given(/^I am at servie now home page$/, async () =>{
    await homePageFunctions.FakeFailure();
    await homePageFunctions.AssertNavigateToServiceHomePage();
});

When(/^All the page Contents are loaded$/, async () => {
    await homePageFunctions.FakeFailure();
});

