import { ApiSampleFunctions} from "../FunctionLibrary/SamplePostCodeApiFunctions";
const { When, Then, Given, And } = require("cucumber");

const apiSampleFunctions = new ApiSampleFunctions();

// Given(/^I have set the endpoint to API$/, async () =>{
//     //await apiSampleFunctions.PostCodeGetAddress();
//     await apiSampleFunctions.ChaiPostCode();
// });

Given(/^I have set the endpoint to API$/, function (){
    //await apiSampleFunctions.PostCodeGetAddress();
    apiSampleFunctions.NavtiveExample();
});


When(/^I do a POST request$/, async () => {
     //await homePageFunctions.FillRFCloggingDetails(changeDataModel);
});

Then(/^A valid response content is returned$/, async () => {
   // await homePageFunctions.FillRFCreviewAndCategorization(changeDataModel);
   // await homePageFunctions.FillAssessmentAndPlanning(changeDataModel);
});