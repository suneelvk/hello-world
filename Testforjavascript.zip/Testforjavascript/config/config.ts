import * as path from "path";
import { browser, Config } from "protractor";
import { Reporter } from "../Helpers/reporter";
const jsonReports = process.cwd() + "/reports/json";

var shell = require('shelljs');

export const config: Config = {

    //seleniumAddress: "http://127.0.0.1:4444/wd/hub",
    seleniumServerJar : "../SeleniumServer/selenium-server-standalone-3.141.59.jar",

    SELENIUM_PROMISE_MANAGER: false,

    baseUrl: "https://suneelpoc.service-now.com/",

    allScriptsTimeout: 30000,

    capabilities: {
        browserName: "chrome",
        //browserName: "ie",
    },

//     multiCapabilities : [
//     {browserName: "chrome"},
//     {browserName: "firefox"},
//     {browserName: "phantomjs"},
// ],

    framework: "custom",
    frameworkPath: require.resolve("protractor-cucumber-framework"),

    specs: [
        "../../features/*.feature",
    ],

    onPrepare: () => {
        //shell.cp("-R", "SeleniumServer", "typeScript/SeleniumServer");
        browser.ignoreSynchronization = true;
        browser.manage().window().maximize();
        Reporter.createDirectory(jsonReports);
        shell.cp("-R", "TestData/UploadFiles", "typeScript/TestData/UploadFiles");
        //require('@hetznercloud/protractor-test-helper/').installMatcher();
    },

    cucumberOpts: {
        compiler: "ts:ts-node/register",
        format: "json:./reports/json/cucumber_report.json",
        require: ["../../typeScript/stepdefinitions/*.js", "../../typeScript/Helpers/*.js"],
        strict: true,
        // tags: "@APItest",
        tags: "@ServiceNowScenario",
    },

    onComplete: () => {
        Reporter.createHTMLReport();
    },
};
