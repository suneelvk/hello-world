export interface PostcodeData{
    country : string;
}