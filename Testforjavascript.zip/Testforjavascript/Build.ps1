
[CmdletBinding()]
Param (
    [string] $TeamFoundationCollectionUri ="https://suneel-it-esm.visualstudio.com",
    [string] $TeamProject = "SUNEEL%20Test%20Automation%20Offering",
    [string] $user = "",
    [string] $PersonalAccessToken = "pattoken",
    [ValidateSet("manual", "checkInShelveset")]
    [string] $Reason = "manual",
    [string] $SourceBranch = "",
    [switch] $WaitUntilBuildComplete,
    [switch] $UsuneelfaultCredentials,
    [string] $Tags ="Java Test"
)


Write-Verbose "TeamFoundationCollectionUri : $TeamFoundationCollectionUri"
Write-Verbose "TeamProject                 : $TeamProject"



$baseUrl = "$TeamFoundationCollectionUri/$TeamProject/_apis"


# Base64-encodes the Personal Access Token (PAT) appropriately

$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $user,$PersonalAccessToken)))


#Find the latest BuildsID

$BuildsIDUri = "$baseUrl/build/builds?api-version=5.1"

$responseFromGet = Invoke-RestMethod -Method Get -ContentType application/json -Uri $BuildsIDUri -Headers @{Authorization=("Basic {0}" -f $base64authinfo)}



$Build_Status = $responseFromGet.value[0].status
$Build_Id = $responseFromGet.value[0].id
$Build_Status_value = $responseFromGet.value[0] 


# Find BuilId_Definition_Name

$BuilId_Definition_Name = $responseFromGet.value[0].Definition.Name

# Add Tag Name

if($BuilId_Definition_Name -eq 'SUNEEL-AutomationFramework-Selenium-CI-TestPOC'){

$Tags = "csharp-dotnet"

}


if($BuilId_Definition_Name -eq 'SUNEEL-AutomationFramework-Selenium-CI-API'){

$Tags = "csharp-api"

}



if($BuilId_Definition_Name -eq 'SUNEEL Protractor Test Execution'){

$Tags = "prot-type"

}





if($BuilId_Definition_Name -eq 'SUNEELDotNetCore-offering'){

$Tags = "Sel-dotnet-core"

}







#Add Tag for new BuildID


$TagsUri = "$baseUrl/build/builds/$Build_Id/tags/$($Tags)?&api-version=5.1"

$Build_Response = Invoke-RestMethod -Method Put -ContentType application/json -Uri $TagsUri  -Headers @{Authorization=("Basic {0}" -f $base64authinfo)}

#$buildresponse = Invoke-RestMethod -Method Put -ContentType application/json -Uri $TagsUri  -Headers @{Authorization=("Basic {0}" -f $base64authinfo)}



$BuildTags=$Build_Response.value



# Sorting Framework

$Build_ID_Uri = "$baseUrl/build/builds?api-version=5.1"

$Build_ID_ResponseFromGet = Invoke-RestMethod -Method Get -ContentType application/json -Uri $Build_ID_Uri -Headers @{Authorization=("Basic {0}" -f $base64authinfo)}


$Daysback = "-7"

$CurrentDate = (Get-Date)

$DatetoDelete1= $CurrentDate.AddDays($Daysback)

$queueTimeDatetoDelete1 =  ($DatetoDelete1).ToString("yyyy-M-dd")





#creating array for Last_Seven_Days_Number that holds all objects

$array_of_Last_Seven_Days_Number = @()


$Count_Last_Seven_Days_Number = $Build_ID_ResponseFromGet.count


for($d=0; $d -le $Count_Last_Seven_Days_Number ; $d++){


$queueTime = $Build_ID_ResponseFromGet.value[$d].queueTime

$length = $queueTime.length

$Number_length =$length

$result_queueTime = $queueTime.substring($length -$Number_length,10)


if($result_queueTime -ge $queueTimeDatetoDelete1 ){


$array_of_Last_Seven_Days_Number+= $Build_ID_ResponseFromGet.value[$d]

$test9 = $array_of_Last_Seven_Days_Number.Count
}else{

break

}
}











$Count = $array_of_Last_Seven_Days_Number.value.Count




#creating array that holds all objects

$array_of_Tags_csharp_dotnet = @()
$array_of_Tags_csharp_api = @()
$array_of_Tags_prot_type = @()
$array_of_Tags_Sel_dotnet_core = @()

#object properties or the X-axis and Y-axis in the chart
$properties = @{ BuildTags_Tags = ""
                 BuildId_Id = 0
                 BuildResult_Result=""
                   
                }



for ($i=0; $i -le $Count; $i++) 

{

$BuildTags=$Build_ID_ResponseFromGet.value[$i].tags
$buildId =$Build_ID_ResponseFromGet.value[$i].id
$buildResult =$Build_ID_ResponseFromGet.value[$i].result

if ($BuildTags -eq 'csharp-dotnet'){


$TagsId = New-Object -TypeName psobject -Property $properties
$TagsId.BuildTags_Tags = $BuildTags
$TagsId.BuildId_Id = $buildId
$TagsId.BuildResult_Result = $buildResult
$array_of_Tags_csharp_dotnet+= $TagsId

}


if ($BuildTags -eq 'csharp-api'){


$TagsId = New-Object -TypeName psobject -Property $properties
$TagsId.BuildTags_Tags = $BuildTags
$TagsId.BuildId_Id = $buildId
$TagsId.BuildResult_Result = $buildResult
$array_of_Tags_csharp_api+= $TagsId

}



if ($BuildTags -eq 'prot-type'){


$TagsId = New-Object -TypeName psobject -Property $properties
$TagsId.BuildTags_Tags = $BuildTags
$TagsId.BuildId_Id = $buildId
$TagsId.BuildResult_Result = $buildResult
$array_of_Tags_prot_type+= $TagsId

}



if ($BuildTags -eq 'Sel-dotnet-core'){




$TagsId = New-Object -TypeName psobject -Property $properties
$TagsId.BuildTags_Tags = $BuildTags
$TagsId.BuildId_Id = $buildId
$TagsId.BuildResult_Result = $buildResult
$array_of_Tags_Sel_dotnet_core+= $TagsId

}



}



# 1.C#-Dotnet

# Total number of Count for csharp_dotnet Tags


$ht_Total= $array_of_Tags_csharp_dotnet.BuildResult_Result   | Group-Object -AsHashTable -AsString
$dt_Total=$array_of_Tags_csharp_dotnet.BuildResult_Result   |  group | % { $h = @{} } { $h[$_.Name] = $_.Count } { $h }

 
$csharp_dotnet_Succeeded_Count  = $dt_Total['succeeded']
$csharp_dotnet_Failed_Count  = $dt_Total['failed']



#pie chart for csharp_dotnet Tags

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#pie chart

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#ChartTitle

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'C#-Dotnet'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','12', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)



# create a chartarea to draw on and add to chart
$ChartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$Chart.ChartAreas.Add($ChartArea)





# add data to chart

$Tags_Name = @{Passed=$csharp_dotnet_Succeeded_Count; Failed=$csharp_dotnet_Failed_Count}

[void]$Chart.Series.Add("csharp_dotnet_Data")

$Chart.Series["csharp_dotnet_Data"].Points.DataBindXY( $Tags_Name.Keys,$Tags_Name.Values)

#Legend
$Legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$Legend.IsEquallySpacedItems = $True
$Legend.BorderColor = 'Black'
$Chart.Legends.Add($Legend)
$chart.Series["csharp_dotnet_Data"].LegendText = "#VALX (#VALY)"



#region Windows Form to Display Chart
$AnchorAll = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right -bor
    [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
$Form = New-Object Windows.Forms.Form
$Form.Width = 740
$Form.Height = 490
$Form.controls.add($Chart)
$Chart.Anchor = $AnchorAll


#$Chart.Series["Data"].Sort([System.Windows.Forms.DataVisualization.Charting.PointSortOrder]::Descending, "Y")


$ChartArea.AxisX.Title = "Process"
$ChartArea.AxisY.Title = "Working Set (MB)"


# Find point with max/min values and change their colour


$Passed= $Chart.Series["csharp_dotnet_Data"].Points[0]
$Passed.Color = [System.Drawing.Color]::Green

$Failed = $Chart.Series["csharp_dotnet_Data"].Points[1]
$Failed.Color = [System.Drawing.Color]::Red

# make bars into 3d cylinders
$Chart.Series["csharp_dotnet_Data"]["DrawingStyle"] = "Cylinder"

# set chart type
$Chart.Series["csharp_dotnet_Data"].ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Pie



# save chart to file


# Create a PNG file
"This file was attached to this incident by the API example for PowerShell" | 
Out-File -FilePath "$($env:TEMP)\csharp_dotnet.png"

$Chart.SaveImage("$($env:TEMP)\csharp_dotnet.png", "PNG")


$file = Get-ChildItem -Path "$($env:TEMP)\csharp_dotnet.png"
$filename = $file.Name
$totalsize = $file.Length
$allFileBytes = [System.IO.File]::ReadAllBytes($file.FullName)
$offset = 0




 $Chart.SaveImage("C:\Users\S.BaburaoThawar\Desktop\csharp_dotnet.png", "PNG")


 <#
 # Set the variables
$WebURL = “http://portal.contoso.com/sites/stuff”
$DocLibName = “Docs”
$FilePath = “C:\Docs\stuff\Secret Sauce.docx”

# Get a variable that points to the folder
$Web = Get-SPWeb $WebURL
$List = $Web.GetFolder($DocLibName)
$Files = $List.Files

# Get just the name of the file from the whole path
$FileName = $FilePath.Substring($FilePath.LastIndexOf("\")+1)

# Load the file into a variable
$File= Get-ChildItem $FilePath

# Upload it to SharePoint
$Files.Add($DocLibName +"/" + $FileName,$File.OpenRead(),$false)
$web.Dispose()




#>

































# 2. C#-Dotnet-API
 #pie chart for csharp_api



# Total number of Count for csharp_api Tags

$ht_Total= $array_of_Tags_csharp_api.BuildResult_Result   | Group-Object -AsHashTable -AsString
$dt_Total=$array_of_Tags_csharp_api.BuildResult_Result   |  group | % { $h = @{} } { $h[$_.Name] = $_.Count } { $h }

 
$csharp_api_Succeeded_Count  = $dt_Total['succeeded']
$csharp_api_Failed_Count  = $dt_Total['failed']



#pie chart for csharp_dotnet Tags

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#pie chart for C#-Dotnet-API

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#ChartTitle

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'C#-Dotnet-API'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','12', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)



# create a chartarea to draw on and add to chart
$ChartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$Chart.ChartAreas.Add($ChartArea)





# add data to chart for csharp_api_Data

$Tags_Name = @{Passed=$csharp_api_Succeeded_Count; Failed=$csharp_api_Failed_Count}

[void]$Chart.Series.Add("csharp_api_Data")

$Chart.Series["csharp_api_Data"].Points.DataBindXY( $Tags_Name.Keys,$Tags_Name.Values)

#Legend
$Legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$Legend.IsEquallySpacedItems = $True
$Legend.BorderColor = 'Black'
$Chart.Legends.Add($Legend)
$chart.Series["csharp_api_Data"].LegendText = "#VALX (#VALY)"



#region Windows Form to Display Chart
$AnchorAll = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right -bor
    [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
$Form = New-Object Windows.Forms.Form
$Form.Width = 740
$Form.Height = 490
$Form.controls.add($Chart)
$Chart.Anchor = $AnchorAll


#$Chart.Series["Data"].Sort([System.Windows.Forms.DataVisualization.Charting.PointSortOrder]::Descending, "Y")


$ChartArea.AxisX.Title = "Process"
$ChartArea.AxisY.Title = "Working Set (MB)"


# Find point with max/min values and change their colour


$Passed= $Chart.Series["csharp_api_Data"].Points[0]
$Passed.Color = [System.Drawing.Color]::Green

$Failed = $Chart.Series["csharp_api_Data"].Points[1]
$Failed.Color = [System.Drawing.Color]::Red

# make bars into 3d cylinders
$Chart.Series["csharp_api_Data"]["DrawingStyle"] = "Cylinder"

# set chart type
$Chart.Series["csharp_api_Data"].ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Pie





# save chart to file


# Create a PNG file
"This file was attached to this incident by the API example for PowerShell" | 
Out-File -FilePath "$($env:TEMP)\csharp_api.png"

$Chart.SaveImage("$($env:TEMP)\csharp_api.png", "PNG")


$file = Get-ChildItem -Path "$($env:TEMP)\csharp_api.png"
$filename = $file.Name
$totalsize = $file.Length
$allFileBytes = [System.IO.File]::ReadAllBytes($file.FullName)
$offset = 0






 $Chart.SaveImage("C:\Users\S.BaburaoThawar\Desktop\csharp_api.png", "PNG")






 
# 3. Protractor-Typescript
 #pie chart for prot_type


 
# Total number of Count for prot_type Tags

$ht_Total= $array_of_Tags_prot_type.BuildResult_Result   | Group-Object -AsHashTable -AsString
$dt_Total= $array_of_Tags_prot_type.BuildResult_Result   |  group | % { $h = @{} } { $h[$_.Name] = $_.Count } { $h }

 
$prot_type_Succeeded_Count  = $dt_Total['succeeded']
$prot_type_Failed_Count  = $dt_Total['failed']



#pie chart for prot_type Tags

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#pie chart for C#-Dotnet-API

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#ChartTitle

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Protractor-Typescript'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','12', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)



# create a chartarea to draw on and add to chart
$ChartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$Chart.ChartAreas.Add($ChartArea)





# add data to chart for csharp_api_Data

$Tags_Name = @{Passed=$prot_type_Succeeded_Count; Failed=$prot_type_Failed_Count}

[void]$Chart.Series.Add("prot_type_Data")

$Chart.Series["prot_type_Data"].Points.DataBindXY( $Tags_Name.Keys,$Tags_Name.Values)

#Legend
$Legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$Legend.IsEquallySpacedItems = $True
$Legend.BorderColor = 'Black'
$Chart.Legends.Add($Legend)
$chart.Series["prot_type_Data"].LegendText = "#VALX (#VALY)"



#region Windows Form to Display Chart
$AnchorAll = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right -bor
    [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
$Form = New-Object Windows.Forms.Form
$Form.Width = 740
$Form.Height = 490
$Form.controls.add($Chart)
$Chart.Anchor = $AnchorAll


#$Chart.Series["Data"].Sort([System.Windows.Forms.DataVisualization.Charting.PointSortOrder]::Descending, "Y")


$ChartArea.AxisX.Title = "Process"
$ChartArea.AxisY.Title = "Working Set (MB)"


# Find point with max/min values and change their colour


$Passed= $Chart.Series["prot_type_Data"].Points[0]
$Passed.Color = [System.Drawing.Color]::Green

$Failed = $Chart.Series["prot_type_Data"].Points[1]
$Failed.Color = [System.Drawing.Color]::Red

# make bars into 3d cylinders
$Chart.Series["prot_type_Data"]["DrawingStyle"] = "Cylinder"

# set chart type
$Chart.Series["prot_type_Data"].ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Pie



# save chart to file


# save chart to file


# Create a PNG file
"This file was attached to this incident by the API example for PowerShell" | 
Out-File -FilePath "$($env:TEMP)\prot_type.png"

$Chart.SaveImage("$($env:TEMP)\prot_type.png", "PNG")


$file = Get-ChildItem -Path "$($env:TEMP)\prot_type.png"
$filename = $file.Name
$totalsize = $file.Length
$allFileBytes = [System.IO.File]::ReadAllBytes($file.FullName)
$offset = 0






 #$Chart.SaveImage("C:\Users\S.BaburaoThawar\Desktop\prot_type.png", "PNG")
























# 4. Dotnet Core-Selenium
 #pie chart for Sel_dotnet_core 

# Total number of Count for Sel_dotnet_core Tags

$ht_Total= $array_of_Tags_Sel_dotnet_core.BuildResult_Result   | Group-Object -AsHashTable -AsString
$dt_Total= $array_of_Tags_Sel_dotnet_core.BuildResult_Result   |  group | % { $h = @{} } { $h[$_.Name] = $_.Count } { $h }

 
$Sel_dotnet_core_Succeeded_Count  = $dt_Total['succeeded']
$Sel_dotnet_core_Failed_Count  = $dt_Total['failed']




#pie chart for prot_type Tags

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#pie chart for C#-Dotnet-API

# load the appropriate assemblies
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")


# create chart object
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 500
$Chart.Height = 400
$Chart.Left = 40
$Chart.Top = 30




# create chart Border
$Chart.Width = 700
$Chart.Height = 400
$Chart.Left = 10
$Chart.Top = 10
$Chart.BackColor = [System.Drawing.Color]::White
$Chart.BorderColor = 'Black'
$Chart.BorderDashStyle = 'Solid'



#ChartTitle

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Dotnet Core-Selenium'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','12', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)



# create a chartarea to draw on and add to chart
$ChartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$Chart.ChartAreas.Add($ChartArea)





# add data to chart for csharp_api_Data

$Tags_Name = @{Passed=$Sel_dotnet_core_Succeeded_Count; Failed=$Sel_dotnet_core_Failed_Count}

[void]$Chart.Series.Add("Sel_dotnet_core_Data")

$Chart.Series["Sel_dotnet_core_Data"].Points.DataBindXY( $Tags_Name.Keys,$Tags_Name.Values)

#Legend
$Legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$Legend.IsEquallySpacedItems = $True
$Legend.BorderColor = 'Black'
$Chart.Legends.Add($Legend)
$chart.Series["Sel_dotnet_core_Data"].LegendText = "#VALX (#VALY)"



#region Windows Form to Display Chart
$AnchorAll = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right -bor
    [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
$Form = New-Object Windows.Forms.Form
$Form.Width = 740
$Form.Height = 490
$Form.controls.add($Chart)
$Chart.Anchor = $AnchorAll


#$Chart.Series["Data"].Sort([System.Windows.Forms.DataVisualization.Charting.PointSortOrder]::Descending, "Y")


$ChartArea.AxisX.Title = "Process"
$ChartArea.AxisY.Title = "Working Set (MB)"


# Find point with max/min values and change their colour


$Passed= $Chart.Series["Sel_dotnet_core_Data"].Points[0]
$Passed.Color = [System.Drawing.Color]::Green

$Failed = $Chart.Series["Sel_dotnet_core_Data"].Points[1]
$Failed.Color = [System.Drawing.Color]::Red

# make bars into 3d cylinders
$Chart.Series["Sel_dotnet_core_Data"]["DrawingStyle"] = "Cylinder"

# set chart type
$Chart.Series["Sel_dotnet_core_Data"].ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Pie



# save chart to file


# Create a PNG file
"This file was attached to this incident by the API example for PowerShell" | 
Out-File -FilePath "$($env:TEMP)\Sel_dotnet_core.png"

$Chart.SaveImage("$($env:TEMP)\Sel_dotnet_core.png", "PNG")


$file = Get-ChildItem -Path "$($env:TEMP)\Sel_dotnet_core.png"
$filename = $file.Name
$totalsize = $file.Length
$allFileBytes = [System.IO.File]::ReadAllBytes($file.FullName)
$offset = 0





 #$Chart.SaveImage("C:\Users\S.BaburaoThawar\Desktop\Sel_dotnet_core.png", "PNG")

 
 # Test


$vstsBaseUrl = 'https://suneel-it-esm.visualstudio.com'
$vstsTeamProjectName = 'SUNEEL%20Test%20Automation%20Offering'
$FileRepo = 'PowshellScripts'
$FileRepoBranch = 'master'
$FilePath = 'C:\Users\S.BaburaoThawar\Desktop\Sel_dotnet_core.png' # example: src/test text/ProjectDepedancy.txt

$User=""



$test = [convert]::ToBase64String((Get-Content C:\Users\S.BaburaoThawar\Desktop\Sel_dotnet_core.png -Encoding byte))


$commitsUrl = "https://suneel-it-esm.visualstudio.com/SUNEEL%20Test%20Automation%20Offering/_apis/git/repositories/PowshellScripts/commits?api-version=5.0"
$commitsRes = Invoke-RestMethod -Method Get -Uri $commitsUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType application/json 





$PushesUrl ="https://suneel-it-esm.visualstudio.com/SUNEEL%20Test%20Automation%20Offering/_apis/git/repositories/PowshellScripts/pushes?api-version=5.0"
$PushesRes =  Invoke-RestMethod -Method Get -Uri $PushesUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType application/json

<#
$bodyObject =@{
  refUpdates = @{
      name = "refs/heads/master"
      oldObjectId = "875795bf7252b78201d23ae451afeab5263554ee"
    }
  
  commits =@{
      comment = "Added new image file."
      changes = @{
          changeType = "edit"
          item = @{
            path = "C:\Users\S.BaburaoThawar\Desktop\Sel_dotnet_core.png"
          }
          newContent = @{
            content = $test
            #contentType = "base64encoded"
          }
        }
      
    }
  
}
#>

#$body = ConvertTo-Json $bodyObject -Depth 100 -Compress




<#

$bodyObject =@{
  refUpdates = @{
      name = "refs/heads/master"
      
    }
  
  commits =@{
      comment = "Added new image file."
      changes = @{
          changeType = "edit"
          item = @{
            path = "C:\Users\S.BaburaoThawar\Desktop\Sel_dotnet_core.png"
          }
          newContent = @{
            content = $test
            contentType = "base64encoded"
          }
        }
      
    }
  
}


#$body = ConvertTo-Json $bodyObject -Depth 100 -Compress








$url_1 ="https://suneel-it-esm.visualstudio.com/SUNEEL%20Test%20Automation%20Offering/_apis/git/repositories/PowshellScripts/pushes?api-version=5.1"


$result=Invoke-RestMethod -Method Post -Uri $url_1 -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType application/json -Body $bodyObject



#>
















