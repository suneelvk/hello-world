import { ServiceNowHomePageControls } from "../ControlLibrary/ServiceNowHomePageControls";
import { browser,protractor,promise,by } from "protractor";
import { waitFor } from "../Helpers/waitFor";
import { ChangeDataModel } from "../DataModels/ChangeDataModel";

const { click, waitToBeDisplayed, sendKeys, getText ,waitToBeNotPresent,selectOptionByText,selectOption  } = require('@hetznercloud/protractor-test-helper');
var driver = browser.driver;
var loc = by.tagName('iframe');
var el = driver.findElement(loc);
var path = require('path');

const chai = require('chai');
chai.use(require('chai-smoothie'));
const expect = chai.expect;


export class ServiceNowHomePageFunctions{

    serviceNowHomePageControls : ServiceNowHomePageControls;

    constructor(){
        this.serviceNowHomePageControls = new ServiceNowHomePageControls();
    }

   
    //#region Scenario: Create new Change request
    public async AssertNavigateToServiceHomePage() : Promise<any> {
        await waitFor.time(10000);
        await waitToBeDisplayed(this.serviceNowHomePageControls.SearchTextBox,10000);
        return await expect(this.serviceNowHomePageControls.SearchTextBox).to.be.displayed;
    }


    public async CreateNewChangeRequest(changeDataModel : ChangeDataModel): Promise<any> {
            await click(this.serviceNowHomePageControls.SearchTextBox);
            await sendKeys(this.serviceNowHomePageControls.SearchTextBox,changeDataModel.SearchCriteria);
            await waitFor.time(2000);
            await  click(this.serviceNowHomePageControls.CreateChangeLink);
            return await browser.waitForAngular();

    }

    public async FakeFailure(){
        return await expect(false).to.be.true;
    }

    public async AssertNewChangeRequsetIsCreated(){
        await browser.switchTo().frame(browser.driver.findElement(by.tagName('iframe')));
        await waitToBeDisplayed(this.serviceNowHomePageControls.BussnessServiceOffering,10000);
        return await expect(this.serviceNowHomePageControls.BussnessServiceOffering).to.be.displayed;
    }

    //#endregion

    //    Scenario: Create RFC Logging

    public async AssertNavigateToRFCLoggingPage() : Promise<any> {
        await waitToBeDisplayed(this.serviceNowHomePageControls.BussnessServiceOffering,10000);
        return await expect(this.serviceNowHomePageControls.BussnessServiceOffering).to.be.displayed;
    }

    public async FillRFCloggingDetails(changeDataModel : ChangeDataModel): Promise<any>{

        //await browser.switchTo().frame(browser.driver.findElement(by.tagName('iframe')));
        // await browser.switchTo().frame(this.serviceNowHomePageControls.FirstIframe);

        await sendKeys(this.serviceNowHomePageControls.BussnessServiceOffering,changeDataModel.BussnessServiceOffering);
        await click(this.serviceNowHomePageControls.ShortDescription);
        await waitToBeNotPresent(this.serviceNowHomePageControls.BussnessServiceOfferingError);
        await browser.waitForAngular();
        await waitFor.elementToBeClickable(this.serviceNowHomePageControls.ITServiceOfferingPreview,10000);
        await click(this.serviceNowHomePageControls.ShortDescription);
        //await waitFor.time(2000);
        await sendKeys(this.serviceNowHomePageControls.ShortDescription,changeDataModel.ShortDescription);
        await browser.actions().mouseMove(this.serviceNowHomePageControls.Description).perform();
        await sendKeys(this.serviceNowHomePageControls.Description,changeDataModel.Description);
        await browser.actions().mouseMove(this.serviceNowHomePageControls.Justification).perform();
        await sendKeys(this.serviceNowHomePageControls.Justification,changeDataModel.Justification);
        await sendKeys(this.serviceNowHomePageControls.RequestedByDate,changeDataModel.RequestedByDate);
        await click(this.serviceNowHomePageControls.HeaderSaveButton);
        //await waitFor.time(5000);
        await waitFor.elementToBeClickable(this.serviceNowHomePageControls.HeaderNextPhase,5000);
        await click(this.serviceNowHomePageControls.HeaderNextPhase);
        return await browser.waitForAngular();
    }

    public async AssertNavigateToRFCreviewAndCategorization() : Promise<any> {
        await waitToBeDisplayed(this.serviceNowHomePageControls.ChangeType,10000);
        return await expect(this.serviceNowHomePageControls.ChangeType).to.be.displayed;
    }


    //    Scenario: Create RFC Review and Categorization

    public async FillRFCreviewAndCategorization(changeDataModel : ChangeDataModel) : Promise<any>{
     
        await browser.waitForAngular();

        // await click(this.serviceNowHomePageControls.HeaderNextPhase);
        await browser.waitForAngular();
        await waitFor.presenceOfElement(this.serviceNowHomePageControls.ChangeType,10000);
        await sendKeys(this.serviceNowHomePageControls.ChangeType,changeDataModel.ChangeType);
        await click(this.serviceNowHomePageControls.AssignedTo);
        await sendKeys(this.serviceNowHomePageControls.AssignedTo,changeDataModel.AssignedTo);
        await selectOptionByText(this.serviceNowHomePageControls.ReasonForChange,changeDataModel.ReasonForChange);
        //await waitFor.time(2000);
        await waitFor.elementToBeClickable(this.serviceNowHomePageControls.HeaderUpdateAndSaveButton,2000);
        await click(this.serviceNowHomePageControls.HeaderUpdateAndSaveButton);
        //await waitFor.time(5000);
        await waitToBeDisplayed(this.serviceNowHomePageControls.HeaderSetActive,5000);
        await click(this.serviceNowHomePageControls.HeaderSetActive);
        await waitToBeDisplayed(this.serviceNowHomePageControls.HeaderNextPhase,2000);
        //await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.HeaderNextPhase);
        return await this.serviceNowHomePageControls.HeaderNextPhase.isDisplayed;

    }

    public async AssertNavigateToAssessmentAndPlanning() : Promise<any> {
        await waitToBeDisplayed(this.serviceNowHomePageControls.PlannedStartDate,10000);
        return await expect(this.serviceNowHomePageControls.PlannedStartDate).to.be.displayed;
    }
    

 //     Scenario: Create Assessment and Planning

    public async FillAssessmentAndPlanning(changeDataModel : ChangeDataModel) : Promise<any>{
        await browser.waitForAngular();
        //await click(this.serviceNowHomePageControls.HeaderNextPhase);
        await waitFor.time(2000)
        await sendKeys(this.serviceNowHomePageControls.PlannedStartDate,changeDataModel.PlannedStartDate);
        await sendKeys(this.serviceNowHomePageControls.PlannedEndDate,changeDataModel.PlannedEndDate);
        await selectOption(this.serviceNowHomePageControls.OutageRequired);
        await click(this.serviceNowHomePageControls.PlanningTab);
        await sendKeys(this.serviceNowHomePageControls.ChangePlan,changeDataModel.ChangePlan);
        await sendKeys(this.serviceNowHomePageControls.BackoutPlan,changeDataModel.BackoutPlan);
        await sendKeys(this.serviceNowHomePageControls.TestPlan,changeDataModel.TestPlan);
        await click(this.serviceNowHomePageControls.HeaderUpdateAndSaveButton);
        //await waitFor.time(5000);
        await click(this.serviceNowHomePageControls.TestStrategy);
        await click(this.serviceNowHomePageControls.FirstTestStrategyFromTable);
        await waitToBeDisplayed(this.serviceNowHomePageControls.FunctionalTesting);
        await click(this.serviceNowHomePageControls.FunctionalTesting);
        await click(this.serviceNowHomePageControls.UnitTesting);
        await click(this.serviceNowHomePageControls.SystemTesting);
        await sendKeys(this.serviceNowHomePageControls.SystemTestingExitCriteria,changeDataModel.SystemTestingExitCriteria);
        await click(this.serviceNowHomePageControls.HeaderUpdate);
        //await waitFor.time(5000);

        await this.FillRiskAssessment();

        await click(this.serviceNowHomePageControls.HeaderNextPhase);

        return await waitFor.time(2000);


    }

    public async FillRiskAssessment() : Promise<any>{

        await waitFor.elementToBeClickable(this.serviceNowHomePageControls.FillRiskAssessment,5000);
        await click(this.serviceNowHomePageControls.FillRiskAssessment);
        await waitFor.time(3000);
        await browser.switchTo().frame(browser.driver.findElement(by.xpath("//iframe[@class='gb_iframe']")));
        await browser.waitForAngular();
        await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectNonProdchange);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectSingleNonBusiness);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectBusinessProcess)
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectSingleLocation);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectLow);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectChangeRegularly);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectFullRedundancy);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectVeryLikely);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectGC51Yes);
        await click(this.serviceNowHomePageControls.RiskAssessmentSelectGC52Yes);
        //await waitFor.time(10000);
        await click(this.serviceNowHomePageControls.RiskAssessmentSubmit);
        //await waitFor.time(10000);
        await browser.switchTo().defaultContent();
        await browser.waitForAngular();
        await browser.switchTo().frame(browser.driver.findElement(by.tagName('iframe')));
        // await browser.switchTo().frame(this.serviceNowHomePageControls.FirstIframe);
        return await browser.waitForAngular();
    }

    public async AssertNavigateToBuildAndTest() : Promise<any> {
        await waitToBeDisplayed(this.serviceNowHomePageControls.ChangeTasksTab,10000);
        return await expect(this.serviceNowHomePageControls.ChangeTasksTab).to.be.displayed;
    }

      //     Scenario: Create Build and Test

    public async FillBuildAndTest(changeDataModel : ChangeDataModel): Promise<any>{
        
        await this.CloseBuildTask(changeDataModel);

        await this.CloseTestTask(changeDataModel);

        return await this.serviceNowHomePageControls.HeaderNextPhase.isDisplayed;

    }


    public async CloseBuildTask(changeDataModel : ChangeDataModel) : Promise<any>{

        await waitFor.time(5000);
        await click(this.serviceNowHomePageControls.ChangeTasksTab);

        await click(this.serviceNowHomePageControls.ChangeTasksBuild);

        await waitFor.time(2000);

        await sendKeys(this.serviceNowHomePageControls.ChangeTasks_Build_AssignedTo,changeDataModel.Build_ChangeTask_AssignedTo);
        await selectOptionByText(this.serviceNowHomePageControls.ChangeTasks_Build_ClosureCode,changeDataModel.Build_ChangeTask_ClosureCode);
        await sendKeys(this.serviceNowHomePageControls.ChangeTasks_Build_ClosingComments,changeDataModel.Build_ChangeTask_ClosingComments);

        await waitFor.time(2000);

        await click(this.serviceNowHomePageControls.HeaderUpdateAndSaveButton);

        //await waitFor.time(5000);

        await waitFor.elementToBeClickable(this.serviceNowHomePageControls.HeaderCloseTask,10000);
        
        await click(this.serviceNowHomePageControls.HeaderCloseTask);

        //await waitFor.time(6000);

        return await waitFor.time(5000);

    }

    public async CloseTestTask(changeDataModel : ChangeDataModel) : Promise<any>{

        await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.ChangeTasksTab);
        await click(this.serviceNowHomePageControls.ChangeTasksTest);

        await waitFor.time(3000);

        await sendKeys(this.serviceNowHomePageControls.ChangeTasks_Build_AssignedTo,changeDataModel.Build_ChangeTask_AssignedTo);
        await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.HeaderUpdateAndSaveButton);
        await waitFor.time(3000);
        //TestPlan_ChangeTask = this.serviceNowHomePageControls.HeaderUpdateAndSaveButton.getText();
        await click(this.serviceNowHomePageControls.HeaderAddAttachment);
        await waitFor.time(2000);
        var absolutePath = path.resolve(__dirname, changeDataModel.Test_ChangeTask_TestPlanAttachment);
        await this.serviceNowHomePageControls.ChangeTask_Test_AttachTestPlan.sendKeys(absolutePath);
        await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.ChangeTask_Test_CloseTestPlanPopUp);
        await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.HeaderCloseTask);
        //await waitFor.time(6000);
        //approve test task
        await this.ApproveTestTask();
        return await waitFor.time(5000);

    }


    public async ApproveTestTask() : Promise<any> {
        await waitFor.time(3000);
        await click(this.serviceNowHomePageControls.ChangeTasksTab);
        await click(this.serviceNowHomePageControls.ChangeTasksTest);
        await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.ChangeTestTaskApprovalTab);
        await waitFor.time(2000);
        await click(this.serviceNowHomePageControls.ChangeTestTaskApprovalItem);
        await waitFor.time(2000);
        
        await click(this.serviceNowHomePageControls.HeaderApprove);
        //await waitFor.time(12000);
        return await waitFor.time(2000);
    }


}