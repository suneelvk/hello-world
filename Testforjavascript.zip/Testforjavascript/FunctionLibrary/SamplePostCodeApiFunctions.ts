import * as rm from 'typed-rest-client';
import {PostcodeData} from '../ResponseInterface/PostData';
import { waitFor } from "../Helpers/waitFor";


//*************************************//

var chai = require('chai');
var chaiHttp = require('chai-http');

chai.use(chaiHttp);

const app : string = 'https://api.postcodes.io/';

//*************************************//


//**************//

var unirest = require('unirest');

var http = require("https");

//*******************//

export class ApiSampleFunctions {


    rest : rm.RestClient;
    resp : rm.IRestResponse<PostcodeData>;

    private delay(ms: number)
    {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    public async PostCodeGetAddress() : Promise<any> {

        await waitFor.time(5000);
        this.rest = new rm.RestClient('Postcode',app);
        //this.rest = new rm.RestClient('Postcode','https://api.postcodes.io/');
        var reponseCont = this.rest.get<PostcodeData>('postcodes/OX49 5NU');

        await  waitFor.time(10000);
        await console.log("======LoggingNow======");
        await console.log(reponseCont);


        //await console.log(this.resp.statusCode);
        //await console.log(this.resp.result.country);
        return waitFor.time(3000);

    }

    public async ChaiPostCode() : Promise<any> {
        await  waitFor.time(2000);
        //var requester = chai.request(app).keepOpen()
        var respons = chai.request(app).get('postcodes/OX49 5NU').end((err, res) => {
            console.log("======LoggingNowInnner======");
            console.log(err); // outputs null
            console.log(res); // outputs normal-looking response
            console.log(res.body) // { name: 'asad', class: 'paewe' };
        });
        await  waitFor.time(5000);
        await console.log("======LoggingNow======");
        await console.log(respons);
        return waitFor.time(3000);
    }


    public ChaiPostCodeNonPromise(){
        waitFor.time(2000);
        //var requester = chai.request(app).keepOpen()
        var respons = chai.request(app).get('postcodes/OX49 5NU')
        .end((err, res) => {
            console.log("======LoggingNowInnner======");
            console.log(err); // outputs null
            console.log(res); // outputs normal-looking response
            console.log(res.body) // { name: 'asad', class: 'paewe' };
        });
        waitFor.time(5000);
        console.log("======LoggingNow======");
        console.log(respons);
        console.log("===================ResponseContent=====================");
        console.log(respons.body);
        waitFor.time(3000);
    }


    public uniRestExample(){
        // var Request = unirest.get('https://api.postcodes.io/postcodes/OX49 5NU');
        // console.log("======LoggingNow======");
        // console.log(Request);
        // console.log("======****LoggingBody****======");
        // Request.end(function (res) {
        //     if (res.error) throw new Error(res.error);
          
        //     console.log(res.body);
        //   });

        //this.delay(3000);

        var req = unirest("GET", "https://api.postcodes.io/postcodes/OX49%205NU");
        
        // req.headers({
        //   "Postman-Token": "37836824-6ca4-4a34-bd3c-e699ad35f883",
        //   "cache-control": "no-cache"
        // });
        
        //this.delay(3000);
        req.end(function (res) {
          if (res.error) throw new Error(res.error);
          console.log("======****LoggingBody****======");
          console.log(res.body);
        });
        console.log("======****LoggingRequestBody****======");
        console.log(req.json);
        console.log("======****LoggingRequest****======");
        console.log(req);
    }

    public NavtiveExample(){
        var options = {
            "method": "GET",
            "hostname":"https://api.postcodes.io/postcodes/OX49%205NU",
            // "path": [
            //   "postcodes",
            //   "OX49%205NU"
            // ],
            "headers": {
              "cache-control": "no-cache",
              "Postman-Token": "5e707fc9-5073-4fb0-b82f-a4b0ba74192d"
            }
          };
          
          var req = http.request(options, function (res) {
            var chunks = [];
          
            res.on("data", function (chunk) {
              chunks.push(chunk);
            });
          
            res.on("end", function () {
              var body = Buffer.concat(chunks);
              console.log(body.toString());
            });
          });
          
          req.end();

    }

}
