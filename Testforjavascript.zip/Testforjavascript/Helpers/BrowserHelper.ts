import { browser, ProtractorBrowser } from 'protractor';

export class BrowserHelper {
    _webDriver: ProtractorBrowser;

    constructor(public driver: ProtractorBrowser = null) {
        this._webDriver = driver;
    }

    /**
     * Take screenshot from headless browser
     */
    public takeScreenShot(scenarioName: string) {
        const fs = require('fs');
        this._webDriver.takeScreenshot().then(function (png) {
            const name = 'scenario_' + scenarioName + '_screenshot.png';
            const stream = fs.createWriteStream('./TestResults/' + name);
            stream.write(new Buffer(png, 'base64'));
            stream.end();
        });
    }

    /**
     * Switch to different browser window handles
     * @param tabNumber
     */
    public switchToBrowserTab(tabNumber: number) {
        return this._webDriver.getAllWindowHandles().then(function (handles) {
            browser.switchTo().window(handles[tabNumber]);
        });
    }

    /**
     * Get Browser Current Url
     */
    public GetBrowserCurrentUrl() {
        return this._webDriver.getCurrentUrl();
    }

    /**
     * CloseCurrntTab
     */
    public CloseCurrentTab(tabNumber: number) {
        return this._webDriver.getAllWindowHandles().then(function (handles) {
            browser.switchTo().window(handles[tabNumber]).then(window => {
                console.log('Closing browser window');
                browser.quit();
            });
        });
    }

    public CloseBrowser() {
        return this._webDriver.quit();
    }
}
