const { BeforeAll, After, AfterAll, Status } = require("cucumber");
import * as fs from "fs";
import { browser } from "protractor";
import { config } from "../Config/config";

var {setDefaultTimeout} = require('cucumber');
var shell = require('shelljs');


BeforeAll({timeout: 100 * 1000}, function () {
    //shell.cp("-R", "SeleniumServer", "typeScript/SeleniumServer");
     setDefaultTimeout(600 * 1000);
     browser.get(config.baseUrl);
});

// BeforeAll({timeout: 100 * 1000}, async () => {
//     await setDefaultTimeout(60 * 1000);
//     await browser.get(config.baseUrl);
// });

After(async function(scenario) {
    if (scenario.result.status === Status.FAILED) {
        // screenShot is a base-64 encoded PNG
         const screenShot = await browser.takeScreenshot();
         this.attach(screenShot, "image/png");
    }
});

AfterAll({timeout: 100 * 1000}, async () => {
    await browser.quit();
});
