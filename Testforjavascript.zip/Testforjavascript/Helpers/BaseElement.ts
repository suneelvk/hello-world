// import { ProtractorBrowser, WebElement, protractor, ElementFinder } from 'protractor';
// import { By } from 'selenium-webdriver';

// // // remaove this later

// export class BaseElement {
//     by: By;
//     browser: ProtractorBrowser;
//     public element: WebElement;

//     constructor(findBy: By, webBrowser: ProtractorBrowser) {
//         this.by = findBy;
//         this.browser = webBrowser;
//         try {
//             this.element = this.browser.findElement(findBy);
//         } catch (err) {
//             console.log(err);
//             throw new Error('Unable to find element with selector #' + findBy);
//         }
//     }

//     // get IsEnabled() {
//     //     return this.element.isEnabled();
//     // }

//     /**
//      * Click on Element
//      */
//     public click() {
//         try {
//             if (this.element.isEnabled()) {
//                 return this.element.click();
//             }
//         } catch (error) {
//             console.log('An error occurred during click operation: ', error);
//         }
//     }

//     public ActionClick() {
//         this.browser.actions().mouseMove(this.element)
//             .click().perform();
//     }

//     public FindChildrenByCssValue(css: string) {
//         return this.element.findElements(By.css(css));
//     }

//     /**
//      * Mouse Hover on element
//      */
//     public mouseHover() {
//         try {
//             if (this.element.isEnabled()) {
//                 this.browser.actions().mouseMove(this.element).perform();
//             }
//         } catch (error) {
//             console.log('An error occurred during mouse hover operation: ', error);
//         }
//     }

//     /**
//      * Drag and drop element
//      * @param targetelement
//      */
//     public dragAndDrop(targetelement: WebElement) {
//         try {
//             if (this.element.isEnabled()) {
//                 this.browser.actions().dragAndDrop(this.element, targetelement).perform();
//                 // TODO: Check this functionality working while automating test cases and
//                 // change to Move operation if dragAndDrop is not working
//             }
//         } catch (error) {
//             console.log('An error occurred during drag and drop operation: ', error);
//         }

//     }

//     /**
//      * Wait for elelment
//      * @param finder
//      */
//     public waitForElement(finder: ElementFinder) {
//         const until = protractor.ExpectedConditions;
//         this.browser.wait(until.presenceOf(finder), 5000, 'Element taking too long to appear in the DOM');
//         // TODO: Check how to extract element finder from BY
//     }

//     /**
//      * Implicit wait for element
//      * @param waitTime
//      */
//     public waitForElementImplicit(waitTime: number) {
//         this.browser.driver.manage().timeouts().implicitlyWait(waitTime);
//     }

//     /**
//      * RightClick On The Element
//      */
//     public rightClick() {
//         this.browser.actions().mouseMove(this.element).perform();
//         this.browser.actions().click(protractor.Button.RIGHT).perform();
//     }

//     /**
//      * Right Click on the co-ordinates on bands
//      * @param toRight
//      * @param toBottom
//      */
//     public RightClickOnCoordinates(toRight, toBottom) {
//         this.browser.actions()
//             .mouseMove(this.element, { x: toRight, y: toBottom }).perform();
//         this.browser.sleep(6000);
//         this.browser.actions()
//             .click(protractor.Button.RIGHT)
//             .perform();
//     }

//     /**
//      * Set Focus on RoadMap
//      * @param x
//      * @param y
//      */
//     public SetFocusOnCoOrdinates(x, y) {
//         return this.browser.actions()
//             .mouseMove(this.element, { x: x, y: y }).perform();
//     }

//     /**
//      * Click On Co-Ordinates
//      * @param x
//      * @param y
//      */
//     public ClickOnCoOrdinates(x, y) {
//         this.browser.actions()
//             .mouseMove(this.element, { x: x, y: y })
//             .click()
//             .perform();
//     }

//     /**
//     * Double Click On The Element
//     */
//     public doubleClick() {
//         this.browser.actions().mouseMove(this.element).perform();
//         this.browser.actions().doubleClick().perform();
//     }
// }
