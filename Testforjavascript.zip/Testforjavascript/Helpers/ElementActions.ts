import { browser, WebElement, protractor, ElementFinder } from 'protractor';
import { By } from 'selenium-webdriver';

export class ElementActions {

    /**
     * Mouse poniter and click on element
     */
    public ActionClick(element: WebElement) {
            browser.actions().mouseMove(element)
            .click().perform();
    }

     /**
     * Mouse Hover on element
     */
    public mouseHover(element: WebElement) {
        try {
            if (element.isEnabled()) {
                browser.actions().mouseMove(element).perform();
            }
        } catch (error) {
            console.log('An error occurred during mouse hover operation: ', error);
        }
    }

    /**
     * Drag and drop element
     * @param targetelement
     */
    public dragAndDrop(element: WebElement, targetelement: WebElement) {
        try {
            if (element.isEnabled()) {
                browser.actions().dragAndDrop(element, targetelement).perform();
                // TODO: Check this functionality working while automating test cases and
                // change to Move operation if dragAndDrop is not working
            }
        } catch (error) {
            console.log('An error occurred during drag and drop operation: ', error);
        }

    }

    
    /**
     * RightClick On The Element
     */
    public rightClick(element: WebElement) {
        browser.actions().mouseMove(element).perform();
        browser.actions().click(protractor.Button.RIGHT).perform();
    }

    /**
     * Right Click on the co-ordinates on bands
     * @param toRight
     * @param toBottom
     */
    public RightClickOnCoordinates(element: WebElement ,toRight, toBottom) {
        browser.actions()
            .mouseMove(element, { x: toRight, y: toBottom }).perform();
        browser.sleep(6000);
        browser.actions()
            .click(protractor.Button.RIGHT)
            .perform();
    }

    /**
     * Set Focus on RoadMap
     * @param x
     * @param y
     */
    public SetFocusOnCoOrdinates(element: WebElement,x, y) {
        return browser.actions()
            .mouseMove(element, { x: x, y: y }).perform();
    }

    /**
     * Click On Co-Ordinates
     * @param x
     * @param y
     */
    public ClickOnCoOrdinates(element: WebElement,x, y) {
            browser.actions()
            .mouseMove(element, { x: x, y: y })
            .click()
            .perform();
    }

    /**
    * Double Click On The Element
    */
    public doubleClick(element: WebElement) {
        browser.actions().mouseMove(element).perform();
        browser.actions().doubleClick().perform();
    }


}