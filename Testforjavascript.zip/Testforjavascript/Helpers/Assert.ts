import { browser,ElementFinder,promise } from "protractor";
import { waitFor } from "../Helpers/waitFor";


const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
const expect = chai.expect;
const assert = chai.assert;

export class Assert {


    public async AssertPageLoadComplete(expectedWebElement :ElementFinder ) : Promise<any>{
        await browser.waitForAngular();
        await waitFor.presenceOfElement(expectedWebElement,30000)
        return await expectedWebElement.isDisplayed;
    }

    /**
     * Assert Value against Promise
     * @param actualPromise Promise from angular call
     * @param expectedValue expected value
     */
    public async AssertIfPageElementIsDisplayed(actualPromise : promise.Promise<boolean>): Promise<any> {
        return await actualPromise.then(function (res) {
            expect(res).to.equal(true);
        });
    }

    /**
     * Assert Value against Promise
     * @param actualPromise Promise from angular call
     * @param expectedValue expected value
     */
    public AssertValueAgainstPromise(actualPromise, expectedValue: any) {
        return actualPromise.then(function (res) {
            expect(res).to.equal(expectedValue);
        });
    }

    /**
     * Assert ProjectTitle from List Promise<webElement[]>
     * @param actualPromise Promise<WebElement[]>
     * @param expectedValue any expected value
     */
    public AssertProjectTitleAgainstPromise(actualPromise, expectedValue: any) {

        return actualPromise.then(function (res) {
            res.forEach((element) => {
                element.getText().then(function (x) {
                    if (x.includes(expectedValue)) {
                        const projTitle = x.split(" ")[1].split("\n")[0];
                        expect(projTitle).to.equal(expectedValue);
                    }
                });
            });
        });
    }

    // /**
    //  * Assert If element is displayed
    //  * @param element
    //  */
    // public AssertIfElementIsDisplayed(element: Promise<any>) {
    //     return element.then((res) => {
    //         // tslint:disable-next-line:no-unused-expression
    //         expect(res).to.be.displayed;
    //     });
    // }

        /**
     * Assert If element is displayed
     * @param element
     */
    public async AssertIfElementIsDisplayed(element:ElementFinder) : Promise<boolean> {
        return await expect(element).to.be.displayed;
    }

    public async AsseetIfPromiseIsTrue(element: Promise<boolean>): Promise<any>{
        return await expect(element).to.be.true;
    }

    /**
     * Assert two values
     * @param actualValue actual value
     * @param expectedValue expected value
     */
    public AssertValues(actualValue: any, expectedValue: any) {
        console.log("ActualValue: ", actualValue);
        console.log("ExpectedValue: ", expectedValue);
        return expect(actualValue).to.equal(expectedValue);
    }

    /**
     * Assert total count
     * @param actualValue actual count
     * @param expectedCount expected count
     */
    public AssertTotalCount(actualValue: Promise<any[]>, expectedCount: number) {
        return actualValue.then((res) => {
            expect(res.length).to.equal(expectedCount);

        });
    }

    public AssertRowIndex(actualValue, expectedRowIndex: number, expectedValue: string) {
        return actualValue.then(x => {
            x[expectedRowIndex].getText().then(value => {
                expect(value.split('\n')[0]).to.equal(expectedValue);
            });
        });
    }

    public AssertElementOfTimeLine(actualElements: any, expectedString: string, elementIndex: number) {
        return actualElements.then(x => {
            return x[elementIndex].getText().then(res => {
                expect(res).to.equal(expectedString);
            });
        });
    }

    // /**
    //  * Assert Hidden swimlane
    //  * @param actualElements
    //  * @param expectedSwimlaneTitle
    //  */
    // public AssertHiddenSwimlane(actualElements: any, expectedSwimlaneTitle: string) {
    //     return actualElements.then(res => {
    //         res.some(function (element) {
    //             element.getText().then(text => {
    //                 if (text.includes(expectedSwimlaneTitle)) {
    //                     assert.isOk(false, expectedSwimlaneTitle + ' is not hidden');
    //                 }
    //             });
    //         });
    //     });
    // }

    // /**
    //  * Assert Hidden swimlane
    //  * @param actualElements
    //  * @param expectedSwimlaneTitle
    //  */
    // public AssertUnHideSwimlane(actualElements: any, expectedSwimlaneTitle: string) {
    //     return actualElements.then(res => {
    //         res.some(function (element) {
    //             element.getText().then(text => {
    //                 if (text.includes(expectedSwimlaneTitle)) {
    //                     assert.isOk(true, expectedSwimlaneTitle + ' is not visible');
    //                 }
    //             });
    //         });
    //     });
    // }

    // public AssetSwimlaneTitleChanged(swimlaneElem: WebElement, expectedSwimlaneTitle: string) {
    //     return swimlaneElem.getText().then((text) => {
    //         if (text.includes(expectedSwimlaneTitle)) {
    //             assert.isOk(true, expectedSwimlaneTitle + ' is  changed');
    //         }
    //         else {
    //             assert.isOk(false, expectedSwimlaneTitle + ' is not  changed');
    //         }
    //     });
    // }


}

