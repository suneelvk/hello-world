import * as shell from "shelljs";

shell.cp("-R", "TestData/UploadFiles", "typeScript/TestData/UploadFiles");
shell.cp("-R", "SeleniumServer", "typeScript/SeleniumServer");

//shell.cp("-R", "src/public/fonts", "dist/public/");
//shell.cp("-R", "src/public/images", "dist/public/");