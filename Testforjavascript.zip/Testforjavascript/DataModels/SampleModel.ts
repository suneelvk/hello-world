interface IProject {
    title: string;
    asset: string;
    description: string;
    startDate: string;
    endDate: string;
}
