import { BaseModel, ModelProperty } from '../Helpers/ModelMapper';

export class ChangeDataModel extends BaseModel {
    @ModelProperty()
    public SearchCriteria: string;

    @ModelProperty()
    public BussnessServiceOffering: string;

    @ModelProperty()
    public ShortDescription: string;

    @ModelProperty()
    public Description: string;

    @ModelProperty()
    public Justification: string;

    @ModelProperty()
    public RequestedByDate: string;

    @ModelProperty()
    public ChangeType: string;

    @ModelProperty()
    public AssignedTo: string;

    @ModelProperty()
    public ReasonForChange: string;

    @ModelProperty()
    public PlannedStartDate: string;

    @ModelProperty()
    public PlannedEndDate: string;

    @ModelProperty()
    public ChangePlan: string;

    @ModelProperty()
    public BackoutPlan: string;

    @ModelProperty()
    public TestPlan: string;

    @ModelProperty()
    public SystemTestingExitCriteria: string;

    @ModelProperty()
    public Build_ChangeTask_AssignedTo: string;

    @ModelProperty()
    public Build_ChangeTask_ClosureCode: string;

    @ModelProperty()
    public Build_ChangeTask_ClosingComments: string;

    @ModelProperty()
    public Test_ChangeTask_TestPlanAttachment: string;

}