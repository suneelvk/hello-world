﻿namespace Shell.TCoE.Appium.Core.Utilities
{
    class IOSUtilities
    {
    }
}
