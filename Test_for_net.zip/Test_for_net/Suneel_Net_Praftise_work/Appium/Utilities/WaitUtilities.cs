﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace Shell.TCoE.Appium.Core.Utilities
{
    public static class WaitUtilities
    {
        #region Private Declarations

        private static readonly WebDriverWait wait = new WebDriverWait(AppiumBase.AppiumDriver, TimeSpan.FromSeconds(60));

        #endregion Private Declarations

        #region Public Methods

        /// <summary>
        /// Wait for an element
        /// </summary>
        /// <param name="locator"></param>
        public static void WaitForElement(By locator)
        {
            wait.Until(ExpectedConditions.ElementIsVisible(locator));
        }

        /// <summary>
        /// Wait for an element staleness
        /// </summary>
        /// <param name="element"></param>
        public static void WaitforStaleness(IWebElement element)
        {
            wait.Until(ExpectedConditions.StalenessOf(element));
        }

        /// <summary>
        /// Waits till the web element is clickable
        /// </summary>
        /// <param name="element">Web Element</param>
        public static void WaitTillElementIsClickable(this IWebElement element)
        {
            wait.Until(ExpectedConditions.ElementToBeClickable(element));
        }

        /// <summary>
        /// Wait till element is selected
        /// </summary>
        /// <param name="element"></param>
        public static void WaitTillElementIsSelected(IWebElement element)
        {
            DefaultWait<IWebElement> waitElement = new DefaultWait<IWebElement>(element);
            waitElement.Timeout = TimeSpan.FromMinutes(2);
            waitElement.PollingInterval = TimeSpan.FromMilliseconds(250);

            Func<IWebElement, bool> waiter = new Func<IWebElement, bool>((IWebElement ele) =>
            {
                if (element.Selected)
                {
                    return true;
                }
                element.Click();
                return false;
            });
            waitElement.Until(waiter);
        }

        #endregion Public Methods
    }
}