﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace Shell.TCoE.Appium.Core.Utilities
{
    public static class AssertUtilities
    {
        /// <summary>
        /// Asserts string messages
        /// </summary>
        /// <param name="actualText">Actual Text : Expected non-null and non-empty string</param>
        /// <param name="expectedText">Expected Text : Expected non-null and non-empty string</param>
        public static void AssertElementText(string actualText, string expectedText)
        {
            if (string.IsNullOrEmpty(actualText) || string.IsNullOrEmpty(expectedText))
            {
                Assert.Fail("One of the argument is null or empty");
            }
            Assert.AreEqual<string>(expectedText, actualText, $"String assertion failed. Expected Text is : {expectedText} but Actual Text is {actualText}");
        }

        /// <summary>
        /// Assert List contains or doesn't contain specific item
        /// </summary>
        /// <typeparam name="T">Type of parameters</typeparam>
        /// <param name="collection"></param>
        /// <param name="objectToSearch"></param>
        /// <param name="checkForContains">if true, logic will run for asserting conatins, if false then assert for doesn't contain</param>
        public static void AssertListContainsItem<T>(List<T> collection, T objectToSearch, bool checkForContains)
        {
            if (checkForContains)
            {
                CollectionAssert.Contains(collection, objectToSearch, $"List doesn't contain item {objectToSearch}");
            }
            else
            {
                CollectionAssert.DoesNotContain(collection, objectToSearch, $"List contains item {objectToSearch}");
            }
        }

        /// <summary>
        /// Assert for Null checks
        /// </summary>
        /// <typeparam name="T">Type of parameters</typeparam>
        /// <param name="value">value to check</param>
        /// <param name="checkForNull">if True: check for null, if False: check for not null</param>
        public static void AssertNull<T>(T value, bool checkForNull)
        {
            if (checkForNull)
            {
                Assert.IsNull(value, $"Provided value {value} is not null");
            }
            else
            {
                Assert.IsNotNull(value, $"Provided value {value} is null");
            }
        }
    }
}