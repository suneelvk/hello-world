﻿namespace Shell.TCoE.Appium.Core.Utilities
{
    public static class AndroidExtensions
    {
    }
}