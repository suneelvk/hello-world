﻿using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.MultiTouch;
using System.Drawing;
using System.IO;
using System.Reflection;

namespace Shell.TCoE.Appium.Core.Utilities
{
    public static class AndroidUtilities
    {
        #region Private Declarations

        /// <summary>
        /// An Instance of Android Driver
        /// </summary>
        private static readonly AndroidDriver<AppiumWebElement> androidDriver = (AndroidDriver<AppiumWebElement>)AppiumBase.AppiumDriver;

        private static IConfiguration config;

        #endregion Private Declarations

        #region Public Methods

        /// <summary>
        /// Launch Android APP
        /// </summary>
        public static void LaunchAndroidApp()
        {
            androidDriver.LaunchApp();
        }

        /// <summary>
        /// Get screenshot saving path
        /// </summary>
        /// <returns></returns>
        public static string GetScreenshotPath()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Android_ScreenShot.png";
        }

        /// <summary>
        /// Take screenshot of the app
        /// </summary>
        public static void TakeScreenshot()
        {
            Screenshot screenshot = androidDriver.GetScreenshot();
            screenshot.SaveAsFile(GetScreenshotPath(), ScreenshotImageFormat.Png);
        }

        /// <summary>
        /// Scroll to element on the App
        /// </summary>
        /// <param name="elementText"></param>
        public static void ScrollToElement(string elementText)
        {
            androidDriver.FindElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"" + elementText + "\").instance(0))");
        }

        //TODO: Add method for horizontal scroll

        /// <summary>
        /// drag and drop elements
        /// </summary>
        /// <param name="sourceElement"></param>
        /// <param name="destElement"></param>
        public static void DragAndDropElement(AppiumWebElement sourceElement, AppiumWebElement destElement)
        {
            //TouchAction action = new TouchAction(androidDriver);
            //action.Press(sourceElement).Perform();

            TouchAction action = new TouchAction(androidDriver);
            action.Press(sourceElement).MoveTo(destElement).Release().Perform();
        }

        /// <summary>
        /// accept alert
        /// </summary>
        public static void AcceptAlert()
        {
            androidDriver.SwitchTo().Alert().Accept();
        }

        /// <summary>
        /// Dismiss alert
        /// </summary>
        public static void DismissAlert()
        {
            androidDriver.SwitchTo().Alert().Dismiss();
        }

        /// <summary>
        /// Send Text to AlertBox
        /// </summary>
        public static void SendText(AppiumWebElement ele, string text)
        {
            ele.SendKeys(text);
        }

        /// <summary>
        /// scroll up on alert
        /// </summary>
        /// <param name="alertelement"></param>
        public static void ScrollDownOnAlert(AppiumWebElement alertelement)
        {
            TouchAction act = new TouchAction(AppiumBase.AppiumDriver);
            Size dimensions = alertelement.Size;
            double screenHeightStart = (dimensions.Height * 0.5);
            double screenHeightEnd = dimensions.Height * 0.3;
            act.LongPress(alertelement, 0, 0).Wait(1000).MoveTo(0, -(dimensions.Height + 200)).Release();
            MultiAction multiAction = new MultiAction(AppiumBase.AppiumDriver);
            multiAction.Add(act).Perform();
        }

        /// <summary>
        /// scroll horizontally to an element
        /// </summary>
        /// <param name="pictureElement"></param>
        /// <param name="startPercentage"></param>
        /// /// <param name="finalPercentage"></param>
        /// <param name="duration"></param>
        public static void ScrollHorizontallyRight(AppiumWebElement pictureElement, double startPercentage, double finalPercentage, int duration)
        {
            TouchAction act = new TouchAction(AppiumBase.AppiumDriver);
            Size dimensions = pictureElement.Size;
            double screenWidthStart = (dimensions.Width * startPercentage);
            double screenWidthEnd = (dimensions.Width * finalPercentage);
            act.Press(pictureElement).Wait(duration).MoveTo(screenWidthStart, screenWidthEnd).Release().Perform();
        }

        /// <summary>
        /// scroll up on alert
        /// </summary>
        /// <param name="alertelement"></param>
        public static void ScrollUpOnAlert(AppiumWebElement alertelement, double currentX, double currentY)
        {
            TouchAction act = new TouchAction(AppiumBase.AppiumDriver);
            Size dimensions = alertelement.Size;
            double screenHeightStart = (dimensions.Height * 0.5);
            double screenHeightEnd = dimensions.Height * 0.3;
            act.LongPress(alertelement).Wait(1000).MoveTo(0, 0).Release();
            MultiAction multiAction = new MultiAction(AppiumBase.AppiumDriver);
            multiAction.Add(act).Perform();
        }

        /// <summary>
        /// Navigate to the previous screen
        /// </summary>
        public static void GoBackToPreviousScreen()
        {
            androidDriver.PressKeyCode(AndroidKeyCode.Back);
        }

        #endregion Public Methods
    }
}