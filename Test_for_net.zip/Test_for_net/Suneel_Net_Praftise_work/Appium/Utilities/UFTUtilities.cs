﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Shell.TCoE.Appium.Core.Utilities
{
    public static class UFTUtilities
    {
        /// <summary>
        /// Start UFt application
        /// </summary>
        public static void StartUft(string Invoker, string testcaseName, string path)
        {
            Process scriptProc = new Process();
            scriptProc.StartInfo.FileName = @"cscript";
            var uftPath = Path.Combine(path, "UftInvoker");
            scriptProc.StartInfo.WorkingDirectory = uftPath;
            string testName = Path.Combine(path, testcaseName);
            scriptProc.StartInfo.Arguments = string.Format("{0} /QTPTestName:\"{1}\"", Invoker, testName);
            scriptProc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden; //prevent console window from popping up
            scriptProc.StartInfo.UseShellExecute = false;
            scriptProc.StartInfo.RedirectStandardOutput = true;
            scriptProc.StartInfo.RedirectStandardError = true;
            scriptProc.Start();
            scriptProc.WaitForExit();
            //Read the output (or the error)
            string output = scriptProc.StandardOutput.ReadToEnd();
            string err = scriptProc.StandardError.ReadToEnd();
            try
            {
                Assert.AreEqual(output.ToString().ToLower().Trim().Contains("true"), true);
            }
            catch (Exception ex)
            {
                throw new Exception("The " +
                    testName.Split('/').Where(x => !string.IsNullOrWhiteSpace(x)).LastOrDefault() + " UFT testcase failed. ");
            }
            scriptProc.Close();
        }
    }
}
