﻿using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.Appium.Service.Options;
using OpenQA.Selenium.Safari;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Shell.TCoE.Appium.Core
{
    public class AppiumBase
    {
        #region Private Variables

        private static AppiumLocalService _appiumLocalService;
        private static string _platform;
        private static string _appType;
        private static string _deviceName;
        private static string _platformVersion;
        private static string _browserName;
        private static string _apkName;
        private static string _timeOut;
        private static string _appiumJsFileLocation;
        private static string _sauceLabsUserName;
        private static string _sauceLabsKey;
        private static bool _is_sauce;
        private static bool _is_browserStack;
        private static string _browserStackServer_Url;
        private static string _browserStackUser;
        private static string _browserStackAccessKey;
        private static string _browserStackAppId;
        private static string _is_browserStack_local;
        private static string _is_browserStack_browser;
        private static string _browserStackVideo;
        private static string _nodeJsLocation;
        private static IConfiguration config;
        private static string s_appSettingsPath;

        #endregion Private Variables

        #region Private Methods

        /// <summary>
        /// Instance initialization
        /// </summary>
        private static readonly Lazy<AppiumBase> instance = new Lazy<AppiumBase>(() =>
        {
            GetAppSettings();
            switch (_platform)
            {
                case "Android":
                    InitializeAndroidDriver();
                    break;

                case "IOS":
                    InitializeIOSDriver();
                    break;

                default:
                    throw new InvalidOperationException("Please choose a valid environment");
            }

            return new AppiumBase();
        });

        /// <summary>
        /// Get Configuration
        /// </summary>
        /// <returns></returns>
        private static IConfiguration GetIConfigurationRoot()
        {
            config = new ConfigurationBuilder()
         .SetBasePath(GetAppSettingsPath())
         .AddJsonFile("appSettings.json", optional: true)
         .Build();

            return config;
        }

        /// <summary>
        /// Get appsettings.json file path
        /// </summary>
        /// <returns></returns>
        private static string GetAppSettingsPath()
        {
            return s_appSettingsPath ?? Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        }

        /// <summary>
        /// Initialize android driver
        /// </summary>
        private static void InitializeAndroidDriver()
        {
            string testAppPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", _apkName);

            var appiumOptions = new AppiumOptions();
            appiumOptions.AddAdditionalCapability(MobileCapabilityType.PlatformName, _platform);
            appiumOptions.AddAdditionalCapability(MobileCapabilityType.PlatformVersion, _platformVersion);
            appiumOptions.AddAdditionalCapability(MobileCapabilityType.DeviceName, _deviceName);
            appiumOptions.AddAdditionalCapability(MobileCapabilityType.NewCommandTimeout, _timeOut);
           
            switch (_appType)
            {
                case "native":
                    appiumOptions.AddAdditionalCapability(MobileCapabilityType.App, testAppPath);
                   // appiumOptions.AddAdditionalCapability(MobileCapabilityType.AutomationName, "UIAutomator2");
                    break;

                case "hybrid":
                    appiumOptions.AddAdditionalCapability(MobileCapabilityType.BrowserName, _browserName);
                    // appiumOptions.AddAdditionalCapability(MobileCapabilityType.AutomationName, "UIAutomator2");
                    appiumOptions.AddAdditionalCapability(MobileCapabilityType.DeviceName, _deviceName);
                    break;

                case "parallel":
                    appiumOptions.AddAdditionalCapability(MobileCapabilityType.App, testAppPath);
                    appiumOptions.AddAdditionalCapability(MobileCapabilityType.BrowserName, _browserName);
                    appiumOptions.AddAdditionalCapability(MobileCapabilityType.DeviceName, _deviceName);
                    break;

                default:
                    throw new InvalidOperationException("Please choose a valid Android app Type");
            }

            AppiumDriver = new AndroidDriver<AppiumWebElement>(_appiumLocalService, appiumOptions, TimeSpan.FromSeconds(Convert.ToInt32(_timeOut)));          
            AppiumDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(Convert.ToInt32(_timeOut));
        }

        //private static void InitializeAndroidWebDriver()
        //{
        //    // StartAppiumServer();

        //    string testAppPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", _apkName);

        //    var appiumOptions = new AppiumOptions();
        //    appiumOptions.AddAdditionalCapability(MobileCapabilityType.BrowserName, _browserName);
        //    appiumOptions.AddAdditionalCapability(MobileCapabilityType.PlatformName, _platform);
        //    appiumOptions.AddAdditionalCapability(MobileCapabilityType.PlatformVersion, _platformVersion);
        //    // appiumOptions.AddAdditionalCapability(MobileCapabilityType.AutomationName, "UIAutomator2");
        //    appiumOptions.AddAdditionalCapability(MobileCapabilityType.DeviceName, _deviceName);
        //   // appiumOptions.AddAdditionalCapability(MobileCapabilityType.App, testAppPath);
        //    appiumOptions.AddAdditionalCapability(MobileCapabilityType.NewCommandTimeout, _timeOut);

        //    // driver = new AndroidDriver<AndroidElement>(new Uri(""), capabilities, TimeSpan.FromSeconds(120));

        //    AppiumDriver = new AndroidDriver<AppiumWebElement>(_appiumLocalService, appiumOptions, TimeSpan.FromSeconds(120));
        //    AppiumDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(120);
        //}

        /// <summary>
        /// Initialize IOS driver
        /// </summary>
        private static void InitializeIOSDriver()
        {
            SafariOptions capabilities = new SafariOptions();
            capabilities.AddAdditionalCapability(MobileCapabilityType.BrowserName, "");
            capabilities.AddAdditionalCapability(MobileCapabilityType.PlatformName, "iOS");
            capabilities.AddAdditionalCapability(MobileCapabilityType.PlatformVersion, "");
            capabilities.AddAdditionalCapability(MobileCapabilityType.AutomationName, "XCUITest");
            capabilities.AddAdditionalCapability(MobileCapabilityType.DeviceName, "");
            capabilities.AddAdditionalCapability(MobileCapabilityType.App, "");

            // driver = new IOSDriver<IOSElement>(new Uri(""), capabilities, TimeSpan.FromSeconds(120));

            AppiumDriver = new IOSDriver<AppiumWebElement>(new Uri(""), capabilities, TimeSpan.FromSeconds(120));
            AppiumDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(120);
        }

        /// <summary>
        /// Get server uri for android
        /// </summary>
        /// <returns></returns>
        private static Uri GetServerUriForAndroid()
        {
            Uri serverUri;

            if (_is_sauce)
            {
                serverUri = new Uri($"https://{_sauceLabsUserName}:{_sauceLabsKey}@ondemand.saucelabs.com:80/wd/hub");
            }
            else if (_is_browserStack)
            {
                serverUri = new Uri($"http://{_browserStackServer_Url }/wd/hub/");
            }
            else
            {
                serverUri = _appiumLocalService.ServiceUrl;
            }

            return serverUri;
        }

        /// <summary>
        /// Get appsettings.json values
        /// </summary>
        private static void GetAppSettings()
        {
            config = GetIConfigurationRoot();

            #region Environment App settings

            _platform = config["Android:platformName"];
            _deviceName = config["Android:deviceName"];
            _platformVersion = config["Android:platformVersion"];
            _browserName = config["Android:browserName"];
            _apkName = config["Android:apkName"];
            _timeOut = config["Android:timeOut"];
            _appiumJsFileLocation = config["Android:appiumJsFileLocation"];
            _appType = config["Android:appType"];
            _nodeJsLocation = config["Android:nodejsLocation"];

            #endregion Environment App settings

            #region Browserstack settings

            //_browserStackUser = config["BrowserStackUserName"];
            //_browserStackpassword = config["BrowserStackPassword"];

            #endregion Browserstack settings

            #region Sauce labs Settings

            //_commandExecutionUri = config["CommandExecutionUri"];
            //_remoteBrowser = config["RemoteBrowser"];
            //_remotebrowserVersion = config["RemoteBrowserVersion"];
            //_remotePlatform = config["RemotePlatform"];
            //_sauceLabsUserName = config["SauceLabsUserName"];
            //_sauceLabsKey = config["SauceLabsUserPassword"];
            //_recordScreenshots = Convert.ToBoolean(config["RecordScreenshots"]);
            //_recordVideo = Convert.ToBoolean(config["RecordVideo"]);
            //_remotescreenResolution = config["ScreenResolution"];
            //  _maxDuration = config["MaximumDuration"];

            #endregion Sauce labs Settings
        }

        #endregion Private Methods

        #region Public Methods

        public static string AppSettingsPath
        {
            get => s_appSettingsPath;
            set => s_appSettingsPath = value;
        }


        public static AppiumLocalService AppiumLocalService
        {
            get => _appiumLocalService;
            set => _appiumLocalService = value;
        }

        /// <summary>
        /// The public singleton Property
        /// </summary>
        public static AppiumBase Instance => instance.Value;

        /// <summary>
        /// The Selenium WebDriver
        /// </summary>
        public static AppiumDriver<AppiumWebElement> AppiumDriver { get; set; }

        /// <summary>
        /// Get rid of the WebDriver
        /// </summary>
        public static void Dispose()
        {
            if (AppiumDriver != null)
            {
                AppiumDriver.Dispose();
            }

            //if (_environment.Contains("remote") && _browserStackLocal.isRunning())
            //{
            //    _browserStackLocal.stop();
            //}
        }

        /// <summary>
        /// start appium local service. This needs js file path from appsettings.json
        /// </summary>
       

        /// <summary>
        /// Start appium web server
        /// </summary>
        public static void StartAppiumWebServer()
        {
            string appDataFile = Environment.GetEnvironmentVariable("appData");

            FileInfo file = new FileInfo(appDataFile + @"\npm\node_modules\appium\build\lib\main.js");

            OptionCollector optionCollector = new OptionCollector();
            optionCollector.AddArguments(new KeyValuePair<string, string>("--chromedriver-executable", @"C:\Users\Shwetha.DJ\Downloads\chromedriver_win32(3)\chromedriver.exe"));

            AppiumServiceBuilder builder = new AppiumServiceBuilder()
                .UsingAnyFreePort().WithAppiumJS(file)
                .WithArguments(optionCollector);

            _appiumLocalService = builder.Build();
            _appiumLocalService.Start();

            //.WithArguments(GeneralServerFlag.APP, System.getProperty("user.dir") + "/build/wordpress.apk")
            //.WithArgument(GeneralServerFlag.LOG_LEVEL, "info")
            //.WithLogFile(new File(System.getProperty("user.dir") + "/target/logs/sample.txt"))
        }

        #endregion Public Methods
    }
}