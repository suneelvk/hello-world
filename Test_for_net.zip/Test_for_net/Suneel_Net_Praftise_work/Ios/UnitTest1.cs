using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Shell.TCoE.DotNet_MobilityFramework
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
