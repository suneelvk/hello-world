﻿using Shell.TCoE.MobilityLibrary.ControlLibrary;
using Shell.TCoE.MobilityLibrary.FunctionalLibrary;
using Shell.TCoE.Specflow.Tests.Classes;
using System.IO;
using System.Reflection;
using System.Threading;
using TechTalk.SpecFlow;

namespace Shell.TCoE.Specflow.Tests.StepDefinition
{
    [Binding]
    public class ApiDemoesApkTestSteps
    {
        private ApiDemosFunctions apiDemosFunctions;
        private ApiDemosControls apiDemosControls;

        [BeforeScenario]
        public void TestInitialize()
        {
            apiDemosControls = new ApiDemosControls();
            apiDemosFunctions = new ApiDemosFunctions(apiDemosControls);
        }

        [Given(@"I have launched apidemos app")]
        public void GivenIHaveLaunchedApidemosApp()
        {
            // TestInitialization.LaunchAndroidApk();
        }

        [When(@"I click on ""(.*)""")]
        public void WhenIClickOn(string p0)
        {
            Thread.Sleep(4000);
        }

        [When(@"I test ""(.*)""")]
        public void WhenITest(string p0)
        {
            apiDemosFunctions.Test_Views();
        }

        [Then(@"I test checkboxes and radiobuttons")]
        public void ThenITestCheckboxesAndRadiobuttons()
        {
            apiDemosFunctions.Test_ControlsOnViews();
        }

        [Then(@"I verify font styles")]
        public void ThenIVerifyFontStyles()
        {
            apiDemosFunctions.VerifyFont();
        }

        [Then(@"I verify popups")]
        public void ThenIVerifyPopups()
        {
            apiDemosFunctions.VerifyPopupMenu();
        }

        [When(@"I Click on Views")]
        public void WhenIClickOnViews()
        {
            apiDemosFunctions.ClickOnViews();
        }

        [When(@"i Click on Expandable Lists")]
        public void WhenIClickOnExpandableLists()
        {
            apiDemosFunctions.ClickOnExpandableList();
        }

        [Then(@"I Verify all lists")]
        public void ThenIVerifyAllLists()
        {
            apiDemosFunctions.VerifyExpandableLists();
        }

        [Then(@"I verify DragAndDrop")]
        public void ThenIVerifyDragAndDrop()
        {
            apiDemosFunctions.VerifyDragAndDrop();
        }

        [When(@"I Click on App")]
        public void WhenIClickOnApp()
        {
            apiDemosFunctions.ClickOnAppOption();
        }

        [Then(@"I verify alerts")]
        public void ThenIVerifyAlerts()
        {
            apiDemosFunctions.VerifyAlerts("user1","password123");
        }

        [When(@"I click on Date")]
        public void WhenIClickOnDate()
        {
            apiDemosFunctions.ClickOnDate();
        }

        [Then(@"I select Date")]
        public void ThenISelectDate()
        {
            apiDemosFunctions.SelectDate("10/12/2020");
        }

        [When(@"I start UFT")]
        public void ThenIStartUft()
        {
            var path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            apiDemosFunctions.NavigateToUFT("UFT.vbs", TestInitialization.UftTestname, path);
        }

        [When(@"I Click on Gallery")]
        public void WhenIClickOnGallery()
        {
            apiDemosFunctions.GotoGallery();
        }

        [Then(@"I Select Picture")]
        public void ThenISelectPicture()
        {
            apiDemosFunctions.SelectPicture();
        }
    }
}