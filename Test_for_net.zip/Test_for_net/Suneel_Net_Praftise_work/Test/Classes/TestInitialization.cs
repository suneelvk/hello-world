﻿using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Appium.Service;
using Shell.TCoE.Appium.Core;
using Shell.TCoE.Appium.Core.Utilities;
using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using TechTalk.SpecFlow;
using Unity;

namespace Shell.TCoE.Specflow.Tests.Classes
{
    [Binding]
    public sealed class TestInitialization
    {
        private static IConfiguration config;
        private static string _ufttestname;

        public static IConfiguration GetIConfigurationRoot(string outputPath)
        {
            config = new ConfigurationBuilder()
         .SetBasePath(outputPath)
         .AddJsonFile("appSettings.json", optional: true)
         .Build();

            return config;
        }


        private static AppiumLocalService _appiumLocalService;

        /// <summary>
        /// The Test suite runs this code first
        /// </summary>
        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            config = GetIConfigurationRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));

            var _appiumJsFileLocation = config["Android:appiumJsFileLocation"];
            var _nodeJsLocation = config["Android:nodejsLocation"];
            _ufttestname = config["UFT:uftTestcaseName"];
            string appDataFile = Environment.GetEnvironmentVariable("appData");
            FileInfo file = new FileInfo(appDataFile + _appiumJsFileLocation);
            StartAppiumServer(file, _nodeJsLocation);

            AppiumBase.AppiumLocalService = _appiumLocalService;

            CreateUnityContainer();

            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("nl-NL");
            ExtentReportsInitilization.InitializeReport();
            //  s_accessibilityUtility = new AccessibilityUtility(SeleniumBase.WebDriver);
        }

        public static void StartAppiumServer(FileInfo appiumJsFile, string nodePath)
        {
            config = GetIConfigurationRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            var _appiumJsFileLocation = config["Android:appiumJsFileLocation"];
            var _nodeJsLocation = config["Android:nodejsLocation"];

            string appDataFile = Environment.GetEnvironmentVariable("appData");

            FileInfo file = new FileInfo(appDataFile + _appiumJsFileLocation);

            AppiumServiceBuilder builder = new AppiumServiceBuilder()
                .UsingDriverExecutable(new FileInfo(nodePath))
                .UsingAnyFreePort().WithAppiumJS(appiumJsFile);
            _appiumLocalService = builder.Build();
            _appiumLocalService.Start();

            //.WithArguments(GeneralServerFlag.APP, System.getProperty("user.dir") + "/build/wordpress.apk")
            //.WithArgument(GeneralServerFlag.LOG_LEVEL, "info")
            //.WithLogFile(new File(System.getProperty("user.dir") + "/target/logs/sample.txt"))
        }

        /// <summary>
        /// Send the UFT testcase name
        /// </summary>
        public static string UftTestname
        {
            set
            {
                _ufttestname = value;
            }
            get => _ufttestname;
        }

        /// <summary>
        /// Code to execute after ever step is executed in a scenario
        /// </summary>
        [AfterScenarioBlock]
        public static void AfterScenarioBlock()
        {
            Console.Write(ScenarioContext.Current.ScenarioExecutionStatus.ToString());
        }

        /// <summary>
        /// This runs before every feature
        /// </summary>
        [BeforeFeature(Order = 0)]
        public static void BeforeFeature()
        {
            ExtentReportsInitilization.BeforeFeature();
        }

        /// <summary>
        /// This runs before every feature with specific tag
        /// </summary>
        [BeforeFeature("apidemosFeature")]
        public static void LaunchAndroidApk()
        {
            //AndroidUtilities.LaunchAndroidApp();
        }

        /// <summary>
        /// This runs before every feature with specific tag
        /// </summary>
        [BeforeFeature("ShellHubTest")]
        public static void ShellHubLogin()
        {
            // BrowserUtilities.NavigateToAddress(config["applicationUrl"]);
        }

        /// <summary>
        /// This runs before every feature with specific tag
        /// </summary>
        [BeforeFeature("ActionTests")]
        public static void ActionTestsLogin()
        {
            //BrowserUtilities.NavigateToAddress(config["actionTestsaddress"]);
        }

        /// <summary>
        /// This runs before every scenario
        /// </summary>
        [BeforeScenario]
        public void BeforeScenario()
        {
            //AndroidUtilities.LaunchAndroidApp();
            ExtentReportsInitilization.Initialize();
        }

        /// <summary>
        /// Runs after scenario
        /// </summary>
        [AfterScenario]
        public void AfterScenario()
        {
            if (ScenarioContext.Current.TestError != null)
            {
                AndroidUtilities.TakeScreenshot();
            }
        }

        /// <summary>
        /// executes after each step
        /// </summary>
        [AfterStep]
        public void AfterStep()
        {
            ExtentReportsInitilization.InsertReportingSteps();
        }

        /// <summary>
        /// Executes before test execution ends
        /// </summary>
        [AfterTestRun]
        public static void AfterTestRun()
        {
            ExtentReportsInitilization.TearDownReport();

            if (AppiumBase.Instance != null)
            {
                AppiumBase.AppiumDriver.CloseApp();
                AppiumBase.Dispose();
            }
            //s_accessibilityUtility.CloseHtmlPage();
            if (_appiumLocalService != null)
            {
                _appiumLocalService.Dispose();
            }
        }

        #region Private Methods

        /// <summary>
        /// Constructor
        /// </summary>
        /// <returns>A Unity Container</returns>
        private static IUnityContainer CreateUnityContainer()
        {
            IUnityContainer unity = new UnityContainer();
            AppiumBase.AppSettingsPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            unity.RegisterInstance(AppiumBase.Instance);
            unity.RegisterInstance(AppiumBase.AppiumDriver);
            return unity;
        }

        #endregion Private Methods
    }
}