﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using Microsoft.Extensions.Configuration;
using Shell.TCoE.Appium.Core.Utilities;
using System;
using System.IO;
using System.Reflection;
using TechTalk.SpecFlow;

namespace Shell.TCoE.Specflow.Tests.Classes
{
    public static class ExtentReportsInitilization
    {

        #region Environment Variables

        private static string _useKlov;
        private static string _mongodbUrl;
        private static int _mongodbPort;
        private static string _klovProjectName;
        private static string _klovUrl;
        private static string _klovReportName;
        private static IConfiguration config;

        #endregion


        private static AventStack.ExtentReports.ExtentReports extent;
        private static ExtentTest featureName;
        private static ExtentTest scenario;
        private static ExtentKlovReporter klov;

        public static void InitializeReport()
        {
            GetAppSettings();
            DirectoryInfo directoryInfo = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            var ResultsFile = Path.Combine(Directory.GetCurrentDirectory(), Path.GetFileNameWithoutExtension(Path.GetRandomFileName())) + ".html";
            var htmlReporter = new ExtentHtmlReporter(ResultsFile);
            htmlReporter = GetReporterCustomSettings(htmlReporter);

            extent = new AventStack.ExtentReports.ExtentReports();

            if (_useKlov.Contains("true"))
            {
                klov = new ExtentKlovReporter();
                klov.InitMongoDbConnection(_mongodbUrl, _mongodbPort);
                klov.InitKlovServerConnection(_klovUrl);

                klov.ProjectName = _klovProjectName;
                klov.ReportName = _klovReportName + DateTime.Now.ToString();

                extent.AttachReporter(htmlReporter, klov);
            }
            else
            {
                extent.AttachReporter(htmlReporter);
            }
            
        }

        /// <summary>
        /// Get custom settings for HTML report
        /// </summary>
        /// <param name="htmlReporter"></param>
        /// <returns></returns>
        public static ExtentHtmlReporter GetReporterCustomSettings(ExtentHtmlReporter htmlReporter)
        {
            htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            htmlReporter.Config.ReportName = "TCoE DotNet-Mobility Test Results";
            htmlReporter.Config.DocumentTitle = "TCoE DotNet-Mobility  Test Results";            
            return htmlReporter;
        }

        /// <summary>
        /// Complete appending report and flush extent reporter object
        /// </summary>
        public static void TearDownReport()
        {
            //Flush report once test completes
            extent.Flush();
            
        }

        /// <summary>
        /// Create extent test for feature
        /// </summary>
      //  [BeforeFeature]
        public static void BeforeFeature()
        {
            featureName = extent.CreateTest<Feature>(FeatureContext.Current.FeatureInfo.Title);
        }

        /// <summary>
        /// Insert reporting steps
        /// </summary>
        public static void InsertReportingSteps()
        {
            var stepType = ScenarioStepContext.Current.StepInfo.StepDefinitionType.ToString();

            if(ScenarioContext.Current.TestError == null)
            {
                if(stepType == "Given")
                {
                    scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text);
                }
                else if (stepType == "When")
                {
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text);
                }
                else if (stepType == "Then")
                {
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text);
                }
                else if (stepType == "And")
                {
                    scenario.CreateNode<And>(ScenarioStepContext.Current.StepInfo.Text);
                }
            }
            else if (ScenarioContext.Current.TestError != null)
            {
                if (stepType == "Given")
                {
                    scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message);
                }
                else if (stepType == "When")
                {
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message);
                }
                else if (stepType == "Then")
                {
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message);
                }
               
               scenario.AddScreenCaptureFromPath(AndroidUtilities.GetScreenshotPath());
            }
        }

        //[BeforeScenario]
        public static void Initialize()
        {
            //Create dynamic scenario name
            scenario = featureName.CreateNode<Scenario>(ScenarioContext.Current.ScenarioInfo.Title);
        }


        /// <summary>
        /// Get appsettings.json values
        /// </summary>
        private static void GetAppSettings()
        {
            #region ExtentReportSettings

            config = GetIConfigurationRoot();
            _useKlov = config["UseKlov"];
            _mongodbUrl = config["MongodbUrl"];
            _mongodbPort = Convert.ToInt32(config["MongodbPort"]);
            _klovProjectName = config["KlovProjectName"];
            _klovUrl = config["KlovUrl"];
            _klovReportName = config["KlovReportName"];

            #endregion
        }

        /// <summary>
        /// Get config values from appsettings.json
        /// </summary>
        /// <returns></returns>
        public static IConfiguration GetIConfigurationRoot()
        {
            config = new ConfigurationBuilder()
         .SetBasePath(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location))
         .AddJsonFile("appsettings.json", optional: true)
         .Build();

            return config;
        }
    }
}
