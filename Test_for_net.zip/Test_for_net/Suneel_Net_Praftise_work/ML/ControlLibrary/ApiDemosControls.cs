﻿using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using Shell.TCoE.Appium.Core;
using Shell.TCoE.Appium.Core.Utilities;
using System;
using System.Collections.Generic;

namespace Shell.TCoE.MobilityLibrary.ControlLibrary
{
    public class ApiDemosControls
    {
        private AppiumDriver<AppiumWebElement> _appiumDriver;

        #region Constructor

        public ApiDemosControls()
        {
            _appiumDriver = AppiumBase.AppiumDriver;
        }

        #endregion Constructor

        private string controlsLinkXPath = "//*[@text='Controls']";

        #region Views Section controls

        private readonly string viewsLinkXPath = "//*[@text='Views']";

        #region Views-Controls Section Android Locators

        private string contentLinkXPath = "//*[@text='Content']";
        private string lightThemeLinkXPath = "//*[@text='1. Light Theme']";
        private string saveButtonXId = "io.appium.android.apis:id/button";
        private string checkbox1Id = "io.appium.android.apis:id/check1";
        private string checkbox2Id = "io.appium.android.apis:id/check2";
        private string radioButton1Id = "io.appium.android.apis:id/radio1";
        private string radioButton2Id = "io.appium.android.apis:id/radio2";
        private string starCheckboxId = "io.appium.android.apis:id/star";
        private string toggle1Id = "io.appium.android.apis:id/toggle1";
        private string toggle2Id = "io.appium.android.apis:id/toggle2";
        private string spinner1Id = "io.appium.android.apis:id/spinner1";
        private string earthRadioButtonXPath = "//*[@text='Earth']";
        private string textColorSecondaryXPath = "//*[@text='textColorSecondary']";

        #endregion Views-Controls Section Android Locators

        #region Views-PopUp Section Android Locators

        private string popUpMenuXPath = "//*[@text='Popup Menu']";
        private string makePopUpXPath = "//*[@text='MAKE A POPUP!']";
        private string editPopUpXPath = "//*[@text='Edit']";
        private string shareXPath = "android:id/content";

        #endregion Views-PopUp Section Android Locators

        #region Views-Expandable Lists Android Locators

        private string expandableListsXPath = "//*[@text='Expandable Lists']";
        private string simpleAdaptorXPath = "//*[@text = '3. Simple Adapter']";
        private string group7XPath = "//*[@text='Group 7']";
        private string chilElementsClassName = "android.widget.TwoLineListItem";

        #endregion Views-Expandable Lists Android Locators

        #region Views-DragAndDrop Android Locators

        private string dragSourceEleId = "io.appium.android.apis:id/drag_dot_1";
        private string dragDestEleId = "io.appium.android.apis:id/drag_dot_2";
        private string dragAndDropXPath = "//*[@text='Drag and Drop']";
        private string dragDropResultId = "io.appium.android.apis:id/drag_result_text";

        #endregion Views-DragAndDrop Android Locators

        #endregion Views Section controls

        #region App Section Controls

        private string appOptionXPath = "//*[@text='App']";
        private string alertDialogsXPath = "//*[@text='Alert Dialogs']";
        private string alert1DialogId = "io.appium.android.apis:id/two_buttons";
        private string alert2DialogId = "io.appium.android.apis:id/two_buttons2";
        private string alert3DialogId = "io.appium.android.apis:id/two_buttons2ultra";
        private string somethingBtnId = "android:id/button3";
        private string radioBtnOnAlertId = "io.appium.android.apis:id/radio_button";
        private string radioBtnOptionOnAlertXPath = "//*[@text='Traffic']";
        private string progressBarId = "io.appium.android.apis:id/select_button";
        private string progressStatusBarId = "io.appium.android.apis:id/progress_button";
        private string hideButtonId = "io.appium.android.apis:id/radio_button";
        private string textEntryXpath = "//*[@text='TEXT ENTRY DIALOG']";
        private string textUsernameId = "io.appium.android.apis:id/username_edit";
        private string textPasswordId = "io.appium.android.apis:id/password_edit";
        private string okButtonXpath = "//*[@text ='OK']";
        private string dateWidgetsXpath = "//*[@text = 'Date Widgets']";
        private string dialogXpath = "//*[@text = '1. Dialog']";
        private string galleryXpath = "//*[@text = 'Gallery']";
        private string galleryPhotosXpath = "//*[@text = '1. Photos']";
        private string changeDateXpath = "//*[@text = 'CHANGE THE DATE']";
        private string okXpath = "//*[@text = 'OK']";
        private string selectPictureId = "io.appium.android.apis:id/gallery";
        private string yearId = "android:id/date_picker_header_year";
        private string date = "";
        private string year = "";

        #endregion App Section Controls

        #region Controls

        public AppiumWebElement ContentLink => _appiumDriver.FindElementByXPath(contentLinkXPath);
        public AppiumWebElement ViewsLink => _appiumDriver.FindElement(By.XPath(viewsLinkXPath));
        public AppiumWebElement ControlsLink => _appiumDriver.FindElementByXPath(controlsLinkXPath);
        public AppiumWebElement LightThemeLink => _appiumDriver.FindElementByXPath(lightThemeLinkXPath);
        public AppiumWebElement SaveButton => _appiumDriver.FindElementById(saveButtonXId);
        public AppiumWebElement CheckBox1 => _appiumDriver.FindElementById(checkbox1Id);
        public AppiumWebElement CheckBox2 => _appiumDriver.FindElementById(checkbox2Id);
        public AppiumWebElement RadioButton1 => _appiumDriver.FindElementById(radioButton1Id);
        public AppiumWebElement RadioButton2 => _appiumDriver.FindElementById(radioButton2Id);
        public AppiumWebElement StarCheckbox => _appiumDriver.FindElementById(starCheckboxId);
        public AppiumWebElement ToggleButton1 => _appiumDriver.FindElementById(toggle1Id);
        public AppiumWebElement ToggleButton2 => _appiumDriver.FindElementById(toggle2Id);
        public AppiumWebElement SpinnerElement => _appiumDriver.FindElementById(spinner1Id);
        public AppiumWebElement EarthValueFromSpinner => _appiumDriver.FindElementByXPath(earthRadioButtonXPath);
        public AppiumWebElement TextColorSecondaryElement => _appiumDriver.FindElementByXPath(textColorSecondaryXPath);
        public AppiumWebElement PopupMenuElement => _appiumDriver.FindElementByXPath(popUpMenuXPath);
        public AppiumWebElement MakePopUpElement => _appiumDriver.FindElementByXPath(makePopUpXPath);
        public AppiumWebElement EditPopUpElement => _appiumDriver.FindElementByXPath(editPopUpXPath);
        public AppiumWebElement ShareElement => _appiumDriver.FindElementById(shareXPath);
        public AppiumWebElement ExpandableListElement => _appiumDriver.FindElementByXPath(expandableListsXPath);
        public AppiumWebElement SimpleAdaptorElement => _appiumDriver.FindElementByXPath(simpleAdaptorXPath);
        public AppiumWebElement Group7Element => _appiumDriver.FindElementByXPath(group7XPath);
        public IList<AppiumWebElement> Group7ChildElements => _appiumDriver.FindElementsByClassName(chilElementsClassName);
        public AppiumWebElement DragSourceElement => _appiumDriver.FindElementById(dragSourceEleId);
        public AppiumWebElement DragDestElement => _appiumDriver.FindElementById(dragDestEleId);
        public AppiumWebElement DragAndDropElement => _appiumDriver.FindElementByXPath(dragAndDropXPath);
        public AppiumWebElement DragDropResultMsg => _appiumDriver.FindElementById(dragDropResultId);
        public AppiumWebElement AppOption => _appiumDriver.FindElementByXPath(appOptionXPath);
        public AppiumWebElement AlertDialogOption => _appiumDriver.FindElementByXPath(alertDialogsXPath);
        public AppiumWebElement FirstAlertButton => _appiumDriver.FindElementById(alert1DialogId);
        public AppiumWebElement SecondAlertButton => _appiumDriver.FindElementById(alert2DialogId);
        public AppiumWebElement ThirdAlertButton => _appiumDriver.FindElementById(alert3DialogId);
        public AppiumWebElement Alert_SomethingButton => _appiumDriver.FindElementById(somethingBtnId);
        public AppiumWebElement Alert_RadioButton => _appiumDriver.FindElementById(radioBtnOnAlertId);
        public AppiumWebElement TrafficOptionOnRadioButton => _appiumDriver.FindElementByXPath(radioBtnOptionOnAlertXPath);
        public AppiumWebElement ProgressBar => _appiumDriver.FindElementById(progressBarId);
        public AppiumWebElement ProgressStatusBar => _appiumDriver.FindElementById(progressStatusBarId);
        public AppiumWebElement ProgressBarHideBtn => _appiumDriver.FindElementById(hideButtonId);
        public AppiumWebElement TextEntry => _appiumDriver.FindElementByXPath(textEntryXpath);
        public AppiumWebElement TextUsername => _appiumDriver.FindElementById(textUsernameId);
        public AppiumWebElement Textpassword => _appiumDriver.FindElementById(textPasswordId);
        public AppiumWebElement OkButton => _appiumDriver.FindElementByXPath(okButtonXpath);
        public AppiumWebElement DateWidgets => _appiumDriver.FindElementByXPath(dateWidgetsXpath);
        public AppiumWebElement DialogDate => _appiumDriver.FindElementByXPath(dialogXpath);
        public AppiumWebElement Gallery => _appiumDriver.FindElementByXPath(galleryXpath);
        public AppiumWebElement ChangeDate => _appiumDriver.FindElementByXPath(changeDateXpath);
        public AppiumWebElement GallerPicture => _appiumDriver.FindElementByXPath(galleryPhotosXpath);
        public AppiumWebElement SelectPicture => _appiumDriver.FindElementById(selectPictureId);
        public AppiumWebElement SelectYear => _appiumDriver.FindElementById(yearId);
        public AppiumWebElement YearElement => _appiumDriver.FindElementByXPath(year);
        public AppiumWebElement DateElement => _appiumDriver.FindElementByXPath(date);
        public AppiumWebElement OKButton => _appiumDriver.FindElementByXPath(okXpath);
        #endregion Controls

        /// <summary>
        /// Creates Xpath for date
        /// </summary>
        public void dateSetter(int dateString)
        {
            date = string.Format("//*[@text = '{0}']", dateString);
        }

        /// <summary>
        /// Creates Xpath for year
        /// </summary>
        public void yearSetter(int yearString)
        {
            String s = yearString.ToString();
            AndroidUtilities.ScrollToElement(s);
            year = string.Format("//*[@text = '{0}']", yearString);
        }

    }
}