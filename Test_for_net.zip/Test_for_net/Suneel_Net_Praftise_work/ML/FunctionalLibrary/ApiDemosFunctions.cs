﻿using OpenQA.Selenium.Appium;
using Shell.TCoE.Appium.Core;
using Shell.TCoE.Appium.Core.Utilities;
using Shell.TCoE.MobilityLibrary.ControlLibrary;
using System;
using System.Linq;
using System.Threading;

namespace Shell.TCoE.MobilityLibrary.FunctionalLibrary
{
    public class ApiDemosFunctions
    {
        private ApiDemosControls _apiDemosControls;

        public ApiDemosFunctions(ApiDemosControls apiDemosControls)
        {
            _apiDemosControls = apiDemosControls;
        }

        /// <summary>
        /// Verify views
        /// </summary>
        public void Test_Views()
        {
            ClickOnViews();
            _apiDemosControls.ControlsLink.Click();
            _apiDemosControls.LightThemeLink.Click();
            _apiDemosControls.SaveButton.Click();
        }

        /// <summary>
        /// verify different selection controls
        /// </summary>
        public void Test_ControlsOnViews()
        {
            _apiDemosControls.CheckBox1.Click();
            _apiDemosControls.CheckBox2.Click();
            _apiDemosControls.RadioButton1.Click();
            _apiDemosControls.RadioButton2.Click();
            _apiDemosControls.StarCheckbox.Click();
            _apiDemosControls.ToggleButton1.Click();
            _apiDemosControls.ToggleButton2.Click();
            _apiDemosControls.SpinnerElement.Click();
            _apiDemosControls.EarthValueFromSpinner.Click();
        }

        /// <summary>
        /// verify fonts
        /// </summary>
        public void VerifyFont()
        {
            AndroidUtilities.ScrollToElement("textColorTertiary");
            _apiDemosControls.TextColorSecondaryElement.Click();
        }

        /// <summary>
        /// Click on 'Views' option
        /// </summary>
        public void ClickOnViews()
        {
            AndroidUtilities.ScrollToElement("Views");
            _apiDemosControls.ViewsLink.Click();
        }

        /// <summary>
        /// Verify pop-up menus
        /// </summary>
        public void VerifyPopupMenu()
        {
            AndroidUtilities.ScrollToElement("Popup Menu");
            _apiDemosControls.PopupMenuElement.Click();
            _apiDemosControls.MakePopUpElement.Click();
            _apiDemosControls.EditPopUpElement.Click();
            _apiDemosControls.ShareElement.Click();
        }

        /// <summary>
        /// Click on the expandable lists
        /// </summary>
        public void ClickOnExpandableList()
        {
            AndroidUtilities.ScrollToElement("Expandable Lists");
            _apiDemosControls.ExpandableListElement.Click();
        }

        /// <summary>
        /// Verify lists on the UI
        /// </summary>
        public void VerifyExpandableLists()
        {
            _apiDemosControls.SimpleAdaptorElement.Click();
            AndroidUtilities.ScrollToElement("Group 7");
            _apiDemosControls.Group7Element.Click();
            var eles = _apiDemosControls.Group7ChildElements.Select(x => x.FindElementByClassName("android.widget.TextView"));
            var contents = eles.Select(x => x.Text).ToList();

            // Assert list
            AssertUtilities.AssertListContainsItem(contents, "Child 0", true);
        }

        /// <summary>
        /// Verify drag and drop
        /// </summary>
        public void VerifyDragAndDrop()
        {
            AndroidUtilities.ScrollToElement("Drag and Drop");
            _apiDemosControls.DragAndDropElement.Click();
            AndroidUtilities.DragAndDropElement(_apiDemosControls.DragSourceElement, _apiDemosControls.DragDestElement);
            string actualText = _apiDemosControls.DragDropResultMsg.Text;

            AssertUtilities.AssertElementText(actualText, "Dropped!");

            AndroidUtilities.GoBackToPreviousScreen();

            Thread.Sleep(5000); // This sleep is just to verify screen loaded.
        }

        /// <summary>
        /// Verify different alerts
        /// </summary>
        public void VerifyAlerts(string username , string password)
        {
            _apiDemosControls.AlertDialogOption.Click();
            _apiDemosControls.TextEntry.Click();
            AndroidUtilities.SendText(_apiDemosControls.TextUsername, username);
            AndroidUtilities.SendText(_apiDemosControls.Textpassword, password);
            AndroidUtilities.AcceptAlert();
            _apiDemosControls.FirstAlertButton.Click();
            AndroidUtilities.DismissAlert();
            _apiDemosControls.SecondAlertButton.Click();
            _apiDemosControls.Alert_SomethingButton.Click();
            _apiDemosControls.ThirdAlertButton.Click();
            var alert_3 = AppiumBase.AppiumDriver.SwitchTo().Alert();
            AppiumWebElement ele = AppiumBase.AppiumDriver.FindElementById("android:id/content");
            AndroidUtilities.ScrollDownOnAlert(ele);
            AndroidUtilities.ScrollUpOnAlert(ele, 2, 3);
            _apiDemosControls.Alert_SomethingButton.Click();
            _apiDemosControls.Alert_RadioButton.Click();
            _apiDemosControls.TrafficOptionOnRadioButton.Click();
            AndroidUtilities.AcceptAlert();
        }

        

        /// <summary>
        /// Navigate to Gallery
        /// </summary>
        public void GotoGallery()
        {
            _apiDemosControls.Gallery.Click();
            _apiDemosControls.GallerPicture.Click();
        }

        /// <summary>
        /// Scroll horizontally to select picture
        /// </summary>
        public void SelectPicture()
        {
            AndroidUtilities.ScrollHorizontallyRight(_apiDemosControls.SelectPicture, 0.3, 0.7, 1000);
        }

        /// <summary>
        /// Click on 'Date Widget' option
        /// </summary>
        public void ClickOnDate()
        {
            _apiDemosControls.DateWidgets.Click();
        }

        /// <summary>
        /// Click on 'APP' option
        /// </summary>
        public void ClickOnAppOption()
        {
            _apiDemosControls.AppOption.Click();
        }

        /// <summary>
        /// Navigate to UFT
        /// </summary>
        public void NavigateToUFT(string Invoker, string testcaseName, string path)
        {
            UFTUtilities.StartUft(Invoker, testcaseName, path);
        }

        /// <summary>
        /// Navigate to UFT
        /// </summary>
        public void SelectDate(string dateValue)
        {
            DateTime t1 = Convert.ToDateTime(dateValue);
            int date = t1.Day;
            int year = t1.Year;
            _apiDemosControls.DialogDate.Click();
            _apiDemosControls.ChangeDate.Click();
            _apiDemosControls.SelectYear.Click();
            _apiDemosControls.yearSetter(year);
            _apiDemosControls.YearElement.Click();
            _apiDemosControls.dateSetter(date);
            _apiDemosControls.DateElement.Click();
            _apiDemosControls.OKButton.Click();
        }
    }
}